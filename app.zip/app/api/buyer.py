
from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session
from sqlalchemy import text, select
from app.db.session import get_db
from app.models.product import Product
from app.models.faq import ProductQuestion
from app.schemas.personas import BuyerSummaryOut, CountItem, BuyerQuote

router = APIRouter()

@router.get("/product/{product_id}/summary", response_model=BuyerSummaryOut)
def buyer_summary(
    product_id: int,
    pros_limit: int = Query(5, ge=1, le=20),
    cons_limit: int = Query(5, ge=1, le=20),
    quotes_per_polarity: int = Query(2, ge=0, le=10),
    db: Session = Depends(get_db)
):
    p = db.get(Product, product_id)
    if not p:
        raise HTTPException(404, "Product not found")

    q_pros = text("""
        SELECT lower(trim(both '"' from elem::text)) AS label, COUNT(*) AS cnt
        FROM analyses a
        JOIN reviews r ON r.id = a.review_id
        CROSS JOIN LATERAL jsonb_array_elements(a.pros) AS elem
        WHERE r.product_id = :pid
          AND a.pros IS NOT NULL
          AND jsonb_typeof(a.pros)='array' AND jsonb_typeof(elem)='string'
        GROUP BY label
        ORDER BY cnt DESC
        LIMIT :lim
    """)
    pros_rows = db.execute(q_pros, {"pid": product_id, "lim": pros_limit}).all()
    pros = [CountItem(label=str(x[0]), count=int(x[1])) for x in pros_rows]

    q_cons = text("""
        SELECT lower(trim(both '"' from elem::text)) AS label, COUNT(*) AS cnt
        FROM analyses a
        JOIN reviews r ON r.id = a.review_id
        CROSS JOIN LATERAL jsonb_array_elements(a.cons) AS elem
        WHERE r.product_id = :pid
          AND a.cons IS NOT NULL
          AND jsonb_typeof(a.cons)='array' AND jsonb_typeof(elem)='string'
        GROUP BY label
        ORDER BY cnt DESC
        LIMIT :lim
    """)
    cons_rows = db.execute(q_cons, {"pid": product_id, "lim": cons_limit}).all()
    cons = [CountItem(label=str(x[0]), count=int(x[1])) for x in cons_rows]

    q_avg = text("""
        SELECT AVG(rating)::float FROM reviews WHERE product_id = :pid AND rating IS NOT NULL
    """)
    avg_rating = db.execute(q_avg, {"pid": product_id}).scalar()

    q_sv = text("""
        SELECT a.summary, a.verdict
        FROM analyses a
        JOIN reviews r ON r.id = a.review_id
        WHERE r.product_id = :pid
          AND (a.summary IS NOT NULL OR a.verdict IS NOT NULL)
        ORDER BY r.review_date DESC, r.id DESC
        LIMIT 1
    """)
    row = db.execute(q_sv, {"pid": product_id}).first()
    summary = row[0] if row else None
    verdict = row[1] if row else None

    def fetch_quotes(sentiment: str, limit: int):
        if limit <= 0:
            return []
        q = text("""
            SELECT r.review_text, r.rating, r.review_date, a.sentiment, r.helpful_votes, r.reviewer_name
            FROM reviews r
            LEFT JOIN analyses a ON a.review_id = r.id
            WHERE r.product_id = :pid AND a.sentiment = :sent
            ORDER BY r.helpful_votes DESC, r.review_date DESC
            LIMIT :lim
        """)
        rows = db.execute(q, {"pid": product_id, "sent": sentiment, "lim": limit}).all()
        out = []
        for t, rating, d, s, hv, name in rows:
            text_excerpt = (t or "").strip()
            if len(text_excerpt) > 240:
                text_excerpt = text_excerpt[:237] + "..."
            out.append(BuyerQuote(
                text=text_excerpt or "(no text)",
                rating=int(rating) if rating is not None else None,
                date=str(d), sentiment=s or "unknown",
                helpful_votes=int(hv or 0), reviewer_name=name
            ))
        return out

    quotes_pos = fetch_quotes("positive", quotes_per_polarity)
    quotes_neg = fetch_quotes("negative", quotes_per_polarity)

    qs = db.execute(select(ProductQuestion).where(ProductQuestion.product_id == product_id).order_by(ProductQuestion.id.asc())).scalars().all()
    faqs = []
    for q in qs:
        faqs.append({
            "id": q.id,
            "product_id": q.product_id,
            "question_text": q.question_text,
            "asked_at": str(q.asked_at),
            "language": q.language,
            "answers": [{"id": a.id, "question_id": a.question_id, "answer_text": a.answer_text, "answered_at": str(a.answered_at)} for a in q.answers]
        })

    return BuyerSummaryOut(
        product_id=product_id, summary=summary, pros=pros, cons=cons,
        verdict=verdict, average_rating=float(avg_rating) if avg_rating is not None else None,
        quotes_positive=quotes_pos, quotes_negative=quotes_neg, faqs=faqs
    )
