

# backend/app/models/product.py
from sqlalchemy import Column, BigInteger, String, Numeric, ForeignKey, DateTime
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func
from app.models.base import Base

class Product(Base):
    __tablename__ = "products"

    id = Column(BigInteger, primary_key=True)

    # Core fields
    product_title = Column(String(512), nullable=False)
    brand = Column(String(128), nullable=True)
    category = Column(String(128), nullable=True)
    subtype = Column(String(128), nullable=True)
    price = Column(Numeric(18, 2), nullable=True)

    # Match DB
    external_id = Column(String(128), nullable=True, index=True)
    sku = Column(String(128), nullable=True, index=True)
    source = Column(String(128), nullable=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now(), nullable=True)

    # Seller linkage
    seller_id = Column(BigInteger, ForeignKey("sellers.id", ondelete="SET NULL"), index=True, nullable=True)
    seller = relationship("Seller", back_populates="products")

