
from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from sqlalchemy import text
from app.db.session import get_db

router = APIRouter()

@router.get("/product/{product_id}/key-issues", response_model=dict)
def key_issues(product_id: int, db: Session = Depends(get_db)):
    q = text("""
        SELECT lower(elem->>'theme') AS label, COUNT(*) AS cnt
        FROM analyses a
        JOIN reviews r ON r.id = a.review_id
        CROSS JOIN LATERAL jsonb_array_elements(a.key_themes) AS elem
        WHERE r.product_id = :pid
        GROUP BY label
        ORDER BY cnt DESC
        LIMIT 10
    """)
    rows = db.execute(q, {"pid": product_id}).all()
    return {"items": [{"label": str(x[0]), "count": int(x[1])} for x in rows]}

@router.get("/product/{product_id}/sentiment-trend", response_model=dict)
def sentiment_trend(product_id: int, db: Session = Depends(get_db)):
    try:
        q = text("""
            SELECT day, sentiment, count
            FROM mv_product_sentiment_daily
            WHERE product_id = :pid
            ORDER BY day, sentiment
        """)
        rows = db.execute(q, {"pid": product_id}).all()
        points = [{"date": str(d), "sentiment": str(s), "count": int(c)} for d, s, c in rows]
    except Exception:
        points = []
    return {"points": points}
