
from fastapi import APIRouter, Depends, HTTPException, status
from fastapi.security import OAuth2PasswordBearer, OAuth2PasswordRequestForm
from sqlalchemy.orm import Session
from sqlalchemy import select
from jose import JWTError
from datetime import datetime, timedelta, timezone

from app.db.session import get_db
from app.models.user import User
from app.models.seller_application import SellerApplication
from app.core.config import Settings
from app.core.security import (
    hash_password, verify_password, create_access_token, decode_access_token
)
from app.core.mailer import send_email
from app.schemas.auth import (
    RegisterRequest, TokenResponse, UserMe,
    ChangePasswordRequest, PasswordResetRequest, PasswordResetConfirm,
    SellerApplicationCreate, SellerOTPRequest, SellerOTPVerify, SetPasswordFirstTime
)

router = APIRouter()
settings = Settings()
oauth2_scheme = OAuth2PasswordBearer(tokenUrl="/auth/login")


def _issue_token(u: User) -> str:
    return create_access_token(
        subject=str(u.id),
        expires_minutes=settings.jwt_expire_minutes,
        secret=settings.jwt_secret,
        algorithm=settings.jwt_algorithm,
        extra_claims={
            "role": u.role,
            "email": u.email,
            "seller_id": u.seller_id,
            "mcp": u.must_change_password,
        },
    )


@router.post("/register", response_model=TokenResponse)
def register(payload: RegisterRequest, db: Session = Depends(get_db)):
    if payload.role != "buyer":
        raise HTTPException(400, "Only buyers can self-register. Contact admin for seller access.")
    exists = db.execute(select(User).where(User.email == payload.email)).scalar_one_or_none()
    if exists:
        raise HTTPException(400, "Email already registered")
    u = User(
        email=payload.email,
        full_name=payload.full_name,
        password_hash=hash_password(payload.password),
        role="buyer",
        seller_id=None,
        must_change_password=False,
    )
    db.add(u); db.commit(); db.refresh(u)
    token = _issue_token(u)
    return TokenResponse(access_token=token)


@router.post("/login", response_model=TokenResponse)
def login(form: OAuth2PasswordRequestForm = Depends(), db: Session = Depends(get_db)):
    user = db.execute(select(User).where(User.email == form.username)).scalar_one_or_none()
    if not user or not verify_password(form.password, user.password_hash) or not user.is_active:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid credentials")
    token = _issue_token(user)
    return TokenResponse(access_token=token)


def get_current_user(token: str = Depends(oauth2_scheme), db: Session = Depends(get_db)) -> User:
    try:
        payload = decode_access_token(token, settings.jwt_secret, (settings.jwt_algorithm,))
        uid = int(payload.get("sub"))
    except (JWTError, ValueError):
        raise HTTPException(status_code=401, detail="Invalid token")
    user = db.get(User, uid)
    if not user or not user.is_active:
        raise HTTPException(status_code=401, detail="Inactive user")
    return user


def require_role(*roles: str):
    def _dep(u: User = Depends(get_current_user)) -> User:
        if u.role not in roles:
            raise HTTPException(403, "Forbidden")
        return u
    return _dep


@router.get("/me", response_model=UserMe)
def me(u: User = Depends(get_current_user)):
    return UserMe(
        id=u.id, email=u.email, full_name=u.full_name, role=u.role,
        seller_id=u.seller_id, must_change_password=u.must_change_password
    )


@router.post("/change-password", response_model=dict)
def change_password(payload: ChangePasswordRequest, u: User = Depends(get_current_user), db: Session = Depends(get_db)):
    if not verify_password(payload.old_password, u.password_hash):
        raise HTTPException(400, "Old password incorrect")
    u.password_hash = hash_password(payload.new_password)
    u.must_change_password = False
    db.add(u); db.commit()
    return {"status": "ok"}


@router.post("/request-password-reset", response_model=dict)
def request_password_reset(payload: PasswordResetRequest, db: Session = Depends(get_db)):
    u = db.execute(select(User).where(User.email == payload.email)).scalar_one_or_none()
    if u:
        from secrets import token_urlsafe
        u.reset_token = token_urlsafe(48)
        u.reset_expires = datetime.now(timezone.utc) + timedelta(hours=2)
        db.add(u); db.commit()
        if settings.emails_enabled and settings.public_app_url:
            # Optional: email the tokenized link
            link = f"{settings.public_app_url}/set-password?token={u.reset_token}"
            subject = "Set/Reset your password"
            body = f"Hello,\n\nUse this link to set your password:\n{link}\n\nThis link expires in 2 hours."
            send_email(u.email, subject, body)
    return {"status": "ok"}


@router.post("/confirm-password-reset", response_model=dict)
def confirm_password_reset(payload: PasswordResetConfirm, db: Session = Depends(get_db)):
    u = db.execute(select(User).where(User.reset_token == payload.token)).scalar_one_or_none()
    if not u or not u.reset_expires or u.reset_expires < datetime.now(timezone.utc):
        raise HTTPException(400, "Invalid or expired token")
    u.password_hash = hash_password(payload.new_password)
    u.reset_token = None
    u.reset_expires = None
    u.must_change_password = False
    db.add(u); db.commit()
    return {"status": "ok"}


# -------------------------------
# Seller application endpoint (frontend calls this)
# -------------------------------
@router.post("/seller-apply", response_model=dict)
def seller_apply(payload: SellerApplicationCreate, db: Session = Depends(get_db)):
    # if already active seller, short circuit
    u = db.execute(select(User).where(User.email == payload.email)).scalar_one_or_none()
    if u and u.role == "seller" and u.is_active:
        return {"status": "exists", "message": "Seller account already active."}

    # idempotent-ish: reuse pending application
    existing = db.execute(
        select(SellerApplication).where(SellerApplication.email == payload.email)
    ).scalar_one_or_none()

    if existing and existing.status == "pending":
        existing.full_name = payload.full_name or existing.full_name
        existing.company_name = payload.company_name or existing.company_name
        existing.phone = payload.phone or existing.phone
        existing.note = payload.note or existing.note
        db.add(existing); db.commit()
        return {"status": "pending", "id": existing.id}

    app_row = SellerApplication(
        email=payload.email,
        full_name=payload.full_name,
        company_name=payload.company_name,
        phone=payload.phone,
        note=payload.note,
        status="pending",
    )
    db.add(app_row); db.commit(); db.refresh(app_row)
    return {"status": "pending", "id": app_row.id}


# -------------------------------
# Email-only seller OTP (first-time login)
# -------------------------------
def _generate_otp(n: int = 6) -> str:
    from secrets import choice
    digits = "0123456789"
    return "".join(choice(digits) for _ in range(n))


@router.post("/seller/otp/request", response_model=dict)
def seller_otp_request(payload: SellerOTPRequest, db: Session = Depends(get_db)):
    """
    Disabled by requirement: Sellers should NOT trigger OTP send.
    OTP is generated and emailed only when the admin approves the application.
    """
    raise HTTPException(
        status_code=400,
        detail="OTP is sent by the admin at the time of approval. Please check your email or contact the admin to resend."
    )


@router.post("/seller/otp/verify", response_model=TokenResponse)
def seller_otp_verify(payload: SellerOTPVerify, db: Session = Depends(get_db)):
    u = db.execute(select(User).where(User.email == payload.email)).scalar_one_or_none()
    if not u:
        raise HTTPException(404, "No user with that email")
    if u.role != "seller":
        raise HTTPException(400, "Only sellers can use OTP onboarding")

    now = datetime.now(timezone.utc)
    if not u.otp_code or not u.otp_expires or u.otp_expires < now:
        raise HTTPException(400, "OTP invalid or expired")

    if u.otp_attempts is None:
        u.otp_attempts = 0
    if u.otp_attempts >= 5:
        raise HTTPException(429, "Too many attempts. Request a new OTP from admin.")

    if payload.otp.strip() != u.otp_code:
        u.otp_attempts = int(u.otp_attempts or 0) + 1
        db.add(u); db.commit()
        raise HTTPException(400, "Incorrect OTP")

    u.otp_code = None
    u.otp_expires = None
    u.otp_attempts = 0
    u.first_login_via_otp = False
    db.add(u); db.commit(); db.refresh(u)

    token = _issue_token(u)
    return TokenResponse(access_token=token)


@router.post("/set-password-first-time", response_model=dict)
def set_password_first_time(payload: SetPasswordFirstTime, u: User = Depends(get_current_user), db: Session = Depends(get_db)):
    if not u.must_change_password:
        raise HTTPException(400, "Password already set")
    u.password_hash = hash_password(payload.new_password)
    u.must_change_password = False
    db.add(u); db.commit()
    return {"status": "ok"}
