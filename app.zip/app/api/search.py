
# backend/app/api/search.py
from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session
from sqlalchemy import text
from typing import List, Dict

from app.db.session import get_db
from app.api.auth import get_current_user  # login required
from app.models.product import Product
from app.models.embedding import ProductEmbedding
from app.core.semsearch import embed_texts

router = APIRouter()

@router.post("/embeddings/refresh", response_model=dict)
def refresh_product_embeddings(
    model_name: str = "all-MiniLM-L6-v2",
    db: Session = Depends(get_db),
    _u = Depends(get_current_user),
):
    """
    Build/upsert embeddings for all products using SentenceTransformers.
    """
    products: List[Product] = db.query(Product).order_by(Product.id.asc()).all()
    if not products:
        return {"status": "ok", "updated": 0}

    texts = [f"{p.product_title or ''} {p.brand or ''}".strip() for p in products]
    vecs = embed_texts(texts)

    updated = 0
    for p, emb in zip(products, vecs):
        row = db.query(ProductEmbedding).filter(
            ProductEmbedding.product_id == p.id,
            ProductEmbedding.model_name == model_name
        ).first()
        if row:
            row.embedding = emb
        else:
            row = ProductEmbedding(product_id=p.id, model_name=model_name, embedding=emb)
            db.add(row)
        updated += 1
    db.commit()
    return {"status": "ok", "updated": updated}

@router.get("/semantic", response_model=Dict)
def semantic_search(
    q: str = Query(..., min_length=1),
    k: int = Query(10, ge=1, le=50),
    db: Session = Depends(get_db),
    _u = Depends(get_current_user),
):
    """
    Semantic search using pgvector cosine distance (embedding <=> :qvec).
    """
    model_name = "all-MiniLM-L6-v2"
    qvec = embed_texts([q])[0]  # normalized

    count = db.query(ProductEmbedding).filter(ProductEmbedding.model_name == model_name).count()
    if count == 0:
        raise HTTPException(400, "No embeddings found. Run POST /search/embeddings/refresh first.")

    sql = text("""
        SELECT p.id, p.sku, p.product_title, p.brand,
               (pe.embedding <=> :qvec) AS distance
        FROM product_embeddings pe
        JOIN products p ON p.id = pe.product_id
        WHERE pe.model_name = :m
        ORDER BY distance ASC
        LIMIT :k
    """)
    rows = db.execute(sql, {"qvec": qvec, "m": model_name, "k": k}).all()

    results = []
    for pid, sku, title, brand, dist in rows:
        sim = float(1.0 - (dist if dist is not None else 1.0))  # cosine similarity ~ 1 - distance
        results.append({
            "product_id": int(pid),
            "sku": str(sku),
            "title": str(title),
            "brand": (str(brand) if brand is not None else None),
            "score": round(sim, 4),
        })

    return {"query": q, "results": results}
