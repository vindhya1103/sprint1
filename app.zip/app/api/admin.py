
# backend/app/api/admin.py
from fastapi import APIRouter, Depends, UploadFile, File, HTTPException
from sqlalchemy.orm import Session
from sqlalchemy import text, select
import io, csv, json, os
from datetime import datetime, timezone, timedelta
from typing import Optional

from app.db.session import get_db
from app.api.auth import require_role
from app.core.security import hash_password, generate_temp_password
from app.core.config import Settings
from app.core.mailer import send_email

from app.models.user import User
from app.models.seller import Seller
from app.models.product import Product
from app.models.review import Review
from app.models.analysis import Analysis
from app.models.seller_application import SellerApplication
from app.schemas.auth import AdminCreateSellerUserRequest

router = APIRouter()
settings = Settings()

# backend/app/api/admin.py  — ADD BELOW YOUR OTHER IMPORTS
from fastapi import APIRouter, Depends, UploadFile, File, HTTPException
from sqlalchemy.orm import Session
from sqlalchemy import select
import io, csv
from datetime import datetime, timezone

from app.db.session import get_db
from app.api.auth import require_role
from app.core.config import Settings
from app.core.mailer import send_email

from app.models.user import User
from app.models.seller import Seller
from app.models.seller_application import SellerApplication


# ---------------------------------------------------------------------
# NEW: Import seller applications from CSV/TSV (external_id,name,email,phone?,note?)
# ---------------------------------------------------------------------

# backend/app/api/admin.py  — ADD these endpoints

from fastapi import APIRouter, Depends, UploadFile, File, HTTPException
from sqlalchemy.orm import Session
from sqlalchemy import select
import io, csv
from datetime import datetime, timezone

from app.db.session import get_db
from app.api.auth import require_role
from app.core.config import Settings
from app.core.mailer import send_email

from app.models.user import User
from app.models.seller import Seller
from app.models.seller_application import SellerApplication


@router.post("/import/seller-applications", response_model=dict)
async def import_seller_applications_csv(
    file: UploadFile = File(...),
    delimiter: str = ",",  # "," for CSV, "\t" for TSV (pass "\\t" if using fetch/form)
    db: Session = Depends(get_db),
    current_admin: User = Depends(require_role("admin")),
):
    """
    CSV/TSV with columns (header optional): external_id, name, email, phone?, note?
    Creates/updates SellerApplication rows in status 'pending'. Decided apps skipped.
    """
    content = await file.read()
    text = content.decode("utf-8")
    # Support "\t" from frontend select
    delim = "\t" if delimiter in ("\t", "\\t") else delimiter
    reader = csv.reader(io.StringIO(text), delimiter=delim)

    created, updated, skipped = 0, 0, 0
    header = None
    first = True
    for row in reader:
        if not row or all((str(x or "").strip() == "" for x in row)):
            continue

        if first:
            possible = [c.strip().lower() for c in row]
            if set(possible) >= {"external_id", "email"}:  # header present
                header = {name: idx for idx, name in enumerate(possible)}
                first = False
                continue
            else:
                header = None
            first = False

        def col(name, default=""):
            if header and name in header and header[name] < len(row):
                return (row[header[name]] or "").strip()
            # Fallback position-based: ext,name,email,phone,note
            idx_map = {"external_id": 0, "name": 1, "email": 2, "phone": 3, "note": 4}
            idx = idx_map.get(name, -1)
            return (row[idx] or "").strip() if (idx >= 0 and idx < len(row)) else default

        ext = col("external_id")
        nm  = col("name")
        em  = col("email")
        ph  = col("phone")
        nt  = col("note")

        if not em:
            skipped += 1
            continue

        app_row = db.execute(select(SellerApplication).where(SellerApplication.email == em)).scalar_one_or_none()
        if app_row:
            if app_row.status != "pending":
                skipped += 1
                continue
            if nm: app_row.full_name = nm
            if ph: app_row.phone = ph
            if nt: app_row.note = nt
            if ext and not app_row.company_name:
                app_row.company_name = ext  # store ext id here for now
            db.add(app_row)
            updated += 1
        else:
            new_app = SellerApplication(
                email=em,
                full_name=nm or None,
                company_name=ext or None,
                phone=ph or None,
                note=nt or None,
                status="pending",
                created_at=datetime.now(timezone.utc),
            )
            db.add(new_app)
            created += 1

    db.commit()
    return {"created": created, "updated": updated, "skipped": skipped}


@router.post("/seed-applications-from-sellers", response_model=dict)
def seed_apps_from_sellers(
    db: Session = Depends(get_db),
    current_admin: User = Depends(require_role("admin")),
):
    """
    Ensure a pending SellerApplication exists for each seller in `sellers` table.
    Does not create users or send OTP; admin will approve later.
    """
    sellers = db.query(Seller).all()
    created, skipped = 0, 0
    for s in sellers:
        if not s.email:
            skipped += 1
            continue
        app = db.query(SellerApplication).filter(SellerApplication.email == s.email).first()
        if app:
            skipped += 1
            continue
        app_row = SellerApplication(
            email=s.email,
            full_name=s.name,
            company_name=s.external_id,
            status="pending",
            created_at=datetime.now(timezone.utc),
        )
        db.add(app_row)
        created += 1
    db.commit()
    return {"created": created, "skipped": skipped}

# ---------------------------
# Seller application admin ops
# ---------------------------

@router.get("/seller-applications", response_model=list[dict])
def list_seller_applications(
    status: str | None = None,
    db: Session = Depends(get_db),
    _=Depends(require_role("admin"))
):
    q = db.query(SellerApplication)
    if status:
        q = q.filter(SellerApplication.status == status)
    rows = q.order_by(SellerApplication.created_at.desc()).limit(500).all()
    return [{
        "id": a.id,
        "email": a.email,
        "full_name": a.full_name,
        "company_name": a.company_name,
        "phone": a.phone,
        "note": a.note,
        "status": a.status,
        "reason": a.reason,
        "created_at": str(a.created_at),
        "decision_at": str(a.decision_at) if a.decision_at else None,
    } for a in rows]


@router.post("/seller-applications/{app_id}/approve", response_model=dict)
def approve_seller_application(
    app_id: int,
    db: Session = Depends(get_db),
    current_admin: User = Depends(require_role("admin"))
):
    app_row = db.get(SellerApplication, app_id)
    if not app_row:
        raise HTTPException(404, "Application not found")
    if app_row.status != "pending":
        raise HTTPException(400, "Application is not pending")

    seller = db.query(Seller).filter(Seller.email == app_row.email).first()
    if not seller:
        seller = Seller(
            external_id=app_row.email,
            name=app_row.company_name or (app_row.full_name or "Unknown"),
            email=app_row.email
        )
        db.add(seller); db.flush()

    user = db.query(User).filter(User.email == app_row.email).first()
    if not user:
        user = User(
            email=app_row.email,
            full_name=app_row.full_name,
            role="seller",
            seller_id=seller.id,
            is_active=True,
            must_change_password=True,
            password_hash=hash_password(generate_temp_password()),
        )
    else:
        user.role = "seller"
        user.seller_id = seller.id
        user.is_active = True
        user.must_change_password = True

    # Generate email OTP at approval time (required behavior)
    from secrets import choice
    digits = "0123456789"
    otp = "".join(choice(digits) for _ in range(6))
    now = datetime.now(timezone.utc)
    user.otp_code = otp
    user.otp_expires = now + timedelta(minutes=10)
    user.otp_attempts = 0
    user.last_otp_sent_at = now
    user.first_login_via_otp = True

    app_row.status = "approved"
    app_row.reason = None
    app_row.decided_by_user_id = current_admin.id
    app_row.decision_at = now

    db.add(user); db.add(app_row); db.commit(); db.refresh(user)

    if settings.emails_enabled:
        subject = "Your seller OTP (expires in 10 minutes)"
        body = (
            f"Hi {app_row.full_name or 'there'},\n\n"
            f"Your seller account has been approved.\n"
            f"Use this OTP to log in the first time: {otp}\n"
            f"It expires in 10 minutes.\n\n"
            f"Then, set your password from the Seller page."
        )
        send_email(app_row.email, subject, body)
    else:
        print(f"[EMAIL DISABLED] OTP for {user.email}: {otp}")

    return {"status": "ok", "user_id": user.id, "seller_id": seller.id, "sent_to": user.email}


@router.post("/seller-applications/{app_id}/reject", response_model=dict)
def reject_seller_application(
    app_id: int,
    payload: dict,
    db: Session = Depends(get_db),
    current_admin: User = Depends(require_role("admin"))
):
    app_row = db.get(SellerApplication, app_id)
    if not app_row:
        raise HTTPException(404, "Application not found")
    if app_row.status != "pending":
        raise HTTPException(400, "Application is not pending")
    reason = (payload.get("reason") or "").strip() or None
    app_row.status = "rejected"
    app_row.reason = reason
    app_row.decided_by_user_id = current_admin.id
    app_row.decision_at = datetime.now(timezone.utc)
    db.add(app_row); db.commit()
    return {"status": "ok"}


@router.post("/seller-applications/{app_id}/resend-otp", response_model=dict)
def resend_seller_otp(
    app_id: int,
    db: Session = Depends(get_db),
    current_admin: User = Depends(require_role("admin"))
):
    """
    Admin-only: resend OTP to an already-approved seller application.
    """
    app_row = db.get(SellerApplication, app_id)
    if not app_row:
        raise HTTPException(404, "Application not found")
    if app_row.status != "approved":
        raise HTTPException(400, "Application is not approved")

    user = db.query(User).filter(User.email == app_row.email).first()
    if not user or user.role != "seller":
        raise HTTPException(404, "Seller user not found")

    from secrets import choice
    digits = "0123456789"
    otp = "".join(choice(digits) for _ in range(6))
    now = datetime.now(timezone.utc)

    user.otp_code = otp
    user.otp_expires = now + timedelta(minutes=10)
    user.otp_attempts = 0
    user.last_otp_sent_at = now
    user.first_login_via_otp = True

    db.add(user); db.commit()

    if settings.emails_enabled:
        subject = "Your seller OTP (expires in 10 minutes)"
        body = (
            f"Hi {user.full_name or 'there'},\n\n"
            f"Here is a new OTP to sign in the first time: {otp}\n"
            f"It expires in 10 minutes.\n\n"
            f"Then, set your password from the Seller page."
        )
        send_email(user.email, subject, body)
    else:
        print(f"[EMAIL DISABLED] OTP for {user.email}: {otp}")

    return {"status": "ok", "user_id": user.id, "sent_to": user.email}

# ---------------------------
# Existing admin import ops
# ---------------------------

@router.post("/import/products")
async def import_products_csv(
    file: UploadFile = File(...),
    db: Session = Depends(get_db),
    current_admin: User = Depends(require_role("admin")),
):
    content = await file.read()
    reader = csv.DictReader(io.StringIO(content.decode("utf-8")))
    created, updated, skipped = 0, 0, 0
    for row in reader:
        sku = (row.get("sku_asin") or row.get("sku") or "").strip()
        if not sku:
            skipped += 1
            continue
        p = db.query(Product).filter(Product.sku == sku).first()
        price = None
        val = (row.get("price") or "").strip()
        if val != "":
            try:
                price = float(val)
            except Exception:
                price = None
        if p:
            p.product_title = (row.get("product_title") or p.product_title)
            p.brand = (row.get("brand") or p.brand)
            p.category = (row.get("category") or p.category or "Electronics")
            p.subtype = (row.get("subtype") or p.subtype)
            p.price = price if price is not None else p.price
            updated += 1
        else:
            db.add(Product(
                external_id=(row.get("product_id") or None),
                sku=sku,
                product_title=(row.get("product_title") or ""),
                brand=(row.get("brand") or None),
                category=(row.get("category") or "Electronics"),
                subtype=(row.get("subtype") or None),
                price=price,
                source="admin-csv",
            ))
            created += 1
    db.commit()
    return {"created": created, "updated": updated, "skipped": skipped}


@router.post("/import/reviews")
async def import_reviews_csv(
    file: UploadFile = File(...),
    db: Session = Depends(get_db),
    current_admin: User = Depends(require_role("admin")),
):
    content = await file.read()
    reader = csv.DictReader(io.StringIO(content.decode("utf-8")))
    created, skipped = 0, 0
    for row in reader:
        ext_pid = (row.get("product_id") or "").strip()
        if not ext_pid:
            skipped += 1
            continue
        p = db.query(Product).filter(Product.external_id == ext_pid).first()
        if not p:
            skipped += 1
            continue
        date_str = (row.get("review_date") or "").strip()
        review_date = None
        for fmt in ("%Y-%m-%d", "%Y/%m/%d", "%d-%m-%Y"):
            try:
                review_date = datetime.strptime(date_str, fmt).date()
                break
            except Exception:
                continue
        if review_date is None:
            try:
                review_date = datetime.fromisoformat(date_str).date()
            except Exception:
                review_date = None
        rating = None
        try:
            r = (row.get("rating") or "").strip()
            rating = int(r) if r != "" else None
        except Exception:
            rating = None

        db.add(Review(
            product_id=p.id,
            rating=rating,
            review_title=(row.get("review_title") or None),
            review_text=(row.get("review_text") or ""),
            review_date=review_date,
            reviewer_name=(row.get("reviewer_name") or None),
            verified_purchase=((row.get("verified_purchase") or "false").strip().lower() in ("true", "1", "yes")),
            helpful_votes=int((row.get("helpful_votes") or "0") or 0),
            source=(row.get("source") or "web"),
        ))
        created += 1
    db.commit()
    return {"created": created, "skipped": skipped}


@router.post("/import/reviews-json")
async def import_reviews_json(
    file: UploadFile = File(...),
    db: Session = Depends(get_db),
    current_admin: User = Depends(require_role("admin")),
):
    content = await file.read()
    data = json.loads(content.decode("utf-8"))
    if not isinstance(data, list):
        raise HTTPException(400, "JSON must be a list of reviews")
    created = 0
    for row in data:
        ext_pid = (row.get("product_id") or "").strip()
        p = db.query(Product).filter(Product.external_id == ext_pid).first()
        if not p:
            continue
        date_str = (row.get("review_date") or "").strip()
        review_date = None
        for fmt in ("%Y-%m-%d", "%Y/%m/%d", "%d-%m-%Y"):
            try:
                review_date = datetime.strptime(date_str, fmt).date()
                break
            except Exception:
                continue
        if review_date is None:
            try:
                review_date = datetime.fromisoformat(date_str).date()
            except Exception:
                review_date = None
        rating = None
        try:
            r = (row.get("rating") or "").strip()
            rating = int(r) if r != "" else None
        except Exception:
            rating = None

        db.add(Review(
            product_id=p.id,
            rating=rating,
            review_title=(row.get("review_title") or None),
            review_text=(row.get("review_text") or ""),
            review_date=review_date,
            reviewer_name=(row.get("reviewer_name") or None),
            verified_purchase=bool(row.get("verified_purchase") or False),
            helpful_votes=int(row.get("helpful_votes") or 0),
            source=(row.get("source") or "web"),
        ))
        created += 1
    db.commit()
    return {"created": created}


@router.post("/import/sellers")
async def import_sellers_csv(
    file: UploadFile = File(...),
    db: Session = Depends(get_db),
    current_admin: User = Depends(require_role("admin")),
):
    created, updated = 0, 0
    content = await file.read()
    reader = csv.DictReader(io.StringIO(content.decode("utf-8")))
    for row in reader:
        ext = (row.get("external_id") or "").strip()
        if not ext:
            continue
        name = (row.get("name") or "").strip() or "Unknown"
        email = (row.get("email") or None)
        if email:
            email = email.strip()
        s = db.query(Seller).filter(Seller.external_id == ext).first()
        if s:
            s.name = name or s.name
            s.email = email or s.email
            updated += 1
        else:
            db.add(Seller(external_id=ext, name=name, email=email))
            created += 1
    db.commit()
    return {"created": created, "updated": updated}


@router.post("/import/faq-questions")
async def import_faq_questions_csv(
    file: UploadFile = File(...),
    db: Session = Depends(get_db),
    current_admin: User = Depends(require_role("admin")),
):
    content = await file.read()
    reader = csv.DictReader(io.StringIO(content.decode("utf-8")))
    created = 0
    from app.models.faq import ProductQuestion
    for row in reader:
        ext_pid = (row.get("product_id") or "").strip()
        qtext = (row.get("question_text") or "").strip()
        if not ext_pid or not qtext:
            continue
        p = db.query(Product).filter(Product.external_id == ext_pid).first()
        if not p:
            continue
        db.add(ProductQuestion(product_id=p.id, question_text=qtext))
        created += 1
    db.commit()
    return {"created": created}


@router.post("/import/faq-answers")
async def import_faq_answers_csv(
    file: UploadFile = File(...),
    db: Session = Depends(get_db),
    current_admin: User = Depends(require_role("admin")),
):
    content = await file.read()
    reader = csv.DictReader(io.StringIO(content.decode("utf-8")))
    created = 0
    from app.models.faq import ProductQuestion, ProductAnswer
    for row in reader:
        ext_pid = (row.get("product_id") or "").strip()
        qtext = (row.get("question_text") or "").strip()
        atext = (row.get("answer_text") or "").strip()
        if not ext_pid or not qtext or not atext:
            continue
        p = db.query(Product).filter(Product.external_id == ext_pid).first()
        if not p:
            continue
        q = db.query(ProductQuestion).filter(
            ProductQuestion.product_id == p.id,
            ProductQuestion.question_text == qtext
        ).first()
        if not q:
            q = ProductQuestion(product_id=p.id, question_text=qtext)
            db.add(q)
            db.flush()
        db.add(ProductAnswer(question_id=q.id, answer_text=atext))
        created += 1
    db.commit()
    return {"created": created}

# ---------------------------
# Admin user ops
# ---------------------------


@router.post("/users/create-seller", response_model=dict)
def admin_create_seller_user(
    payload: AdminCreateSellerUserRequest,
    db: Session = Depends(get_db),
    current_admin: User = Depends(require_role("admin")),
):
    # Ensure seller exists by external_id
    seller = db.execute(
        select(Seller).where(Seller.external_id == payload.seller_external_id)
    ).scalar_one_or_none()
    if not seller:
        raise HTTPException(400, "Unknown seller_external_id")

    # Check if user already exists
    exists = db.execute(select(User).where(User.email == payload.email)).scalar_one_or_none()
    if exists:
        # For idempotency: return status 'exists' for UI/automation
        return {"status": "exists", "user_id": exists.id, "seller_id": seller.id, "temp_password": None}

    # Create user with temp password
    temp_password = generate_temp_password()
    u = User(
        email=payload.email,
        full_name=payload.full_name,
        password_hash=hash_password(temp_password),
        role="seller",
        seller_id=seller.id,
        must_change_password=True,
        is_active=True,
    )
    db.add(u)
    db.commit()
    db.refresh(u)

    # Email the temp password (dev prints if emails disabled or SMTP missing)
    if settings.emails_enabled:
        subject = "Your seller account credentials (temporary password)"
        body = (
            f"Hi {payload.full_name or 'there'},\n\n"
            f"Your seller account has been created.\n"
            f"Email: {payload.email}\n"
            f"Temporary password: {temp_password}\n\n"
            f"Please log in and set a new password from the Seller page.\n"
            f"{'Login URL: ' + (settings.public_app_url + '/login') if settings.public_app_url else ''}\n"
        )
        send_email(payload.email, subject, body)
    else:
        print(f"[EMAIL DISABLED] Temp password for {u.email}: {temp_password}")

    return {"status": "created", "user_id": u.id, "seller_id": seller.id, "temp_password": temp_password}

@router.post("/users/{user_id}/reset-password", response_model=dict)
def admin_reset_user_password(
    user_id: int,
    db: Session = Depends(get_db),
    current_admin: User = Depends(require_role("admin")),
):
    u = db.get(User, user_id)
    if not u:
        raise HTTPException(404, "User not found")
    temp_password = generate_temp_password()
    u.password_hash = hash_password(temp_password)
    u.must_change_password = True
    db.add(u)
    db.commit()
    return {"status": "ok", "temp_password": temp_password}

# ---------------------------
# Analyses & materialized views
# ---------------------------

@router.get("/bootstrap-analyses", response_model=dict)
def bootstrap_analyses_get(
    db: Session = Depends(get_db),
    current_admin: User = Depends(require_role("admin")),
):
    count = db.query(Analysis).count()
    return {"status": "ok", "existing": int(count)}


@router.post("/bootstrap-analyses", response_model=dict)
def bootstrap_analyses_post(
    db: Session = Depends(get_db),
    current_admin: User = Depends(require_role("admin")),
):
    # Simple heuristic: mark sentiment by rating, fill pros/cons empty
    reviews = db.query(Review).all()
    created, updated = 0, 0
    for r in reviews:
        a = db.query(Analysis).filter(Analysis.review_id == r.id).first()
        if r.rating is None:
            sent = 'unknown'
        elif r.rating <= 2:
            sent = 'negative'
        elif r.rating == 3:
            sent = 'neutral'
        else:
            sent = 'positive'
        if a:
            a.sentiment = sent
            updated += 1
        else:
            db.add(Analysis(review_id=r.id, sentiment=sent, pros=[], cons=[], key_themes=[]))
            created += 1
    db.commit()
    return {"status": "ok", "created": created, "updated": updated}


@router.post("/refresh/materialized-views")
def refresh_materialized_views(
    db: Session = Depends(get_db),
    current_admin: User = Depends(require_role("admin")),
):
    try:
        db.execute(text("REFRESH MATERIALIZED VIEW mv_product_sentiment_daily"))
        db.commit()
        return {"status": "ok", "action": "refreshed"}
    except Exception:
        db.rollback()

    create_mv = text("""
        CREATE MATERIALIZED VIEW IF NOT EXISTS mv_product_sentiment_daily AS
        SELECT
          r.product_id,
          r.review_date::date AS day,
          CASE
            WHEN r.rating IS NULL THEN 'unknown'
            WHEN r.rating <= 2 THEN 'negative'
            WHEN r.rating = 3 THEN 'neutral'
            WHEN r.rating >= 4 THEN 'positive'
            ELSE 'unknown'
          END AS sentiment,
          COUNT(*) AS count
        FROM reviews r
        WHERE r.review_date IS NOT NULL
        GROUP BY r.product_id, r.review_date::date,
                 CASE
                   WHEN r.rating IS NULL THEN 'unknown'
                   WHEN r.rating <= 2 THEN 'negative'
                   WHEN r.rating = 3 THEN 'neutral'
                   WHEN r.rating >= 4 THEN 'positive'
                   ELSE 'unknown'
                 END;
    """)
    try:
        db.execute(create_mv)
        db.execute(text("CREATE INDEX IF NOT EXISTS ix_mv_psd_prod_day ON mv_product_sentiment_daily(product_id, day)"))
        db.commit()
    except Exception as e:
        db.rollback()
        return {"status": "partial", "error": f"create_mv failed: {str(e)}"}

    try:
        db.execute(text("REFRESH MATERIALIZED VIEW mv_product_sentiment_daily"))
        db.commit()
        return {"status": "ok", "action": "created_and_refreshed"}
    except Exception as e:
        db.rollback()
        return {"status": "partial", "error": f"refresh failed: {str(e)}"}
