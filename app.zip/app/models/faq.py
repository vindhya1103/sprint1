
from sqlalchemy import Column, BigInteger, Text, TIMESTAMP, ForeignKey, String
from sqlalchemy.sql import func
from sqlalchemy.orm import relationship
from app.models.base import Base

class ProductQuestion(Base):
    __tablename__ = "product_questions"
    id = Column(BigInteger, primary_key=True)
    product_id = Column(BigInteger, ForeignKey("products.id", ondelete="CASCADE"), nullable=False, index=True)
    question_text = Column(Text, nullable=False)
    asked_at = Column(TIMESTAMP(timezone=True), server_default=func.now(), nullable=False)
    language = Column(String(16), default="en")

    product = relationship("Product", backref="questions")
    answers = relationship("ProductAnswer", back_populates="question", cascade="all, delete-orphan")

class ProductAnswer(Base):
    __tablename__ = "product_answers"
    id = Column(BigInteger, primary_key=True)
    question_id = Column(BigInteger, ForeignKey("product_questions.id", ondelete="CASCADE"), nullable=False, index=True)
    answer_text = Column(Text, nullable=False)
    answered_at = Column(TIMESTAMP(timezone=True), server_default=func.now(), nullable=False)

    question = relationship("ProductQuestion", back_populates="answers")
