
// frontend/src/pages/AdminApprovals.jsx
import { useEffect, useState } from "react";
import Header from "../components/Header";

const API_BASE = import.meta.env.VITE_API_BASE || "http://127.0.0.1:8001";

function authHeaders() {
  const t = localStorage.getItem("access_token");
  return t ? { Authorization: `Bearer ${t}` } : {};
}

export default function AdminApprovals() {
  const [tab, setTab] = useState("pending"); // pending | approved | rejected
  const [items, setItems] = useState([]);
  const [loading, setLoading] = useState(false);
  const [flash, setFlash] = useState("");
  const [rejectNote, setRejectNote] = useState("");
  const [uploading, setUploading] = useState(false);
  const [delimiter, setDelimiter] = useState(",");

  async function fetchApps(status) {
    setLoading(true);
    setFlash("");
    try {
      const url = new URL(API_BASE + "/admin/seller-applications");
      if (status) url.searchParams.set("status", status);
      const res = await fetch(url, { headers: { Accept: "application/json", ...authHeaders() } });
      if (!res.ok) throw new Error((await res.text()) || res.statusText);
      const data = await res.json();
      setItems(data || []);
    } catch (e) {
      setFlash(e?.message || "Failed to load applications.");
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    fetchApps(tab);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [tab]);

  async function approve(id) {
    setFlash("");
    try {
      const res = await fetch(`${API_BASE}/admin/seller-applications/${id}/approve`, {
        method: "POST",
        headers: { Accept: "application/json", ...authHeaders() },
      });
      if (!res.ok) throw new Error((await res.text()) || res.statusText);
      setFlash("Approved. OTP emailed to the seller.");
      await fetchApps("pending");
    } catch (e) {
      setFlash(e?.message || "Approve failed.");
    }
  }

  async function reject(id) {
    setFlash("");
    try {
      const res = await fetch(`${API_BASE}/admin/seller-applications/${id}/reject`, {
        method: "POST",
        headers: { "Content-Type": "application/json", Accept: "application/json", ...authHeaders() },
        body: JSON.stringify({ reason: rejectNote || null }),
      });
      if (!res.ok) throw new Error((await res.text()) || res.statusText);
      setFlash("Rejected.");
      setRejectNote("");
      await fetchApps("pending");
    } catch (e) {
      setFlash(e?.message || "Reject failed.");
    }
  }

  async function resendOTP(id) {
    setFlash("");
    try {
      const res = await fetch(`${API_BASE}/admin/seller-applications/${id}/resend-otp`, {
        method: "POST",
        headers: { Accept: "application/json", ...authHeaders() },
      });
      if (!res.ok) throw new Error((await res.text()) || res.statusText);
      setFlash("OTP resent.");
      if (tab === "approved") await fetchApps("approved");
    } catch (e) {
      setFlash(e?.message || "Resend OTP failed.");
    }
  }

  async function onUploadFile(e) {
    const file = e.target.files?.[0];
    if (!file) return;
    setUploading(true);
    setFlash("");
    try {
      const form = new FormData();
      form.append("file", file);
      form.append("delimiter", delimiter === "\\t" ? "\\t" : delimiter); // "," or "\\t"

      const res = await fetch(`${API_BASE}/admin/import/seller-applications`, {
        method: "POST",
        headers: { ...authHeaders() }, // DO NOT set Content-Type; browser will set multipart/form-data
        body: form,
      });
      if (!res.ok) throw new Error((await res.text()) || res.statusText);
      const data = await res.json();
      setFlash(`Imported: ${data.created} created, ${data.updated} updated, ${data.skipped} skipped.`);
      await fetchApps("pending");
    } catch (e) {
      setFlash(e?.message || "Upload failed.");
    } finally {
      setUploading(false);
      e.target.value = null;
    }
  }

  async function seedFromSellers() {
    setUploading(true);
    setFlash("");
    try {
      const res = await fetch(`${API_BASE}/admin/seed-applications-from-sellers`, {
        method: "POST",
        headers: { Accept: "application/json", ...authHeaders() },
      });
      if (!res.ok) throw new Error((await res.text()) || res.statusText);
      const data = await res.json();
      setFlash(`Seeded: ${data.created} created, ${data.skipped} skipped.`);
      await fetchApps("pending");
    } catch (e) {
      setFlash(e?.message || "Seed failed.");
    } finally {
      setUploading(false);
    }
  }

  return (
    <div className="page">
      <Header />
      <main className="container">
        {/* Inline styles for a polished approvals UI */}
        <style>{`
          :root {
            --bg: #0b1020;
            --panel: #0f172a;
            --panel2: #101a33;
            --border: #1f2937;
            --text: #e5e7eb;
            --muted: #9fb0d1;
            --accent: #3b82f6;
            --accent600: #2563eb;
            --pos: #22c55e;
            --neg: #ef4444;
            --warn: #eab308;
          }
          .card {
            background: linear-gradient(180deg, rgba(255,255,255,.02), rgba(255,255,255,.01));
            border: 1px solid var(--border);
            border-radius: 12px;
            box-shadow: 0 1px 3px rgba(0,0,0,.25);
          }
          .glass {
            background: linear-gradient(180deg, rgba(255,255,255,.03), rgba(255,255,255,.02));
            backdrop-filter: blur(4px);
          }
          .panel {
            background: var(--panel);
            border: 1px solid var(--border);
            border-radius: 12px;
          }
          .muted { color: var(--muted); }
          .hint { color: var(--muted); margin-top: 8px; }

          /* Header area inside card */
          .card-head {
            padding: 16px 18px 8px;
            border-bottom: 1px solid var(--border);
          }
          .card-body {
            padding: 14px 18px 18px;
          }
          h3 {
            margin: 0;
            font-size: 1.4rem;
            letter-spacing: -.2px;
            color: var(--text);
          }

          /* Tabs */
          .tabs {
            display: inline-flex;
            align-items: center;
            gap: 8px;
            margin-top: 10px;
          }
          .tab-btn {
            padding: 8px 12px;
            border-radius: 999px;
            border: 1px solid var(--border);
            background: var(--panel2);
            color: var(--text);
            cursor: pointer;
            font-size: .95rem;
            transition: background .12s, border-color .12s, transform .06s;
          }
          .tab-btn:hover { background: #111b33; border-color: #2a3b65; transform: translateY(-1px); }
          .tab-btn.active {
            background: rgba(59,130,246,.14);
            border-color: rgba(59,130,246,.45);
            box-shadow: 0 0 0 2px rgba(124,108,255,.12) inset;
          }

          /* Import bar */
          .import-bar {
            display: flex; gap: 12px; align-items: center; flex-wrap: wrap;
            margin-top: 12px; padding: 10px; border-radius: 12px;
            background: var(--panel2);
            border: 1px solid var(--border);
          }
          .import-bar label { display: inline-flex; align-items: center; gap: 8px; }
          .import-bar input[type="file"] {
            color: var(--text);
          }
          .import-bar select {
            background: #0f1a33; color: var(--text);
            border: 1px solid var(--border); border-radius: 8px;
            padding: 6px 8px; font-size: .95rem;
          }

          /* Table */
          .table-wrap {
            margin-top: 12px;
            border: 1px solid var(--border);
            border-radius: 12px;
            overflow: hidden;
            background: #0f1a33;
          }
          table.approvals {
            width: 100%;
            border-collapse: separate;
            border-spacing: 0;
            font-size: .95rem;
            color: var(--text);
          }
          .approvals thead th {
            position: sticky; top: 0;
            background: rgba(255,255,255,.03);
            backdrop-filter: blur(3px);
            color: #cbd5e1;
            text-align: left;
            padding: 12px;
            border-bottom: 1px solid var(--border);
            z-index: 1;
          }
          .approvals tbody td {
            padding: 12px;
            border-bottom: 1px solid rgba(255,255,255,.06);
            vertical-align: middle;
          }
          .approvals tbody tr:nth-child(odd) td { background: rgba(255,255,255,.02); }
          .approvals tbody tr:hover td { background: rgba(255,255,255,.03); }

          /* Status badges */
          .badge {
            display: inline-flex; align-items: center; gap: 6px;
            padding: 4px 10px; border-radius: 999px; font-weight: 600; font-size: .85rem;
            border: 1px solid transparent;
          }
          .badge.pending { background: rgba(234,179,8,.12); border-color: rgba(234,179,8,.35); color: var(--warn); }
          .badge.approved { background: rgba(34,197,94,.12); border-color: rgba(34,197,94,.35); color: var(--pos); }
          .badge.rejected { background: rgba(239,68,68,.12); border-color: rgba(239,68,68,.35); color: var(--neg); }

          /* Actions */
          .actions {
            display: inline-flex; gap: 8px; align-items: center; flex-wrap: wrap;
          }
          .btn-mini {
            padding: 6px 10px;
            border-radius: 8px;
            border: 1px solid var(--border);
            background: var(--panel2);
            color: var(--text);
            cursor: pointer;
            font-size: .9rem;
            transition: background .12s, border-color .12s, transform .06s;
          }
          .btn-mini:hover { background: #111b33; border-color: #2a3b65; transform: translateY(-1px); }
          .btn-approve {
            background: rgba(34,197,94,.15);
            border-color: rgba(34,197,94,.45);
            color: var(--pos);
          }
          .btn-approve:hover { background: rgba(34,197,94,.25); }
          .btn-reject {
            background: rgba(239,68,68,.15);
            border-color: rgba(239,68,68,.45);
            color: var(--neg);
          }
          .btn-reject:hover { background: rgba(239,68,68,.25); }
          .btn-otp {
            background: rgba(59,130,246,.14);
            border-color: rgba(59,130,246,.45);
            color: #7aa2ff;
          }
          .btn-otp:hover { background: rgba(59,130,246,.24); }

          .reject-wrap {
            display: inline-flex; gap: 8px; align-items: center; flex-wrap: wrap;
          }
          .reject-input {
            width: 220px;
            padding: 6px 8px;
            border-radius: 8px;
            border: 1px solid var(--border);
            background: #0f1a33;
            color: var(--text);
            outline: none;
          }
          .reject-input::placeholder { color: #8ba0c8; }

          /* Page max width controls (optional) */
          .container { max-width: 1200px; margin: 0 auto; }
        `}</style>

        <section className="glass card" aria-label="Seller Applications Admin">
          <div className="card-head">
            <h3>Seller Applications — Admin</h3>

            {/* Tabs */}
            <div className="tabs" role="tablist" aria-label="Approval tabs">
              <button
                className={`tab-btn ${tab === "pending" ? "active" : ""}`}
                role="tab"
                aria-selected={tab === "pending"}
                onClick={() => setTab("pending")}
              >
                Pending
              </button>
              <button
                className={`tab-btn ${tab === "approved" ? "active" : ""}`}
                role="tab"
                aria-selected={tab === "approved"}
                onClick={() => setTab("approved")}
              >
                Approved
              </button>
              <button
                className={`tab-btn ${tab === "rejected" ? "active" : ""}`}
                role="tab"
                aria-selected={tab === "rejected"}
                onClick={() => setTab("rejected")}
              >
                Rejected
              </button>
            </div>

            {/* Import / Seed bar */}
            <div className="import-bar" aria-label="Bulk import and seed controls">
              <label>
                <span className="muted">Import (CSV/TSV): </span>
                <input type="file" accept=".csv,.tsv,.txt" onChange={onUploadFile} disabled={uploading} />
              </label>
              <label>
                <span className="muted">Delimiter: </span>
                <select value={delimiter} onChange={(e) => setDelimiter(e.target.value)}>
                  <option value=",">Comma (,)</option>
                  <option value="\\t">Tab (\\t)</option>
                </select>
              </label>
              <button className="btn-mini btn-otp" onClick={seedFromSellers} disabled={uploading}>
                Seed from sellers table
              </button>
            </div>

            {flash && <p className="hint" role="status">{flash}</p>}
            {loading && <p className="hint">Loading…</p>}
          </div>

          <div className="card-body">
            <div className="table-wrap" role="region" aria-label="Applications table">
              {items.length === 0 && <p className="hint">No applications.</p>}

              {items.length > 0 && (
                <table className="approvals">
                  <thead>
                    <tr>
                      <th align="left">ID</th>
                      <th align="left">Email</th>
                      <th align="left">Name</th>
                      <th align="left">Company/Ext ID</th>
                      <th align="left">Phone</th>
                      <th align="left">Status</th>
                      <th align="left">Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    {items.map((a) => (
                      <tr key={a.id}>
                        <td>{a.id}</td>
                        <td>{a.email}</td>
                        <td>{a.full_name || "—"}</td>
                        <td>{a.company_name || "—"}</td>
                        <td>{a.phone || "—"}</td>
                        <td>
                          <span className={`badge ${String(a.status).toLowerCase()}`}>
                            {a.status}
                          </span>
                        </td>
                        <td>
                          <div className="actions">
                            {tab === "pending" && (
                              <>
                                <button className="btn-mini btn-approve" onClick={() => approve(a.id)}>
                                  Approve
                                </button>
                                <div className="reject-wrap">
                                  <input
                                    className="reject-input"
                                    placeholder="Reject reason (optional)"
                                    value={rejectNote}
                                    onChange={(e) => setRejectNote(e.target.value)}
                                  />
                                  <button className="btn-mini btn-reject" onClick={() => reject(a.id)}>
                                    Reject
                                  </button>
                                </div>
                              </>
                            )}
                            {tab === "approved" && (
                              <button className="btn-mini btn-otp" onClick={() => resendOTP(a.id)}>
                                Resend OTP
                              </button>
                            )}
                            {tab === "rejected" && (
                              <span className="muted" title={a.rejection_reason || ""}>
                                {a.rejection_reason ? `Reason: ${a.rejection_reason}` : "—"}
                              </span>
                            )}
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              )}
            </div>
          </div>
        </section>
      </main>
    </div>
  );
}
