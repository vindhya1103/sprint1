
from pydantic import BaseModel
from typing import Optional

class ReviewCreate(BaseModel):
    product_id: int
    rating: Optional[int] = None
    review_title: Optional[str] = None
    review_text: str
    review_date: str
    reviewer_name: Optional[str] = None
    verified_purchase: bool = False
    helpful_votes: int = 0
    source: Optional[str] = "web"

class ReviewOut(BaseModel):
    id: int
    product_id: int
    rating: Optional[int] = None
    review_title: Optional[str] = None
    review_text: str
    review_date: str
    reviewer_name: Optional[str] = None
    verified_purchase: bool
    helpful_votes: int
    source: Optional[str] = None
