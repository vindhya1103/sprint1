
# backend/app/models/embedding.py
from sqlalchemy import Column, BigInteger, String, ForeignKey, UniqueConstraint
from sqlalchemy.orm import relationship
from app.models.base import Base

# pgvector SQLAlchemy type
from pgvector.sqlalchemy import Vector

# all-MiniLM-L6-v2 produces 384-dim vectors
EMBED_DIM = 384

class ProductEmbedding(Base):
    __tablename__ = "product_embeddings"
    id = Column(BigInteger, primary_key=True)
    product_id = Column(BigInteger, ForeignKey("products.id", ondelete="CASCADE"), nullable=False, index=True)
    model_name = Column(String(128), nullable=False, default="all-MiniLM-L6-v2")
    embedding = Column(Vector(EMBED_DIM), nullable=False)  # pgvector column

    product = relationship("Product", backref="embeddings")

    __table_args__ = (
        UniqueConstraint('product_id', 'model_name', name='uq_pe_pid_model'),
    )
