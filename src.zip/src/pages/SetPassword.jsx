
// src/pages/SetPassword.jsx
import { useState } from "react";
import { useNavigate, useSearchParams } from "react-router-dom";
import Header from "../components/Header";
import { postJSON } from "../api";

export default function SetPassword() {
  const [params] = useSearchParams();
  const token = params.get("token") || ""; // invite/reset token from email
  const navigate = useNavigate();

  const [fullName, setFullName] = useState("");
  const [password, setPassword] = useState("");
  const [confirm, setConfirm] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState("");

  async function onSubmit(e) {
    e.preventDefault();
    setError("");

    if (!token) {
      setError("Missing token in link.");
      return;
    }
    if (password.length < 6) {
      setError("Password must be at least 6 characters.");
      return;
    }
    if (password !== confirm) {
      setError("Passwords do not match.");
      return;
    }

    setSubmitting(true);
    try {
      // 1) Set password using backend's confirm-password-reset
      await postJSON("/auth/confirm-password-reset", {
        token,
        new_password: password,
      });

      // (Optional) 2) Update full name if provided (you can extend backend with PATCH /auth/me)
      // For now, skip or add a call like: await postJSON('/auth/update-profile', { full_name: fullName });

      // Redirect to login
      navigate("/login", { replace: true, state: { flash: "Password set. Please log in." } });
    } catch (err) {
      setError(err?.message || "Failed to set password.");
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <div className="register-v10">
      <Header />
      <div className="register-v10__container">
        <div className="inner glass card">
          <form onSubmit={onSubmit} noValidate>
            <h3 className="register-title">Set your seller password</h3>

            <div className="form-holder">
              <input
                type="text"
                className="form-control"
                placeholder="Full Name (optional)"
                value={fullName}
                onChange={(e) => setFullName(e.target.value)}
                autoComplete="name"
              />
            </div>

            <div className="form-holder">
              <input
                type="password"
                className="form-control"
                placeholder="New password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                autoComplete="new-password"
              />
            </div>

            <div className="form-holder">
              <input
                type="password"
                className="form-control"
                placeholder="Confirm password"
                value={confirm}
                onChange={(e) => setConfirm(e.target.value)}
                autoComplete="new-password"
              />
            </div>

            <button type="submit" className="btn primary" disabled={submitting}>
              <span>{submitting ? "Saving..." : "Save"}</span>
            </button>

            {error && <div className="submit-error" role="alert">{error}</div>}
          </form>
        </div>
      </div>
    </div>
  );
}
