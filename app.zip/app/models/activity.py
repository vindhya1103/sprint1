
# backend/app/models/activity.py
from sqlalchemy import Column, BigInteger, String, Text, TIMESTAMP, ForeignKey, Boolean
from sqlalchemy.sql import func
from sqlalchemy.orm import relationship
from app.models.base import Base

class UserSession(Base):
    __tablename__ = "user_sessions"
    id = Column(BigInteger, primary_key=True)
    user_id = Column(BigInteger, ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True)
    created_at = Column(TIMESTAMP(timezone=True), server_default=func.now(), nullable=False)
    logout_time = Column(TIMESTAMP(timezone=True), nullable=True)
    is_active = Column(Boolean, nullable=False, default=True)

    user = relationship("User", backref="sessions")

class UserActivityLog(Base):
    __tablename__ = "user_activity_logs"
    id = Column(BigInteger, primary_key=True)
    user_id = Column(BigInteger, ForeignKey("users.id", ondelete="SET NULL"), nullable=True, index=True)
    activity_type = Column(String(64), nullable=False)
    activity_description = Column(Text, nullable=False)
    # !!! renamed from `metadata` (reserved) to `meta_json`
    meta_json = Column(Text, nullable=True)  # store JSON string if needed
    created_at = Column(TIMESTAMP(timezone=True), server_default=func.now(), nullable=False)

    user = relationship("User", backref="activity_logs")

class ProductView(Base):
    __tablename__ = "product_views"
    id = Column(BigInteger, primary_key=True)
    user_id = Column(BigInteger, ForeignKey("users.id", ondelete="SET NULL"), nullable=True, index=True)
    product_id = Column(BigInteger, ForeignKey("products.id", ondelete="CASCADE"), nullable=False, index=True)
    viewed_at = Column(TIMESTAMP(timezone=True), server_default=func.now(), nullable=False)
