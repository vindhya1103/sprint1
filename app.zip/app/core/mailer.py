
# backend/app/core/mailer.py
import smtplib
from email.message import EmailMessage
from app.core.config import Settings

settings = Settings()

def send_email(to_email: str, subject: str, body: str):
    """
    Simple SMTP sender. Requires EMAILS_ENABLED=true and SMTP_* set.
    """
    if not settings.emails_enabled:
        print(f"[MAIL DISABLED] Would send to {to_email}: {subject}\n{body}\n")
        return
    if not (settings.smtp_host and settings.smtp_port and settings.smtp_user and settings.smtp_pass):
        print("[MAIL] Missing SMTP config; cannot send.")
        return

    msg = EmailMessage()
    msg["From"] = settings.smtp_user
    msg["To"] = to_email
    msg["Subject"] = subject
    msg.set_content(body)

    try:
        with smtplib.SMTP(settings.smtp_host, int(settings.smtp_port)) as server:
            server.ehlo()
            if settings.smtp_use_tls:
                server.starttls()
                server.ehlo()
            server.login(settings.smtp_user, settings.smtp_pass)
            server.send_message(msg)
        print(f"[MAIL] Sent to {to_email}: {subject}")
    except Exception as e:
        print(f"[MAIL ERROR] Sending to {to_email} failed: {e}")
