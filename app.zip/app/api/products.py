


# backend/app/api/products.py
from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session
from sqlalchemy import text
from typing import List, Optional

from app.db.session import get_db
from app.models.product import Product
from app.models.user import User
from app.schemas.product import ProductCreate, ProductOut

# Optional activity helpers
try:
    from app.core.activity import record_product_view, log_activity
    HAVE_ACTIVITY_HELPERS = True
except Exception:
    HAVE_ACTIVITY_HELPERS = False

# Optional auth dependency
try:
    from app.api.auth import get_current_user
    HAVE_AUTH_DEP = True
except Exception:
    HAVE_AUTH_DEP = False

router = APIRouter()


@router.post("/", response_model=dict)
def create_product(payload: ProductCreate, db: Session = Depends(get_db)):
    """
    Create a new product. Enforces unique SKU constraint.
    """
    exists = db.query(Product).filter(Product.sku == payload.sku).first()
    if exists:
        raise HTTPException(status_code=400, detail="SKU already exists")

    p = Product(**payload.model_dump())
    db.add(p)
    db.commit()
    db.refresh(p)
    return {"id": p.id}


@router.get("/search", response_model=List[ProductOut])
def search_products(
    q: Optional[str] = Query(None, description="Search by title, brand, or SKU"),
    limit: int = Query(50, ge=1, le=200),
    seller_id: Optional[int] = Query(None, description="Filter by seller id"),
    db: Session = Depends(get_db),
):
    """
    Text search by title, brand, or SKU (ILIKE). Optional filter by seller_id.
    Raw SQL to leverage ILIKE and keep it simple.
    """
    if q is None or q.strip() == "":
        return []

    where = ["(product_title ILIKE :qq OR brand ILIKE :qq OR sku ILIKE :qq)"]
    params: dict = {"qq": f"%{q.strip()}%", "lim": limit}
    if seller_id is not None:
        where.append("seller_id = :sid")
        params["sid"] = int(seller_id)

    sql = text(f"""
        SELECT id, sku, product_title, brand, category, price, source, external_id, subtype
        FROM products
        WHERE {' AND '.join(where)}
        ORDER BY id ASC
        LIMIT :lim
    """)
    rows = db.execute(sql, params).all()

    out: List[ProductOut] = []
    for r in rows:
        out.append(ProductOut(
            id=int(r[0]),
            sku=(str(r[1]) if r[1] is not None else None),
            product_title=(str(r[2]) if r[2] is not None else None),
            brand=(str(r[3]) if r[3] is not None else None),
            category=(str(r[4]) if r[4] is not None else None),
            price=(float(r[5]) if r[5] is not None else None),
            source=(str(r[6]) if r[6] is not None else None),
            external_id=(str(r[7]) if r[7] is not None else None),
            subtype=(str(r[8]) if r[8] is not None else None),
        ))
    return out


@router.get("/", response_model=List[ProductOut])
def list_products(
    limit: int = Query(60, ge=1, le=500),
    seller_id: Optional[int] = Query(None, description="Filter by seller id"),
    order: str = Query("desc", pattern="^(asc|desc)$", description="Order by id asc|desc"),
    db: Session = Depends(get_db),
):
    """
    List products (optionally filter by seller_id).
    Defaults to newest first (id DESC).
    """
    q = db.query(Product)
    if seller_id is not None:
        q = q.filter(Product.seller_id == int(seller_id))

    if order.lower() == "asc":
        q = q.order_by(Product.id.asc())
    else:
        q = q.order_by(Product.id.desc())

    items: List[Product] = q.limit(limit).all()

    return [
        ProductOut(
            id=p.id,
            sku=getattr(p, "sku", None),  # safe access
            product_title=p.product_title,
            brand=p.brand,
            category=p.category,
            price=float(p.price) if p.price is not None else None,
            source=p.source,
            external_id=p.external_id,
            subtype=p.subtype,
        )
        for p in items
    ]


# ------- Product details -------

if HAVE_AUTH_DEP:
    @router.get("/by-id/{product_id}", response_model=ProductOut)
    def get_product(
        product_id: int,
        db: Session = Depends(get_db),
        u: User = Depends(get_current_user),
    ):
        p = db.get(Product, product_id)
        if not p:
            raise HTTPException(status_code=404, detail="Product not found")

        if HAVE_ACTIVITY_HELPERS:
            try:
                record_product_view(db, u.id if u else None, product_id)
                log_activity(
                    db,
                    u.id if u else None,
                    "VIEW_PRODUCT",
                    f"Viewed product {product_id}",
                    {"sku": getattr(p, "sku", None), "title": p.product_title},
                )
            except Exception:
                pass

        return ProductOut(
            id=p.id,
            sku=getattr(p, "sku", None),
            product_title=p.product_title,
            brand=p.brand,
            category=p.category,
            price=float(p.price) if p.price is not None else None,
            source=p.source,
            external_id=p.external_id,
            subtype=p.subtype,
        )
else:
    @router.get("/by-id/{product_id}", response_model=ProductOut)
    def get_product(product_id: int, db: Session = Depends(get_db)):
        p = db.get(Product, product_id)
        if not p:
            raise HTTPException(status_code=404, detail="Product not found")
        return ProductOut(
            id=p.id,
            sku=getattr(p, "sku", None),
            product_title=p.product_title,
            brand=p.brand,
            category=p.category,
            price=float(p.price) if p.price is not None else None,
            source=p.source,
            external_id=p.external_id,
            subtype=p.subtype,
        )
