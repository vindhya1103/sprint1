
from sqlalchemy import Column, BigInteger, Text, String, ForeignKey, UniqueConstraint
from sqlalchemy.dialects.postgresql import JSONB
from sqlalchemy.orm import relationship
from app.models.base import Base

class Analysis(Base):
    __tablename__ = "analyses"
    id = Column(BigInteger, primary_key=True)
    review_id = Column(BigInteger, ForeignKey("reviews.id", ondelete="CASCADE"), unique=True, nullable=False)
    summary = Column(Text, nullable=True)
    verdict = Column(Text, nullable=True)
    pros = Column(JSONB, nullable=True)
    cons = Column(JSONB, nullable=True)
    sentiment = Column(String(32), nullable=True)
    key_themes = Column(JSONB, nullable=True)
    raw_output = Column(JSONB, nullable=True)

    review = relationship("Review", backref="analysis")

    __table_args__ = (
        UniqueConstraint('review_id', name='uq_analyses_review'),
    )
