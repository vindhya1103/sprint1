
from pydantic import BaseModel, EmailStr
from typing import Optional

class RegisterRequest(BaseModel):
    email: EmailStr
    full_name: Optional[str] = None
    password: str
    role: str = "buyer"

class TokenResponse(BaseModel):
    access_token: str
    token_type: str = "bearer"

class UserMe(BaseModel):
    id: int
    email: EmailStr
    full_name: Optional[str] = None
    role: str
    seller_id: Optional[int] = None
    must_change_password: bool = False

class AdminCreateSellerUserRequest(BaseModel):
    email: EmailStr
    full_name: Optional[str] = None
    seller_external_id: str

class ChangePasswordRequest(BaseModel):
    old_password: str
    new_password: str

class PasswordResetRequest(BaseModel):
    email: EmailStr

class PasswordResetConfirm(BaseModel):
    token: str
    new_password: str

# Seller application (frontend /auth/seller-apply)
class SellerApplicationCreate(BaseModel):
    email: EmailStr
    full_name: Optional[str] = None
    company_name: Optional[str] = None
    phone: Optional[str] = None
    note: Optional[str] = None

# Email-only seller OTP onboarding
class SellerOTPRequest(BaseModel):
    email: EmailStr

class SellerOTPVerify(BaseModel):
    email: EmailStr
    otp: str

class SetPasswordFirstTime(BaseModel):
    new_password: str
