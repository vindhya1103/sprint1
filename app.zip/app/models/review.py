
from sqlalchemy import Column, BigInteger, Integer, String, Text, Date, Boolean, ForeignKey
from sqlalchemy.orm import relationship
from app.models.base import Base

class Review(Base):
    __tablename__ = "reviews"
    id = Column(BigInteger, primary_key=True)
    product_id = Column(BigInteger, ForeignKey("products.id", ondelete="CASCADE"), index=True, nullable=False)
    rating = Column(Integer, nullable=True)
    review_title = Column(String(512), nullable=True)
    review_text = Column(Text, nullable=False)
    review_date = Column(Date, nullable=True)
    reviewer_name = Column(String(256), nullable=True)
    verified_purchase = Column(Boolean, nullable=False, default=False)
    helpful_votes = Column(Integer, nullable=False, default=0)
    source = Column(String(64), nullable=True)

    product = relationship("Product", backref="reviews")
