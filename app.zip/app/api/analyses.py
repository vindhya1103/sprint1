
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from sqlalchemy import select
from typing import List
from app.db.session import get_db
from app.models.analysis import Analysis
from app.schemas.analysis import AnalysisCreate, AnalysisOut

router = APIRouter()

@router.post("/", response_model=dict)
def upsert_analysis(payload: AnalysisCreate, db: Session = Depends(get_db)):
    a = db.execute(select(Analysis).where(Analysis.review_id == payload.review_id)).scalar_one_or_none()
    if a:
        a.summary = payload.summary
        a.verdict = payload.verdict
        a.pros = payload.pros
        a.cons = payload.cons
        a.sentiment = payload.sentiment
        a.key_themes = payload.key_themes
        a.raw_output = payload.raw_output
        db.add(a)
        action = "updated"
    else:
        a = Analysis(
            review_id=payload.review_id, summary=payload.summary, verdict=payload.verdict,
            pros=payload.pros, cons=payload.cons, sentiment=payload.sentiment,
            key_themes=payload.key_themes, raw_output=payload.raw_output
        )
        db.add(a)
        action = "created"
    db.commit()
    return {"status": "ok", "action": action}

@router.get("/{review_id}", response_model=AnalysisOut)
def get_analysis(review_id: int, db: Session = Depends(get_db)):
    a = db.execute(select(Analysis).where(Analysis.review_id == review_id)).scalar_one_or_none()
    if not a:
        raise HTTPException(404, "Analysis not found")
    return AnalysisOut(
        review_id=a.review_id, summary=a.summary, verdict=a.verdict, pros=a.pros,
        cons=a.cons, sentiment=a.sentiment, key_themes=a.key_themes
    )

@router.post("/bulk", response_model=dict)
def bulk_upsert(items: List[AnalysisCreate], db: Session = Depends(get_db)):
    created, updated = 0, 0
    for payload in items:
        a = db.query(Analysis).filter(Analysis.review_id == payload.review_id).first()
        if a:
            a.summary = payload.summary
            a.verdict = payload.verdict
            a.pros = payload.pros
            a.cons = payload.cons
            a.sentiment = payload.sentiment
            a.key_themes = payload.key_themes
            a.raw_output = payload.raw_output
            updated += 1
        else:
            db.add(Analysis(
                review_id=payload.review_id, summary=payload.summary, verdict=payload.verdict,
                pros=payload.pros, cons=payload.cons, sentiment=payload.sentiment,
                key_themes=payload.key_themes, raw_output=payload.raw_output
            ))
            created += 1
    db.commit()
    return {"created": created, "updated": updated}
