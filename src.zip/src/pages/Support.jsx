
// src/pages/Support.jsx
import { useEffect, useMemo, useState } from "react";
import Header from "../components/Header";
import { getJSON } from "../api";
import { useAuth } from "../auth/AuthContext";

/** ---------- Mini sparkline (SVG) for severe counts per date ---------- */
function Sparkline({ series, width = 120, height = 36 }) {
  // series: [{date: 'YYYY-MM-DD', count: n}, ...] sorted ASC
  if (!Array.isArray(series) || series.length === 0) {
    return <span className="muted">no severe activity</span>;
  }
  const pad = { l: 8, r: 8, t: 6, b: 6 };
  const xs = series.map(
    (_, i) => pad.l + (i * (width - pad.l - pad.r)) / Math.max(1, series.length - 1)
  );
  const max = Math.max(1, ...series.map((s) => Number(s.count) || 0));
  const yScale = (v) => height - pad.b - (Number(v) * (height - pad.t - pad.b)) / max;
  const pts = series.map((s, i) => [xs[i], yScale(Number(s.count) || 0)]);
  const path = pts.map((p, i) => (i === 0 ? `M ${p[0]} ${p[1]}` : `L ${p[0]} ${p[1]}`)).join(" ");
  const last = series[series.length - 1];

  return (
    <svg width={width} height={height} aria-label="Severe trend">
      <path d={path} stroke="#f87171" strokeWidth="2.0" fill="none" />
      <circle cx={pts[pts.length - 1][0]} cy={pts[pts.length - 1][1]} r="2.8" fill="#34d399" />
      <text x={width - 4} y={13} fontSize="10.5" fill="#cbd5e1" textAnchor="end">
        {Number(last?.count) || 0}
      </text>
    </svg>
  );
}

/** ---------- Tiny colored dot ---------- */
function Dot({ color = "#22c55e", size = 8 }) {
  return (
    <span
      style={{
        display: "inline-block",
        width: size,
        height: size,
        borderRadius: "50%",
        background: color,
      }}
      aria-hidden
    />
  );
}

/** ---------- Chip badge (tone variants) ---------- */
function Chip({ children, tone = "default" }) {
  const tones =
    {
      default: { bg: "rgba(148,163,184,.12)", bd: "rgba(148,163,184,.35)", fg: "#cbd5e1" },
      pos: { bg: "rgba(34,197,94,.12)", bd: "rgba(34,197,94,.35)", fg: "#34d399" },
      neu: { bg: "rgba(234,179,8,.12)", bd: "rgba(234,179,8,.35)", fg: "#eab308" },
      neg: { bg: "rgba(239,68,68,.12)", bd: "rgba(239,68,68,.35)", fg: "#f87171" },
      info: { bg: "rgba(59,130,246,.12)", bd: "rgba(59,130,246,.35)", fg: "#7aa2ff" },
    }[tone] || { bg: "rgba(148,163,184,.12)", bd: "rgba(148,163,184,.35)", fg: "#cbd5e1" };

  return (
    <span
      style={{
        display: "inline-flex",
        alignItems: "center",
        gap: 6,
        padding: "5px 10px",
        borderRadius: 999,
        border: `1px solid ${tones.bd}`,
        background: tones.bg,
        color: tones.fg,
        fontSize: ".9rem",
        lineHeight: 1,
      }}
    >
      {children}
    </span>
  );
}

/** ---------- Thicker severity progress bar ---------- */
function SeverityBar({ value = 0, max = 1 }) {
  const pct = Math.min(100, Math.round((Number(value) / Math.max(1, Number(max))) * 100));
  return (
    <div
      style={{
        height: 7,
        borderRadius: 999,
        background: "rgba(255,255,255,.08)",
        position: "relative",
        overflow: "hidden",
      }}
      aria-label={`Severity ${value} of ${max}`}
    >
      <div
        style={{
          width: `${pct}%`,
          height: "100%",
          background: pct === 0 ? "#22c55e" : pct <= 40 ? "#eab308" : "#ef4444",
          transition: "width .2s ease",
        }}
      />
    </div>
  );
}

export default function Support() {
  const { user, refreshMe } = useAuth();

  const [ready, setReady] = useState(false);
  const [flash, setFlash] = useState("");

  // Sellers
  const [sellers, setSellers] = useState([]);
  const [sellerQuery, setSellerQuery] = useState("");
  const [activeSeller, setActiveSeller] = useState(null);

  // Products
  const [products, setProducts] = useState([]);
  const [productQuery, setProductQuery] = useState("");
  const [activeProduct, setActiveProduct] = useState(null);

  // Severe reviews
  const [urgent, setUrgent] = useState([]);

  /** Load sellers (team scoped) */
  useEffect(() => {
    (async () => {
      const me = user || (await refreshMe());
      if (!me || (me.role !== "support" && me.role !== "admin")) {
        setFlash("You must be logged in as support or admin.");
        setReady(true);
        return;
      }
      try {
        const list = await getJSON("/support/me/sellers");
        setSellers(Array.isArray(list) ? list : []);
      } catch (e) {
        setFlash(e?.message || "Failed to load sellers.");
      } finally {
        setReady(true);
      }
    })();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  /** When seller selected → load products */
  useEffect(() => {
    setProducts([]);
    setActiveProduct(null);
    setUrgent([]);
    setFlash("");
    if (!activeSeller) return;
    (async () => {
      try {
        const rows = await getJSON(`/support/seller/${activeSeller.id}/products`);
        setProducts(Array.isArray(rows) ? rows : []);
      } catch (e) {
        setFlash(e?.message || "Failed to load products for seller.");
      }
    })();
  }, [activeSeller]);

  /** When product selected → load severe reviews */
  useEffect(() => {
    setUrgent([]);
    setFlash("");
    if (!activeProduct) return;
    (async () => {
      try {
        const res = await getJSON(`/support/product/${activeProduct.id}/urgent`);
        setUrgent(Array.isArray(res?.items) ? res.items : []);
      } catch (e) {
        setFlash(e?.message || "Failed to load severe reviews for product.");
      }
    })();
  }, [activeProduct]);

  /** Filters */
  const filteredSellers = useMemo(() => {
    const q = sellerQuery.trim().toLowerCase();
    if (!q) return sellers;
    return sellers.filter(
      (s) =>
        String(s.name || "").toLowerCase().includes(q) ||
        String(s.external_id || "").toLowerCase().includes(q)
    );
  }, [sellers, sellerQuery]);

  const filteredProducts = useMemo(() => {
    const q = productQuery.trim().toLowerCase();
    if (!q) return products;
    return products.filter(
      (p) =>
        String(p.product_title || "").toLowerCase().includes(q) ||
        String(p.brand || "").toLowerCase().includes(q) ||
        String(p.category || "").toLowerCase().includes(q)
    );
  }, [products, productQuery]);

  /** Compute max severity for progress scaling */
  const maxSeverity = useMemo(() => {
    const arr = filteredProducts.map((p) => Number(p.severe_total) || 0);
    return arr.length ? Math.max(...arr) : 1;
  }, [filteredProducts]);

  if (!ready) {
    return (
      <div>
        <Header />
        <main className="container" style={{ padding: 24 }}>
          <p className="hint">Loading…</p>
        </main>
      </div>
    );
  }

  return (
    <div>
      <Header />
      <main className="container support-wrap">
        <style>{`
          :root {
            --bg: #0b1020; --bg2: #0e1630;
            --text: #e5e7eb; --muted: #9fb0d1;
            --card: #0f172a; --cardBorder: #1f2937;
            --accent: #3b82f6; --accent600: #2563eb;
            --pos: #22c55e; --neu: #eab308; --neg: #ef4444;
          }
          .support-wrap {
            padding: 20px; color: var(--text);
            background: radial-gradient(1200px 800px at 20% -10%, var(--bg2), var(--bg));
          }

          /* Top-level: narrow Sellers | Main (which has Products | Reviews side-by-side) */
          .columns {
            display: grid; grid-template-columns: 260px 1fr; gap: 14px;
          }
          @media (max-width: 1100px) { .columns { grid-template-columns: 1fr; } }

          /* Inside Main: Products (left) & Reviews (right) */
          .main-split {
            display: grid; grid-template-columns: 1fr 1fr; gap: 14px;
          }
          @media (max-width: 1100px) { .main-split { grid-template-columns: 1fr; } }

          .page-title { margin: 0 0 12px; font-size: 1.5rem; letter-spacing: -.2px; }
          .section-title { margin: 0 0 10px; font-weight: 700; letter-spacing: -.2px; }

          /* Card */
          .card {
            background: linear-gradient(180deg, rgba(255,255,255,.02), rgba(255,255,255,.01));
            border: 1px solid var(--cardBorder);
            border-radius: 12px;
            box-shadow: 0 1px 3px rgba(0,0,0,.25);
            padding: 14px;
          }
          .muted { color: var(--muted); }
          .hint  { color: var(--muted); margin-top: 6px; }

          /* Search bars */
          .search {
            display: flex; align-items: center; gap: 8px;
            background: var(--card); border: 1px solid var(--cardBorder);
            border-radius: 10px; padding: 8px 10px; margin-bottom: 8px;
          }
          .search input {
            flex: 1; background: transparent; border: none; outline: none; color: var(--text);
            font-size: .95rem;
          }

          /* Sellers list */
          .seller-list { list-style: none; padding: 0; margin: 0; display: grid; gap: 8px; }
          .seller-row {
            width: 100%; text-align: left; display: flex; align-items: center; justify-content: space-between; gap: 10px;
            padding: 8px 10px; border-radius: 10px; border: 1px solid var(--cardBorder);
            background: #0f1a33; cursor: pointer;
            transition: background .12s, border-color .12s;
          }
          .seller-row:hover { background: #111b33; border-color: #2a3b65; }
          .seller-row.active { border-color: #7c6cff; box-shadow: 0 0 0 2px rgba(124,108,255,.22) inset; }
          .seller-id { opacity: .95; font-size: .95rem; }
          .pill-count {
            display: inline-flex; align-items: center; gap: 6px;
            padding: 3px 8px; border-radius: 999px;
            background: rgba(59,130,246,.12); border: 1px solid rgba(59,130,246,.35); color: #7aa2ff;
            font-size: .85rem;
          }

          /* Product rows (compact) */
          .product-list { list-style: none; padding: 0; margin: 0; display: grid; gap: 10px; }
          .row-btn {
            width: 100%;
            text-align: left;
            display: grid;
            grid-template-columns: 1fr 140px;
            align-items: center;
            gap: 10px;
            padding: 10px 12px;
            border-radius: 10px;
            border: 1px solid var(--cardBorder);
            background: #0f1a33;
            cursor: pointer;
            transition: transform .08s ease, box-shadow .12s ease, border-color .12s ease, background .12s ease;
          }
          .row-btn:hover {
            transform: translateY(-1px);
            border-color: #2a3b65;
            box-shadow: 0 6px 16px rgba(0,0,0,.25);
            background: #111b33;
          }
          .row-btn.active {
            border-color: #7c6cff;
            box-shadow: 0 0 0 2px rgba(124,108,255,.22) inset;
          }
          .p-title { font-weight: 700; margin: 0 0 4px; color: #fff; font-size: .95rem; }
          .p-meta  { margin: 0; color: var(--muted); font-size: .85rem; }
          .meta-line { display: flex; align-items: center; gap: 8px; flex-wrap: wrap; }
          .severe-dot { margin-left: 6px; }
          .progress-wrap { margin-top: 8px; }

          /* Severe table: scrolls to stay in view */
          .table-scroll {
            max-height: 55vh;
            overflow-y: auto;
            border: 1px solid var(--cardBorder);
            border-radius: 10px;
            background: #0f1a33;
          }
          .table {
            width: 100%; border-collapse: collapse; font-size: .9rem;
          }
          .table thead th {
            position: sticky; top: 0;
            background: rgba(255,255,255,.03);
            backdrop-filter: blur(2px);
            border-bottom: 1px solid var(--cardBorder);
            padding: 10px; text-align: left; color: #cbd5e1;
            z-index: 1;
          }
          .table tbody td {
            padding: 10px; border-bottom: 1px solid rgba(255,255,255,.06);
            vertical-align: top;
          }
          .table tr:hover td { background: rgba(255,255,255,.02); }
        `}</style>

        <h3 className="page-title">Customer Support Console</h3>
        {flash && <p className="hint">{flash}</p>}

        {/* Sellers | Main */}
        <div className="columns">
          {/* Sellers column (narrow) */}
          <aside className="card" aria-label="Sellers list">
            <h4 className="section-title">My Sellers</h4>

            <div className="search" role="search" aria-label="Search sellers">
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" aria-hidden="true">
                <circle cx="11" cy="11" r="7" stroke="currentColor" strokeWidth="2" />
                <line x1="16.65" y1="16.65" x2="21" y2="21" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
              </svg>
              <input
                value={sellerQuery}
                onChange={(e) => setSellerQuery(e.target.value)}
                placeholder="Search seller id or name…"
              />
            </div>

            {!filteredSellers?.length && <p className="hint">No sellers under your team.</p>}

            <ul className="seller-list">
              {filteredSellers.map((s) => (
                <li key={s.id}>
                  <button
                    className={`seller-row ${activeSeller?.id === s.id ? "active" : ""}`}
                    onClick={() => setActiveSeller(s)}
                    title="View seller products"
                  >
                    <span className="seller-id">
                      <strong>{s.external_id}</strong> — {s.name}
                    </span>
                    <span className="pill-count">{Number(s.products) || 0} products</span>
                  </button>
                </li>
              ))}
            </ul>
          </aside>

          {/* Main: Products (left) | Severe Reviews (right) */}
          <div className="main-split">
            {/* Products column (compact) */}
            <section className="card" aria-label="Seller products">
              <h4 className="section-title">
                Seller Products{activeSeller ? ` — ${activeSeller.name}` : ""}
              </h4>

              <div className="search" role="search" aria-label="Search products">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" aria-hidden="true">
                  <circle cx="11" cy="11" r="7" stroke="currentColor" strokeWidth="2" />
                  <line x1="16.65" y1="16.65" x2="21" y2="21" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
                </svg>
                <input
                  value={productQuery}
                  onChange={(e) => setProductQuery(e.target.value)}
                  placeholder="Search product, brand, category…"
                />
              </div>

              {!activeSeller && <p className="hint">Pick a seller.</p>}
              {activeSeller && filteredProducts.length === 0 && (
                <p className="hint">No products for this seller.</p>
              )}

              {activeSeller && filteredProducts.length > 0 && (
                <ul className="product-list">
                  {filteredProducts.map((p) => {
                    const severeTotal = Number(p.severe_total) || 0;
                    const tone = severeTotal === 0 ? "pos" : severeTotal <= 2 ? "neu" : "neg";
                    return (
                      <li key={p.id}>
                        <button
                          className={`row-btn ${activeProduct?.id === p.id ? "active" : ""}`}
                          onClick={() => setActiveProduct(p)}
                          title="Show severe reviews for this product"
                        >
                          <div>
                            <p className="p-title">{p.product_title}</p>
                            <div className="meta-line">
                              <p className="p-meta">
                                {p.brand || "—"}
                                {p.category ? ` · ${p.category}` : ""}
                                {p.subtype ? ` · ${p.subtype}` : ""}
                              </p>
                              <Chip tone={tone}>
                                severe: <strong>{severeTotal}</strong>
                                <span className="severe-dot">
                                  <Dot
                                    color={
                                      tone === "pos" ? "var(--pos)" : tone === "neu" ? "var(--neu)" : "var(--neg)"
                                    }
                                    size={8}
                                  />
                                </span>
                              </Chip>
                            </div>
                            <div className="progress-wrap">
                              <SeverityBar value={severeTotal} max={maxSeverity} />
                            </div>
                          </div>
                          <div style={{ justifySelf: "end" }}>
                            <Sparkline series={p.sparkline} />
                          </div>
                        </button>
                      </li>
                    );
                  })}
                </ul>
              )}
            </section>

            {/* Severe Reviews column (beside products) */}
            <section className="card" aria-label="Severe reviews">
              <h4 className="section-title">
                Severe Reviews{activeProduct ? ` — ${activeProduct.product_title}` : ""}
              </h4>

              {!activeSeller && <p className="hint">Pick a seller first.</p>}
              {activeSeller && !activeProduct && <p className="hint">Pick a product.</p>}
              {activeProduct && urgent.length === 0 && <p className="hint">No severe reviews found.</p>}

              {activeProduct && urgent.length > 0 && (
                <div className="table-scroll" role="region" aria-label="Severe reviews table">
                  <table className="table">
                    <thead>
                      <tr>
                        <th>Date</th>
                        <th>Rating</th>
                        <th>Sentiment</th>
                        <th>Severity</th>
                        <th>Top issue</th>
                        <th>Excerpt</th>
                        <th>Helpful</th>
                      </tr>
                    </thead>
                    <tbody>
                      {urgent.map((r) => {
                        const s = String(r.sentiment || "").toLowerCase();
                        const tone = s.includes("pos") ? "pos" : s.includes("neg") ? "neg" : "neu";
                        const sevTone =
                          Number(r.severity) >= 3 ? "neg" : Number(r.severity) === 2 ? "neu" : "pos";
                        return (
                          <tr key={r.review_id}>
                            <td>{r.review_date || "—"}</td>
                            <td>{r.rating ?? "—"}</td>
                            <td>
                              <Chip tone={tone}>
                                <Dot
                                  color={tone === "pos" ? "var(--pos)" : tone === "neu" ? "var(--neu)" : "var(--neg)"}
                                  size={8}
                                />
                                {r.sentiment}
                              </Chip>
                            </td>
                            <td>
                              <Chip tone={sevTone}>{r.severity}</Chip>
                            </td>
                            <td>{r.top_issue || "—"}</td>
                            <td
                              title={r.excerpt}
                              style={{
                                maxWidth: 360,
                                whiteSpace: "nowrap",
                                overflow: "hidden",
                                textOverflow: "ellipsis",
                              }}
                            >
                              {r.excerpt}
                            </td>
                            <td>{r.helpful_votes}</td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              )}
            </section>
          </div>
        </div>
      </main>
    </div>
  );
}
