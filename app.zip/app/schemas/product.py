

# backend/app/schemas/product.py
from pydantic import BaseModel
from typing import Optional

class ProductCreate(BaseModel):
    sku: str
    product_title: str
    brand: Optional[str] = None
    category: str = "Electronics"
    subtype: Optional[str] = None
    price: Optional[float] = None
    external_id: Optional[str] = None
    source: Optional[str] = None
    seller_id: Optional[int] = None

class ProductOut(BaseModel):
    id: int
    sku: Optional[str] = None        # optional for safety
    product_title: str
    brand: Optional[str] = None
    category: str
    price: Optional[float] = None
    source: Optional[str] = None
    external_id: Optional[str] = None
    subtype: Optional[str] = None

class SellerProductUpdate(BaseModel):
    sku: Optional[str] = None
    product_title: Optional[str] = None
    brand: Optional[str] = None
    category: Optional[str] = None
    subtype: Optional[str] = None
    price: Optional[float] = None
    external_id: Optional[str] = None
    source: Optional[str] = None
    seller_id: Optional[int] = None  # admin-only
