
# backend/app/core/security.py
from typing import Tuple, Dict, Any
import os, base64, hashlib, hmac, secrets
from datetime import datetime, timedelta, timezone
from jose import jwt

# ---- Password hashing (PBKDF2-SHA256) ----
# Stored format: pbkdf2$iterations$salt$hash
PBKDF2_ITERATIONS = 180_000

def _pbkdf2_hash(password: str, salt: bytes, iterations: int = PBKDF2_ITERATIONS) -> bytes:
    return hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt, iterations)

def hash_password(password: str) -> str:
    salt = os.urandom(16)
    digest = _pbkdf2_hash(password, salt, PBKDF2_ITERATIONS)
    return f"pbkdf2${PBKDF2_ITERATIONS}${base64.b64encode(salt).decode()}${base64.b64encode(digest).decode()}"

def verify_password(password: str, stored: str) -> bool:
    try:
        scheme, iter_s, salt_b64, hash_b64 = stored.split("$")
        if scheme != "pbkdf2":
            return False
        iterations = int(iter_s)
        salt = base64.b64decode(salt_b64)
        expected = base64.b64decode(hash_b64)
        actual = _pbkdf2_hash(password, salt, iterations)
        return hmac.compare_digest(actual, expected)
    except Exception:
        return False

# ---- JWT helpers ----
def create_access_token(
    subject: str,
    expires_minutes: int,
    secret: str,
    algorithm: str,
    extra_claims: Dict[str, Any] | None = None
) -> str:
    exp = datetime.now(timezone.utc) + timedelta(minutes=expires_minutes)
    payload: Dict[str, Any] = {"sub": subject, "exp": exp}
    if extra_claims:
        payload.update(extra_claims)
    return jwt.encode(payload, secret, algorithm=algorithm)

def decode_access_token(token: str, secret: str, algorithms: Tuple[str, ...]) -> Dict[str, Any]:
    return jwt.decode(token, secret, algorithms=list(algorithms))

# ---- Admin helper ----
def generate_temp_password(length: int = 12) -> str:
    alphabet = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"
    return "".join(secrets.choice(alphabet) for _ in range(length))
