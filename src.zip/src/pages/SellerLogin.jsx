
// src/pages/SellerLogin.jsx
import { useState } from "react";
import Header from "../components/Header";
import { useAuth } from "../auth/AuthContext";
import { postJSON } from "../api";

export default function SellerLogin() {
  const { login, loginWithToken } = useAuth();
  const [tab, setTab] = useState("password"); // "password" | "otp"
  const [form, setForm] = useState({ email: "", password: "", otp: "" });
  const [msg, setMsg] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  function onChange(e) {
    const { name, value } = e.target;
    setForm(prev => ({ ...prev, [name]: value }));
    setError(""); setMsg("");
  }

  async function onLoginPassword(e) {
    e.preventDefault();
    setError(""); setMsg(""); setLoading(true);
    try {
      await login(form.email.trim(), form.password);
      window.location.href = "/seller";
    } catch (err) {
      setError(err?.message || "Login failed.");
    } finally {
      setLoading(false);
    }
  }

  async function onVerifyOTP(e) {
    e.preventDefault();
    setError(""); setMsg(""); setLoading(true);
    try {
      const payload = { email: form.email.trim(), otp: form.otp.trim() };
      if (!payload.email || !payload.otp) {
        setError("Enter your email and the OTP you received.");
        setLoading(false);
        return;
      }
      const res = await postJSON("/auth/seller/otp/verify", payload);
      await loginWithToken(res.access_token);
      window.location.href = "/seller";
    } catch (err) {
      setError(err?.message || "OTP verification failed.");
    } finally {
      setLoading(false);
    }
  }

  return (
    <div>
      <Header />
      <div style={{ padding: 24, color: '#fff' }}>
        <div style={{ display: "flex", gap: 8, marginBottom: 12 }}>
          <button onClick={() => setTab("password")} style={{ padding: 8, border: '1px solid #ccc' }}>
            Password login
          </button>
          <button onClick={() => setTab("otp")} style={{ padding: 8, border: '1px solid #ccc' }}>
            First-time: OTP login
          </button>
        </div>

        {tab === "password" ? (
          <form onSubmit={onLoginPassword} noValidate>
            <h3>Seller login</h3>
            <div>
              <input type="email" name="email" placeholder="Email" value={form.email} onChange={onChange} />
            </div>
            <div>
              <input type="password" name="password" placeholder="Password" value={form.password} onChange={onChange} />
            </div>
            <button type="submit" disabled={loading}>{loading ? "Signing in..." : "Login"}</button>
          </form>
        ) : (
          <form onSubmit={onVerifyOTP} noValidate>
            <h3>First-time login with OTP (email)</h3>
            <p className="muted">
              OTP is emailed to you when the admin approves your seller application.
              If you didn’t receive it or it expired, please contact the admin to resend.
            </p>
            <div>
              <input type="email" name="email" placeholder="Email" value={form.email} onChange={onChange} />
            </div>
            <div>
              <input type="text" name="otp" placeholder="Enter OTP" value={form.otp} onChange={onChange} />
            </div>
            <button type="submit" disabled={loading}>
              {loading ? "Verifying..." : "Verify OTP"}
            </button>
          </form>
        )}

        {msg && <div style={{ marginTop: 10, color: "#b6ffcc" }}>{msg}</div>}
        {error && <div style={{ marginTop: 10, color: "#ffd7d7" }}>{error}</div>}
      </div>
    </div>
  );
}
