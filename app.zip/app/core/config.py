
# backend/app/core/config.py
from pydantic_settings import BaseSettings, SettingsConfigDict
from pydantic import field_validator
from typing import List, Any
import ast

class Settings(BaseSettings):
    app_env: str = "dev"
    app_port: int = 8001

    database_url: str
    cors_origins: List[str] = ["http://localhost:5173", "http://127.0.0.1:5173"]

    jwt_secret: str
    jwt_algorithm: str = "HS256"
    jwt_expire_minutes: int = 60 * 12

    # Email / invite link config
    public_app_url: str | None = None  # e.g., http://localhost:5173
    emails_enabled: bool = False

    smtp_host: str | None = None       # e.g., smtp.gmail.com / smtp.office365.com
    smtp_port: int | None = None       # e.g., 587
    smtp_user: str | None = None
    smtp_pass: str | None = None
    smtp_use_tls: bool = True

    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
    )

    @field_validator("cors_origins", mode="before")
    @classmethod
    def parse_cors(cls, v: Any):
        if isinstance(v, str):
            try:
                return list(ast.literal_eval(v))
            except Exception:
                return [v]
        return v
