
// src/pages/ProductDetails.jsx
import React, { useEffect, useMemo, useRef, useState } from "react";
import { useParams, useNavigate, useLocation, Link } from "react-router-dom";
import "../pages/home.css";
import { getJSON, postJSON } from "../api";

/* ---------- Small UI bits ---------- */
const StarRating = ({ value = 0 }) => (
  <span className="star-rating">
    {[1, 2, 3, 4, 5].map((i) => (
      <span
        key={i}
        style={{
          color: i <= value ? "#FFA41C" : "#6b7280",
          fontSize: "18px",
          marginRight: 2,
        }}
      >
        ★
      </span>
    ))}
  </span>
);

const Section = ({ title, items }) => (
  <div className="pd-section-card">
    <h3 className="pd-section-title">{title}</h3>
    <ul className="pd-list">
      {(items || []).length === 0 ? (
        <li className="pd-list-empty">—</li>
      ) : (
        items.map((i, idx) => <li key={idx}>{i}</li>)
      )}
    </ul>
  </div>
);

/* ---------- FAQ helpers ---------- */
function stripPrefix(s) {
  if (!s || typeof s !== "string") return s;
  return s.replace(/^\s*(Q:|A:)\s*/i, "");
}

/** Normalize + DEDUPE [{question, answer}] from various backend shapes */
function normalizeFaqs(raw) {
  const base =
    (Array.isArray(raw) && raw) ||
    (Array.isArray(raw?.items) && raw.items) ||
    (Array.isArray(raw?.data) && raw.data) ||
    (Array.isArray(raw?.results) && raw.results) ||
    (Array.isArray(raw?.faqs) && raw.faqs) ||
    (Array.isArray(raw?.faq) && raw.faq) ||
    [];

  const toTime = (s) => {
    if (!s) return 0;
    const t = new Date(s).getTime();
    return Number.isFinite(t) ? t : 0;
  };

  const byQuestion = new Map();

  for (const f of base) {
    const questionRaw =
      f.question ??
      f.question_text ??
      f.questionTitle ??
      f.q_text ??
      f.q ??
      f.faq_question ??
      f.title ??
      f.text ??
      f?.faq?.question ??
      f?.faq?.question_text ??
      "";

    const askedAt = toTime(f.asked_at);

    let bestAnswerText = "";
    let bestAnsweredAt = 0;
    if (Array.isArray(f.answers) && f.answers.length > 0) {
      for (const ans of f.answers) {
        const txt = ans.answer ?? ans.answer_text ?? "";
        const at = toTime(ans.answered_at);
        if (txt && at >= bestAnsweredAt) {
          bestAnswerText = txt;
          bestAnsweredAt = at;
        }
      }
    } else {
      const flatAns =
        f.answer ??
        f.answer_text ??
        f.answerBody ??
        f.a_text ??
        f.a ??
        f.faq_answer ??
        f.description ??
        f?.faq?.answer ??
        f?.faq?.answer_text ??
        "";
      bestAnswerText = flatAns || bestAnswerText;
    }

    const normalizedQuestion = stripPrefix(String(questionRaw ?? "")).trim();
    const normalizedAnswer = stripPrefix(String(bestAnswerText ?? "")).trim();

    const current = {
      question: normalizedQuestion,
      answer: normalizedAnswer,
      askedAt,
      answeredAt: bestAnsweredAt,
      hasAnswer: !!normalizedAnswer,
    };

    const prev = byQuestion.get(normalizedQuestion);
    if (!prev) {
      byQuestion.set(normalizedQuestion, current);
    } else {
      const prefer =
        (!prev.hasAnswer && current.hasAnswer) ||
        (prev.hasAnswer && current.hasAnswer && current.answeredAt > prev.answeredAt) ||
        (!prev.hasAnswer && !current.hasAnswer && current.askedAt > prev.askedAt);
      if (prefer) byQuestion.set(normalizedQuestion, current);
    }
  }

  const items = Array.from(byQuestion.values())
    .sort((a, b) => b.answeredAt - a.answeredAt || b.askedAt - a.askedAt)
    .map(({ question, answer }) => ({ question, answer }))
    .filter((it) => it.question?.trim() || it.answer?.trim());

  return items;
}

/* ---------- FAQ UI ---------- */
function FAQItem({ q, a, isOpen, onToggle }) {
  const question = (q ?? "").trim();
  const answer = (a ?? "").trim();

  return (
    <div className="faq-item pd-card">
      <button className="faq-question" onClick={onToggle}>
        <span className="faq-q-text">{question || "—"}</span>
        <span className="faq-toggle">{isOpen ? "▲" : "▼"}</span>
      </button>
      {isOpen && (
        <div className="faq-answer">
          <p style={{ margin: 0 }}>{answer || "No answer yet."}</p>
        </div>
      )}
    </div>
  );
}

function FAQSection({ faqs, loading, error, onReload, showImportButtons = false }) {
  const items = Array.isArray(faqs) ? faqs : [];
  const initialCount = 2;
  const step = 5;

  const [query, setQuery] = useState("");
  const [visibleCount, setVisibleCount] = useState(initialCount);
  const [openIndex, setOpenIndex] = useState(-1);

  useEffect(() => {
    setVisibleCount(initialCount);
    setOpenIndex(-1);
  }, [faqs, query]);

  const filtered = items.filter(
    (x) =>
      (x.question || "").toLowerCase().includes(query.toLowerCase()) ||
      (x.answer || "").toLowerCase().includes(query.toLowerCase())
  );

  const visible = filtered.slice(0, visibleCount);
  const hasMore = visible.length < filtered.length;

  async function handleImportQuestions() {
    try {
      const pid = Number(window?.location?.pathname?.split("/").pop());
      const payload = {
        product_id: isNaN(pid) ? undefined : pid,
        questions: [
          { question: "What is the warranty period?" },
          { question: "Is this compatible with iOS and Android?" },
        ],
      };
      await postJSON("/faq/import/questions", payload);
      alert("Questions imported");
      onReload?.();
    } catch (e) {
      console.error(e);
      alert("Failed to import questions");
    }
  }

  async function handleImportAnswers() {
    try {
      const pid = Number(window?.location?.pathname?.split("/").pop());
      const payload = {
        product_id: isNaN(pid) ? undefined : pid,
        answers: [
          { question: "What is the warranty period?", answer: "12 months manufacturer warranty." },
          { question: "Is this compatible with iOS and Android?", answer: "Yes, fully compatible." },
        ],
      };
      await postJSON("/faq/import/answers", payload);
      alert("Answers imported");
      onReload?.();
    } catch (e) {
      console.error(e);
      alert("Failed to import answers");
    }
  }

  return (
    <div className="pd-section-card" id="faq" style={{ width: "100%" }}>
      <div className="pd-section-header">
        <h3 className="pd-section-title" style={{ margin: 0 }}>FAQs</h3>
        <div className="pd-actions">
          <button className="btn ghost" onClick={onReload} disabled={loading}>
            ⟳ Refresh
          </button>
          {showImportButtons && (
            <>
              <button className="btn ghost" onClick={handleImportQuestions} disabled={loading}>
                Import Questions
              </button>
              <button className="btn ghost" onClick={handleImportAnswers} disabled={loading}>
                Import Answers
              </button>
            </>
          )}
        </div>
      </div>

      <div style={{ marginTop: 10 }}>
        <input
          type="text"
          placeholder="Search FAQs..."
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          className="pd-input"
        />
      </div>

      {loading && <p className="pd-muted">Loading FAQs…</p>}
      {error && (
        <p className="pd-error">
          {error} &nbsp; <button className="btn ghost" onClick={onReload}>Try again</button>
        </p>
      )}

      {!loading && !error && filtered.length === 0 && <p className="pd-muted">No FAQs found</p>}

      {!loading && !error && visible.length > 0 && (
        <div style={{ marginTop: 10 }}>
          {visible.map((f, idx) => (
            <FAQItem
              key={`${f.question}-${idx}`}
              q={f.question}
              a={f.answer}
              isOpen={openIndex === idx}
              onToggle={() => setOpenIndex(openIndex === idx ? -1 : idx)}
            />
          ))}

          <div className="pd-actions" style={{ marginTop: 12 }}>
            {hasMore && (
              <button
                className="btn ghost"
                onClick={() => setVisibleCount((c) => c + step)}
                aria-label={`Show ${Math.min(step, filtered.length - visible.length)} more FAQs`}
              >
                Show more
              </button>
            )}
            {visibleCount > initialCount && (
              <button
                className="btn ghost"
                onClick={() => setVisibleCount(initialCount)}
                aria-label="Show fewer FAQs"
              >
                Show less
              </button>
            )}
          </div>
        </div>
      )}
    </div>
  );
}

/* ---------- Main Page ---------- */
export default function ProductDetails() {
  const { id } = useParams();
  const location = useLocation();
  const navigate = useNavigate();
  const pid = Number(id);

  const [product, setProduct] = useState(null);
  const [loadingProd, setLoadingProd] = useState(true);
  const [errorProd, setErrorProd] = useState(null);

  const [summaryData, setSummaryData] = useState(null);
  const [loadingSummary, setLoadingSummary] = useState(true);

  const [reviews, setReviews] = useState([]);
  const [loadingRev, setLoadingRev] = useState(true);
  const [errorRev, setErrorRev] = useState(null);

  const [showDetails, setShowDetails] = useState(true);

  const [showReviewForm, setShowReviewForm] = useState(false);
  const [reviewText, setReviewText] = useState("");
  const [reviewRating, setReviewRating] = useState(0);

  const [faqs, setFaqs] = useState([]);
  const [faqLoading, setFaqLoading] = useState(false);
  const [faqError, setFaqError] = useState(null);

  const reviewsRef = useRef(null);

  // Fetch product details
  useEffect(() => {
    if (!Number.isFinite(pid) || pid <= 0) {
      setErrorProd("Invalid product id.");
      setLoadingProd(false);
      return;
    }
    let ignore = false;
    setLoadingProd(true);
    setErrorProd(null);
    getJSON(`/products/by-id/${pid}`)
      .then((p) => {
        if (!ignore) setProduct(p || null);
      })
      .catch((e) => {
        console.error("Failed to load product:", e);
        if (!ignore) setErrorProd(e.message || "Failed to load product");
      })
      .finally(() => {
        if (!ignore) setLoadingProd(false);
      });
    return () => { ignore = true; };
  }, [pid]);

  // Fetch buyer summary (optional)
  useEffect(() => {
    if (!Number.isFinite(pid) || pid <= 0) {
      setLoadingSummary(false);
      return;
    }
    let ignore = false;
    setLoadingSummary(true);
    getJSON(`/buyer/product/${pid}/summary`)
      .then((data) => { if (!ignore) setSummaryData(data || null); })
      .catch((e) => {
        console.warn("Buyer summary failed:", e);
        if (!ignore) setSummaryData(null);
      })
      .finally(() => { if (!ignore) setLoadingSummary(false); });
    return () => { ignore = true; };
  }, [pid]);

  // Fetch reviews
  useEffect(() => {
    if (!Number.isFinite(pid) || pid <= 0) {
      setErrorRev("Invalid product id.");
      setLoadingRev(false);
      return;
    }
    let ignore = false;
    setLoadingRev(true);
    setErrorRev(null);
    getJSON(`/reviews/product/${pid}`)
      .then((list) => { if (!ignore) setReviews(Array.isArray(list) ? list : []); })
      .catch((e) => {
        console.error("Failed to load reviews:", e);
        if (!ignore) setErrorRev(e.message || "Failed to load reviews");
      })
      .finally(() => { if (!ignore) setLoadingRev(false); });
    return () => { ignore = true; };
  }, [pid]);

  // Fetch FAQs (optional)
  useEffect(() => {
    if (!Number.isFinite(pid) || pid <= 0) return;
    let ignore = false;
    async function loadFaqs() {
      setFaqLoading(true);
      setFaqError(null);
      try {
        const data = await getJSON(`/faq/product/${pid}`);
        if (!ignore) setFaqs(normalizeFaqs(data));
      } catch (e) {
        console.error("Failed to load FAQs:", e);
        if (!ignore) setFaqError("Failed to load FAQs");
      } finally {
        if (!ignore) setFaqLoading(false);
      }
    }
    loadFaqs();
    return () => { ignore = true; };
  }, [pid]);

  // Scroll to reviews if location has #reviews
  useEffect(() => {
    if (location.hash === "#reviews" && reviewsRef.current) {
      const t = setTimeout(() => {
        reviewsRef.current.scrollIntoView({ behavior: "smooth", block: "start" });
      }, 100);
      return () => clearTimeout(t);
    }
  }, [location, loadingRev]);

  const reloadFaqs = async () => {
    try {
      setFaqLoading(true);
      setFaqError(null);
      const data = await getJSON(`/faq/product/${pid}`);
      setFaqs(normalizeFaqs(data));
    } catch (e) {
      console.error("Failed to reload FAQs:", e);
      setFaqError("Failed to load FAQs");
    } finally {
      setFaqLoading(false);
    }
  };

  const avgRating = useMemo(() => {
    const val = summaryData?.average_rating;
    return Number.isFinite(val) ? Number(val) : null;
  }, [summaryData]);

  const priceText = useMemo(() => {
    const val = product?.price;
    return val != null ? `₹${Number(val).toFixed(2)}` : "—";
  }, [product]);

  const name = useMemo(() => {
    const t = product?.product_title;
    const external = product?.external_id;
    return t || external || (product ? `#${product.id}` : "");
  }, [product]);

  async function handleSubmitReview() {
    if (reviewRating <= 0 || reviewText.trim() === "") {
      alert("Please give rating and write a review");
      return;
    }
    try {
      const isoDate = new Date().toISOString().slice(0, 10);
      const payload = {
        product_id: pid,
        rating: reviewRating,
        review_title: null,
        review_text: reviewText.trim(),
        review_date: isoDate,
        reviewer_name: null,
        verified_purchase: false,
        helpful_votes: 0,
        source: "web",
      };
      // NOTE: backend must implement POST /reviews/ to accept this payload
      const resp = await postJSON(`/reviews/`, payload);
      const newId = resp?.id ?? Math.floor(Math.random() * 1e9); // fallback id for optimistic UI
      setReviews([{ ...payload, id: newId }, ...reviews]);
      setReviewText("");
      setReviewRating(0);
      setShowReviewForm(false);
    } catch (e) {
      console.error(e);
      alert("Failed to submit review. Are you logged in as buyer/admin, and is POST /reviews implemented?");
    }
  }

  if (loadingProd) {
    return <p style={{ padding: 24 }}>Loading product…</p>;
  }
  if (errorProd) {
    return (
      <div className="pd-container">
        <p className="pd-error">Error: {errorProd}</p>
        <button className="btn ghost" onClick={() => navigate(-1)}>← Go Back</button>
      </div>
    );
  }
  if (!product) {
    return (
      <div className="pd-container">
        <p>No product found.</p>
        <button className="btn ghost" onClick={() => navigate(-1)}>← Go Back</button>
      </div>
    );
  }

  return (
    <div className="pd-container">
      {/* Scoped styles for Product Details */}
      <style>{`
        :root {
          --bg: #0b1020;
          --bg2: #0e1630;
          --text: #e5e7eb;
          --muted: #9fb0d1;
          --primary: #3b82f6;
          --primary-600: #2563eb;
          --card: #0f172a;
          --cardBorder: #1f2937;
          --success: #34d399;
          --warn: #FFA41C;
        }

        .pd-container {
          width: 100%;
          max-width: 1200px;
          margin: 0 auto;
          padding: 24px;
          color: var(--text);
        }

        .pd-breadcrumbs {
          margin-bottom: 16px;
        }

        /* Header layout */
        .pd-header {
          display: grid;
          grid-template-columns: 1.05fr 1fr;
          gap: 18px;
        }
        @media (max-width: 900px) {
          .pd-header {
            grid-template-columns: 1fr;
          }
        }

        .pd-card {
          background: linear-gradient(180deg, rgba(255,255,255,0.02), rgba(255,255,255,0.015));
          border: 1px solid var(--cardBorder);
          border-radius: 12px;
          box-shadow: 0 1px 3px rgba(0,0,0,.25);
        }

        .pd-media {
          height: 420px;
          display: grid;
          place-items: center;
          background: #0b1222;
          border-radius: 12px;
          overflow: hidden;
        }
        .pd-media img {
          width: 100%;
          height: 100%;
          object-fit: contain;
          background: #0b1222;
        }
        @media (max-width: 700px) {
          .pd-media { height: 320px; }
        }

        .pd-info {
          padding: 16px 16px 18px;
        }

        .pd-title {
          margin: 0 0 8px;
          font-size: 1.5rem;
          line-height: 1.2;
          letter-spacing: -0.2px;
        }

        .pd-meta {
          display: grid;
          grid-template-columns: 1fr 1fr;
          gap: 6px 12px;
        }
        @media (max-width: 600px) {
          .pd-meta { grid-template-columns: 1fr; }
        }
        .pd-meta p {
          margin: 0;
        }
        .pd-price {
          margin: 8px 0 10px;
          font-weight: 700;
          color: var(--success);
        }

        .pd-rating {
          display: inline-flex;
          align-items: center;
          gap: 6px;
          color: var(--muted);
          margin: 6px 0 10px;
        }
        .pd-rating .value {
          color: #fef3c7;
          font-weight: 600;
        }

        .pd-actions {
          display: flex;
          gap: 10px;
          align-items: center;
          flex-wrap: wrap;
          margin-top: 6px;
        }

        .btn {
          display: inline-flex; align-items: center; justify-content: center;
          height: 34px; padding: 0 14px; border-radius: 10px;
          border: 1px solid #2a3b65; background: #16223e;
          color: var(--text); text-decoration: none; cursor: pointer;
          transition: background .12s ease, border-color .12s ease, transform .08s ease;
          user-select: none;
        }
        .btn:hover { border-color: #3a56a3; background: #1a2a52; }
        .btn:active { transform: translateY(1px); }
        .btn.small { height: 32px; padding: 0 12px; font-size: .9rem; }
        .btn.primary { background: var(--primary); border-color: var(--primary-600); color: #fff; }
        .btn.primary:hover { background: var(--primary-600); }
        .btn.ghost { background: transparent; border-color: #2a3b65; }

        /* Section cards */
        .pd-section-grid {
          margin-top: 18px;
          display: grid;
          grid-template-columns: 1fr 1fr;
          gap: 16px;
        }
        @media (max-width: 900px) {
          .pd-section-grid { grid-template-columns: 1fr; }
        }

        .pd-section-card {
          background: linear-gradient(180deg, rgba(255,255,255,0.02), rgba(255,255,255,0.01));
          border: 1px solid var(--cardBorder);
          border-radius: 12px;
          padding: 14px 16px;
          box-shadow: 0 1px 3px rgba(0,0,0,.25);
        }

        .pd-section-title {
          margin: 0 0 10px;
          font-size: 1.1rem;
        }

        .pd-list {
          margin: 0; padding-left: 18px;
        }
        .pd-list li {
          margin: 4px 0;
        }
        .pd-list-empty {
          list-style: none;
          color: var(--muted);
        }

        .pd-summary-card, .pd-verdict-card {
          margin-top: 16px;
        }

        /* Reviews */
        .pd-reviews {
          margin-top: 22px;
        }
        .review-card {
          margin-top: 10px;
          padding: 12px;
          border: 1px solid var(--cardBorder);
          border-radius: 10px;
          background: rgba(255,255,255,0.02);
        }
        .review-card .stars {
          margin-bottom: 6px;
          color: #FFA41C;
        }
        .pd-input, textarea.pd-textarea {
          width: 100%;
          padding: 10px 12px;
          border-radius: 8px;
          border: 1px solid rgba(255,255,255,0.15);
          background: transparent;
          color: var(--text);
        }
        .pd-input::placeholder, .pd-textarea::placeholder {
          color: var(--muted);
        }

        /* FAQ */
        .faq-item {
          border: 1px solid rgba(255,255,255,0.15);
          border-radius: 8px;
          margin-top: 8px;
          overflow: hidden;
          background: rgba(255,255,255,0.02);
        }
        .faq-question {
          width: 100%;
          text-align: left;
          padding: 10px 12px;
          background: transparent;
          border: none;
          color: inherit;
          cursor: pointer;
          display: flex;
          align-items: center;
          justify-content: space-between;
          gap: 8px;
        }
        .faq-answer {
          padding: 10px 12px;
          border-top: 1px solid rgba(255,255,255,0.08);
        }

        .pd-muted { color: var(--muted); margin-top: 8px; }
        .pd-error { color: #f66; margin: 8px 0; }
      `}</style>

      <section className="pd-breadcrumbs">
        <Link to="/customer" className="btn small ghost">← Back to Customer</Link>
      </section>

      <div className="pd-header">
        {/* LEFT: image */}
        <div className="pd-media pd-card">
          <img
            className="product-image"
            src={product.image_url || "https://via.placeholder.com/800x600?text=Product"}
            alt={name}
            onError={(e) => { e.currentTarget.src = "https://via.placeholder.com/800x600?text=No+Image"; }}
          />
        </div>

        {/* RIGHT: info / actions / sections */}
        <div className="pd-info pd-card">
          <h2 className="pd-title">{name}</h2>

          <div className="pd-meta">
            <p><strong>Brand:</strong> {product.brand || "—"}</p>
            <p><strong>Category:</strong> {product.category || "—"}</p>
            <p><strong>Subtype:</strong> {product.subtype || "—"}</p>
            <p><strong>SKU:</strong> {product.sku || "—"}</p>
            <p><strong>External ID:</strong> {product.external_id || "—"}</p>
            <p><strong>Source:</strong> {product.source || "—"}</p>
          </div>

          <p className="pd-price"><strong>Price:</strong> {priceText}</p>

          {avgRating != null && (
            <p className="pd-rating">
              <StarRating value={Math.round(avgRating)} /> <span className="value">({avgRating.toFixed(1)})</span>
            </p>
          )}

          <div className="pd-actions">
            <button
              className="btn"
              onClick={() => setShowDetails(!showDetails)}
              style={{ color: "black", width: "auto" }}
            >
              {showDetails ? "Hide Details" : "Show Details"}
            </button>
            <Link to={`/product-details/${product.id}#reviews`} className="btn small ghost">
              Jump to reviews
            </Link>
          </div>

          {showDetails && (
            <>
              <div className="pd-section-grid">
                <Section title="Pros" items={summaryData?.pros?.map((x) => x.label)} />
                <Section title="Cons" items={summaryData?.cons?.map((x) => x.label)} />
              </div>

              <div className="pd-section-card pd-summary-card">
                <h3 className="pd-section-title">Summary</h3>
                {loadingSummary ? <p className="pd-muted">Loading summary…</p> : <p>{summaryData?.summary || "—"}</p>}
              </div>

              <div className="pd-section-card pd-verdict-card">
                <h3 className="pd-section-title">Verdict</h3>
                {loadingSummary ? <p className="pd-muted">Loading verdict…</p> : <p>{summaryData?.verdict || "—"}</p>}
              </div>
            </>
          )}
        </div>
      </div>

      {/* ---------- Reviews ---------- */}
      <div className="pd-reviews pd-section-card" id="reviews" ref={reviewsRef}>
        <h3 className="pd-section-title">Customer Reviews</h3>

        {loadingRev && <p className="pd-muted">Loading reviews…</p>}
        {errorRev && <p className="pd-error">Error: {errorRev}</p>}

        {!loadingRev && !errorRev && reviews.length === 0 ? (
          <p className="pd-muted">No reviews yet</p>
        ) : (
          !loadingRev &&
          !errorRev &&
          reviews.map((r) => (
            <div key={r.id} className="review-card">
              <div className="stars">
                {[1, 2, 3, 4, 5].map((i) => (
                  <span key={i} style={{ color: i <= (r.rating || 0) ? "#FFA41C" : "#6b7280", marginRight: 2 }}>
                    ★
                  </span>
                ))}
              </div>
              <p style={{ margin: "6px 0" }}>{r.review_text || ""}</p>
              {r.review_date && <small style={{ color: "var(--muted)" }}>{r.review_date}</small>}
            </div>
          ))
        )}

        {/* Write a Review — optional */}
        <div className="pd-actions" style={{ marginTop: 14 }}>
          <button className="btn ghost" onClick={() => setShowReviewForm(!showReviewForm)}>
            {showReviewForm ? "Cancel" : "Write a Review"}
          </button>

          {showReviewForm && (
            <div className="pd-card" style={{ padding: 12, marginTop: 10 }}>
              <p style={{ marginBottom: 6 }}>Your Rating</p>
              <div style={{ fontSize: "22px", marginBottom: "10px" }}>
                {[1, 2, 3, 4, 5].map((i) => (
                  <span
                    key={i}
                    style={{ cursor: "pointer", color: i <= reviewRating ? "#FFA41C" : "#6b7280", marginRight: 2 }}
                    onClick={() => setReviewRating(i)}
                  >
                    ★
                  </span>
                ))}
              </div>

              <textarea
                placeholder="Write your review here..."
                value={reviewText}
                onChange={(e) => setReviewText(e.target.value)}
                rows={4}
                className="pd-textarea"
                style={{ width: "100%" }}
              />

              <button className="btn primary" onClick={handleSubmitReview} style={{ marginTop: 8 }}>
                Submit Review
              </button>
            </div>
          )}
        </div>
      </div>

      {/* ---------- FAQs ---------- */}
      <FAQSection
        faqs={faqs}
        loading={faqLoading}
        error={faqError}
        onReload={reloadFaqs}
        showImportButtons={false}
      />
    </div>
  );
}

