
from sqlalchemy import Column, BigInteger, String, Text, TIMESTAMP, ForeignKey
from sqlalchemy.sql import func
from sqlalchemy.orm import relationship
from app.models.base import Base

class SellerApplication(Base):
    __tablename__ = "seller_applications"
    id = Column(BigInteger, primary_key=True)
    email = Column(String(256), index=True, nullable=False)
    full_name = Column(String(256), nullable=True)
    company_name = Column(String(256), nullable=True)
    # phone is optional; you can drop it later if unused, keeping for admin context
    phone = Column(String(64), nullable=True)
    note = Column(Text, nullable=True)

    status = Column(String(16), nullable=False, default="pending")  # pending|approved|rejected
    reason = Column(Text, nullable=True)
    decided_by_user_id = Column(BigInteger, ForeignKey("users.id", ondelete="SET NULL"), nullable=True)
    decision_at = Column(TIMESTAMP(timezone=True), nullable=True)

    created_at = Column(TIMESTAMP(timezone=True), server_default=func.now(), nullable=False)
