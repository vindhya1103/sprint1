


// src/pages/Customer.jsx
import { useEffect, useMemo, useState } from "react";
import { Link } from "react-router-dom";
import Header from "../components/Header";
import { getJSON } from "../api";

export default function Customer() {
  const [query, setQuery] = useState("");
  const [brand, setBrand] = useState("All");
  const [minRating, setMinRating] = useState(0);

  const [products, setProducts] = useState([]);
  const [ratingsMap, setRatingsMap] = useState(new Map()); // productId -> number|null
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  // Initial load (newest first)
  useEffect(() => {
    setLoading(true);
    setError(null);
    getJSON("/products", { limit: 60, order: "desc" })
      .then((items) => setProducts(items || []))
      .catch((e) => {
        console.error("Failed to load products:", e);
        setError(e.message || "Failed to load products");
      })
      .finally(() => setLoading(false));
  }, []);

  // Build brand list
  const brands = useMemo(() => {
    const set = new Set((products || []).map((p) => p.brand).filter(Boolean));
    return ["All", ...Array.from(set)];
  }, [products]);

  // Debounce search text
  const [debouncedQuery, setDebouncedQuery] = useState("");
  useEffect(() => {
    const t = setTimeout(() => setDebouncedQuery(query.trim()), 250);
    return () => clearTimeout(t);
  }, [query]);

  // Remote search when query is present; otherwise keep the preloaded list
  useEffect(() => {
    const qstr = debouncedQuery;
    if (!qstr) return;

    let ignore = false;
    setLoading(true);
    setError(null);
    getJSON("/products/search", { q: qstr, limit: 60 })
      .then((items) => {
        if (!ignore) setProducts(items || []);
      })
      .catch((e) => {
        console.error("Search failed:", e);
        if (!ignore) setError(e.message || "Search failed");
      })
      .finally(() => {
        if (!ignore) setLoading(false);
      });

    return () => { ignore = true; };
  }, [debouncedQuery]);

  // Parse rating from product (string/number across common keys)
  function parseProductRating(p) {
    const raw =
      p?.avg_rating ??
      p?.average_rating ??
      p?.rating ??
      p?.avgRating ??
      p?.averageRating ??
      null;

    const val = raw === null || raw === undefined ? null : Number(raw);
    return Number.isFinite(val) ? val : null;
  }

  // Lazy rating fetch from summary (cached)
  async function ensureRating(pid) {
    if (!pid) return;
    if (ratingsMap.has(pid)) return; // cached (even null)
    try {
      const summary = await getJSON(`/buyer/product/${pid}/summary`);
      const val = Number(
        summary?.average_rating ?? summary?.avg_rating ?? summary?.rating
      );
      const parsed = Number.isFinite(val) ? val : null;
      setRatingsMap((prev) => {
        const next = new Map(prev);
        next.set(pid, parsed);
        return next;
      });
    } catch (e) {
      console.error("Failed to load rating for product", pid, e);
      setRatingsMap((prev) => {
        const next = new Map(prev);
        next.set(pid, null);
        return next;
      });
    }
  }

  // Filtered list (uses product rating or cached summary rating)
  const filtered = useMemo(() => {
    const q = (debouncedQuery || "").toLowerCase();
    return (products || []).filter((p) => {
      const name = (p.product_title || p.external_id || "").toLowerCase();
      const okName = !q || name.includes(q);

      const okBrand = brand === "All" || p.brand === brand;

      const prodRating = parseProductRating(p);
      const cached = ratingsMap.get(p.id) ?? null;
      const r = prodRating ?? cached;

      const okRating =
        minRating === 0 ? true : r == null ? false : r >= minRating;

      return okName && okBrand && okRating;
    });
  }, [products, debouncedQuery, brand, minRating, ratingsMap]);

  // Group by brand for sections
  const grouped = useMemo(() => {
    const byBrand = new Map();
    for (const p of filtered) {
      const key = p.brand || "Unknown";
      if (!byBrand.has(key)) byBrand.set(key, []);
      byBrand.get(key).push(p);
    }
    return Array.from(byBrand.entries());
  }, [filtered]);

  const clearAll = () => {
    setQuery("");
    setBrand("All");
    setMinRating(0);
  };

  const onSearchKeyDown = (e) => {
    if (e.key === "Escape") {
      setQuery("");
      e.currentTarget.blur();
    }
  };

  const clearSearchText = () => setQuery("");

  const onSearchSubmit = (e) => {
    e.preventDefault();
    // no-op; filtering/search happens via debouncedQuery + remote call
  };

  return (
    <div className="page customer-page">
      {/* Scoped styles */}
      <style>{`
        :root {
          --bg: #0b1020;
          --bg2: #0e1630;
          --text: #e5e7eb;
          --muted: #9fb0d1;
          --primary: #3b82f6;
          --primary-600: #2563eb;
          --card: #0f172a;
          --cardBorder: #1f2937;
          --success: #34d399;
          --starOn: #f59e0b;
          --starOff: #6b7280;

          --btn-bg: #16223e;
          --btn-border: #2a3b65;
          --btn-text: #e5e7eb;
          --btn-ghost-hover: rgba(122,162,255,.08);
        }

        body, .customer-page {
          background: radial-gradient(1200px 800px at 20% -10%, var(--bg2), var(--bg));
          color: var(--text);
        }

        .container { width: 100%; max-width: 1200px; margin: 0 auto; padding: 0 20px; }

        /* Controls card */
        .controls {
          margin: 18px 0 8px;
          background: linear-gradient(180deg, rgba(255,255,255,0.02), rgba(255,255,255,0.01));
          border: 1px solid var(--cardBorder);
          border-radius: 12px;
          padding: 16px;
          box-shadow: 0 1px 3px rgba(0,0,0,.25);
        }
        .controls-header {
          display: flex; align-items: baseline; justify-content: space-between;
          gap: 12px; margin-bottom: 10px;
        }
        .controls-header h3 { margin: 0; font-size: 1.2rem; letter-spacing: -0.2px; }
        .result-meta { margin: 0; font-size: .95rem; color: var(--muted); white-space: nowrap; }

        /* Filters layout */
        .filters {
          display: grid;
          grid-template-columns: 1fr auto auto auto;
          gap: 10px;
          align-items: center;
        }
        @media (max-width: 900px) { .filters { grid-template-columns: 1fr auto auto; } }
        @media (max-width: 700px) { .filters { grid-template-columns: 1fr; } }

        /* THEMED Search bar */
        .searchbar {
          display: grid;
          grid-template-columns: auto 1fr auto auto; /* cat | input | clear | submit */
          align-items: center;
          height: 44px;
          background: var(--card);
          border: 1px solid var(--cardBorder);
          border-radius: 999px;
          overflow: hidden;
          transition: box-shadow .12s ease, border-color .12s ease;
        }
        .searchbar:hover { border-color: #2a3b65; }
        .searchbar:focus-within { box-shadow: 0 0 0 3px rgba(59,130,246,.25); }

        .sb-cat {
          height: 100%;
          display: inline-flex; align-items: center; gap: 6px;
          padding: 0 14px;
          background: var(--card);
          color: var(--text);
          border: none;
          border-right: 1px solid var(--cardBorder);
          cursor: default;
          user-select: none;
          font-size: .95rem;
        }

        .sb-input {
          border: none; outline: none;
          padding: 0 12px; font-size: 1rem;
          color: var(--text); background: transparent; width: 100%;
        }
        .sb-input::placeholder { color: var(--muted); }

        .sb-clear-btn {
          display: inline-flex; align-items: center; justify-content: center;
          height: 28px; width: 28px; margin-right: 6px;
          border: 1px solid var(--cardBorder);
          background: rgba(255,255,255,0.04);
          color: var(--muted);
          border-radius: 999px;
          cursor: pointer;
          transition: background .12s ease, border-color .12s ease, color .12s ease;
        }
        .sb-clear-btn:hover { background: rgba(255,255,255,0.07); color: #cdd7f3; border-color: #2a3b65; }

        .sb-submit {
          height: 100%;
          display: inline-grid; place-items: center;
          min-width: 54px;
          border: none;
          background: var(--primary);
          color: #fff;
          cursor: pointer;
          transition: background .12s ease;
        }
        .sb-submit:hover { background: var(--primary-600); }
        .sb-icon { display: block; }

        .select-pill {
          height: 44px; border-radius: 999px;
          border: 1px solid var(--cardBorder);
          background: var(--card); color: var(--text);
          padding: 0 14px; outline: none; font-size: .95rem;
        }
        .select-pill:focus { box-shadow: 0 0 0 3px rgba(96,165,250,.25); border-color: #284a80; }

        .results { margin: 16px 0 32px; }
        .brand-title { margin: 18px 0 10px; font-size: 1.1rem; color: var(--text); }

        .product-grid {
          display: grid; grid-template-columns: repeat(auto-fill, minmax(280px, 1fr));
          gap: 16px;
        }
        .product-card {
          background: var(--card); border: 1px solid var(--cardBorder);
          border-radius: 12px; overflow: hidden;
          box-shadow: 0 1px 3px rgba(0,0,0,.25);
          transition: transform .12s ease, box-shadow .12s ease, border-color .12s ease;
          display: flex; flex-direction: column; min-height: 320px;
        }
        .product-card:hover { transform: translateY(-2px); border-color: #2a3b65; box-shadow: 0 4px 16px rgba(0,0,0,.25); }

        .product-media { position: relative; background: #0b1222; height: 160px;
          display: flex; align-items: center; justify-content: center; }
        .product-media img { width: 100%; height: 100%; object-fit: cover; }

        .product-body { padding: 12px; display: flex; flex-direction: column; gap: 8px; flex: 1; }
        .product-title { margin: 0 0 2px; font-weight: 700; color: #fff; line-height: 1.2; }
        .product-brand { margin: 0 0 2px; color: var(--muted); }

        .product-meta { display: flex; align-items: center; justify-content: space-between; margin-top: 4px; }
        .price { color: var(--success); font-weight: 700; }

        .stars { color: var(--starOn); font-size: .95rem; display: inline-flex; align-items: center; gap: 2px; }
        .star { color: var(--starOff); }
        .star.on { color: var(--starOn); }
        .rating-value { color: #fef3c7; margin-left: 6px; font-weight: 600; }

        .product-actions { margin-top: auto; display: flex; align-items: center; gap: 10px; padding-top: 8px; }

        .customer-page .btn {
          display: inline-flex; align-items: center; justify-content: center;
          height: 34px; padding: 0 14px; border-radius: 10px;
          border: 1px solid var(--btn-border); background: var(--btn-bg);
          color: var(--btn-text); text-decoration: none; cursor: pointer;
          transition: background .12s ease, border-color .12s ease, transform .08s ease;
          user-select: none;
        }
        .customer-page .btn:hover { border-color: #3a56a3; background: #1a2a52; }
        .customer-page .btn:active { transform: translateY(1px); }
        .customer-page .btn.small { height: 32px; padding: 0 12px; font-size: .9rem; }
        .customer-page .btn.primary { background: var(--primary); border-color: var(--primary-600); color: #fff; }
        .customer-page .btn.primary:hover { background: var(--primary-600); }
        .customer-page .btn.ghost { background: transparent; border-color: var(--btn-border); }
        .customer-page .btn.ghost:hover { background: var(--btn-ghost-hover); }

        /* (Optional) Kept in case you re-enable the badge later; not rendered now */
        .rating-badge {
          display: inline-flex;
          align-items: center;
          gap: 4px;
          margin-left: 8px;
          padding: 2px 6px;
          border-radius: 8px;
          border: 1px solid var(--cardBorder);
          background: rgba(245, 158, 11, 0.12);
          color: #f59e0b;
          font-weight: 600;
          font-size: .85rem;
        }
      `}</style>

      <Header />

      <main className="container">
        {/* Controls */}
        <section className="controls" aria-label="Filters and search">
          <div className="controls-header">
            <h3>Explore products</h3>
            <p className="result-meta">
              Showing <strong>{filtered.length}</strong> of <strong>{products.length}</strong>
            </p>
          </div>

          <div className="filters">
            {/* THEMED SEARCH BAR */}
            <form className="searchbar" role="search" aria-label="Search products" onSubmit={onSearchSubmit}>
              <button type="button" className="sb-cat" title="All categories" disabled aria-label="Category (All)">
                All
              </button>

              <input
                className="sb-input"
                type="text"
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                onKeyDown={onSearchKeyDown}
                placeholder="Search products… (e.g., router, laptop, tablet)"
                aria-label="Search products"
              />

              {query && (
                <button
                  type="button"
                  className="sb-clear-btn"
                  aria-label="Clear search"
                  onClick={clearSearchText}
                  title="Clear"
                >
                  ×
                </button>
              )}

              <button type="submit" className="sb-submit" aria-label="Search">
                <svg className="sb-icon" width="18" height="18" viewBox="0 0 24 24" fill="none" aria-hidden="true">
                  <circle cx="11" cy="11" r="7" stroke="currentColor" strokeWidth="2" />
                  <line x1="16.65" y1="16.65" x2="21" y2="21" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
                </svg>
              </button>
            </form>

            {/* Brand select */}
            <select
              className="select-pill"
              value={brand}
              onChange={(e) => setBrand(e.target.value)}
              aria-label="Filter by brand"
              title="Filter by brand"
            >
              {brands.map((b) => (
                <option key={b} value={b}>
                  {b}
                </option>
              ))}
            </select>

            {/* Rating select */}
            <select
              className="select-pill"
              value={minRating}
              onChange={(e) => setMinRating(Number(e.target.value))}
              aria-label="Filter by minimum rating"
              title="Filter by minimum rating"
            >
              <option value={0}>Any rating</option>
              <option value={3}>3★+</option>
              <option value={4}>4★+</option>
              <option value={4.5}>4.5★+</option>
            </select>
          </div>
        </section>

        {/* Loading / error */}
        {loading && <p className="result-meta">Loading products…</p>}
        {error && <p className="result-meta" style={{ color: "#f66" }}>Error: {error}</p>}

        {/* Results */}
        <section className="results">
          {!loading && !error && grouped.length === 0 && (
            <p className="result-meta">No products found. Try clearing filters.</p>
          )}

          {!loading &&
            !error &&
            grouped.map(([brandName, list]) => (
              <div key={brandName}>
                <h4 className="brand-title">{brandName}</h4>
                <div className="product-grid">
                  {list.map((p) => (
                    <CustomerCard
                      key={p.id}
                      product={p}
                      parseProductRating={parseProductRating}
                      ensureRating={ensureRating}
                      cachedRating={ratingsMap.get(p.id) ?? null}
                      minRating={minRating}
                    />
                  ))}
                </div>
              </div>
            ))}
        </section>
      </main>
    </div>
  );
}

/* -------- Card -------- */
function CustomerCard({
  product,
  parseProductRating,
  ensureRating,
  cachedRating /* minRating not required for fetching */
}) {
  const { id, product_title, brand, price, image_url, external_id } = product;
  const name =
    product.product_title || product_title || external_id || `#${id}`;

  const prodRating = parseProductRating(product);
  const displayRating = prodRating ?? cachedRating; // number|null

  useEffect(() => {
    // Always lazy-fetch rating if we don't have one yet
    if (displayRating == null) {
      ensureRating(id);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [id, displayRating]);

  return (
    <article className="product-card" aria-label={`${name} by ${brand || ""}`}>
      <div className="product-media">
        <img
          src={image_url || "https://via.placeholder.com/800x600?text=Product"}
          alt={`${name} by ${brand || ""}`}
          loading="lazy"
          onError={(e) => {
            e.currentTarget.src =
              "https://via.placeholder.com/800x600?text=No+Image";
          }}
        />
      </div>

      <div className="product-body">
        {/* Title WITHOUT the top rating badge */}
        <h4 className="product-title" title={name}>
          {name}
        </h4>

        <p className="product-brand">{brand || "—"}</p>

        <div className="product-meta">
          <span className="price">
            {price != null ? `₹${Number(price).toFixed(2)}` : "—"}
          </span>

          {/* Keep ONLY the bottom stars + numeric rating */}
          {displayRating != null && Number.isFinite(Number(displayRating)) ? (
            <span className="stars" aria-label={`${displayRating} out of 5 stars`}>
              {renderStars(displayRating)}
              <span className="rating-value">
                {Number(displayRating).toFixed(1)}
              </span>
            </span>
          ) : (
            <span
              className="stars"
              aria-label="No rating yet"
              style={{ color: "var(--starOff)" }}
            >
              {renderStars(0)}
              <span className="rating-value" style={{ color: "var(--muted)" }}>
                —
              </span>
            </span>
          )}
        </div>

        <div className="product-actions">
          <Link to={`/product-details/${id}`} className="btn small primary">
            View
          </Link>
          <Link to={`/product-details/${id}#reviews`} className="btn small ghost">
            Reviews
          </Link>
        </div>
      </div>
    </article>
  );
}

/* -------- Helpers -------- */
function renderStars(rating = 0) {
  const r = Math.round(Number(rating) || 0);
  return (
    <>
      {[...Array(5)].map((_, i) => (
        <span key={i} className={i < r ? "star on" : "star"} aria-hidden>
          ★
        </span>
      ))}
    </>
  );
}
