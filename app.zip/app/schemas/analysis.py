
from pydantic import BaseModel
from typing import Optional, List, Dict

class AnalysisCreate(BaseModel):
    review_id: int
    summary: Optional[str] = None
    verdict: Optional[str] = None
    pros: Optional[List[str]] = None
    cons: Optional[List[str]] = None
    sentiment: Optional[str] = None
    key_themes: Optional[List[Dict]] = None
    raw_output: Optional[Dict] = None

class AnalysisOut(BaseModel):
    review_id: int
    summary: Optional[str] = None
    verdict: Optional[str] = None
    pros: Optional[List[str]] = None
    cons: Optional[List[str]] = None
    sentiment: Optional[str] = None
    key_themes: Optional[List[Dict]] = None
