


# backend/app/api/routes.py
from fastapi import APIRouter

from . import (
    auth,
    admin,
    admin_bootstrap,
    products,
    reviews,        # ensure this exists; we provide a minimal one below
    analyses,
    dashboards,
    buyer,
    seller,         # seller-role API
    sellers,        # admin endpoints to create/list sellers
    support,
    faq,
    search,
    vector_setup,
)

api_router = APIRouter()

api_router.include_router(auth.router,            prefix="/auth",          tags=["auth"])
api_router.include_router(admin.router,           prefix="/admin",         tags=["admin"])
api_router.include_router(admin_bootstrap.router, prefix="/admin",         tags=["admin"])
api_router.include_router(products.router,        prefix="/products",      tags=["products"])
api_router.include_router(reviews.router,         prefix="/reviews",       tags=["reviews"])
api_router.include_router(analyses.router,        prefix="/analyses",      tags=["analyses"])
api_router.include_router(dashboards.router,      prefix="/dashboards",    tags=["dashboards"])
api_router.include_router(buyer.router,           prefix="/buyer",         tags=["buyer"])
api_router.include_router(seller.router,          prefix="/seller",        tags=["seller"])
api_router.include_router(sellers.router,         prefix="/sellers",       tags=["sellers"])
api_router.include_router(support.router,         prefix="/support",       tags=["support"])
api_router.include_router(faq.router,             prefix="/faq",           tags=["faq"])
api_router.include_router(search.router,          prefix="/search",        tags=["search"])
api_router.include_router(vector_setup.router,    prefix="/vector-setup",  tags=["admin"])

# ❌ Removed duplicate: api_router.include_router(support.router, prefix="/support")
