
# backend/app/main.py
import logging
from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse

from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker

from app.core.config import Settings
from app.models.base import Base
from app.models.seller_application import SellerApplication
# Import models so Base.metadata.create_all sees them
from app.models.user import User
from app.models.seller import Seller
from app.models.product import Product
from app.models.review import Review
from app.models.analysis import Analysis
from app.models.faq import ProductQuestion, ProductAnswer
from app.models.activity import UserSession, UserActivityLog, ProductView
from app.models.embedding import ProductEmbedding
from app.models.support import SupportTeam   # <-- NEW
from app.api.routes import api_router

settings = Settings()
app = FastAPI(title="Review Intelligence API", version="0.1.0", description="Consolidated build")

app.add_middleware(
    CORSMiddleware,
    allow_origins=[
        "http://localhost:5174",
        "http://127.0.0.1:5174",
        "http://localhost:5173",
        "http://127.0.0.1:5173",
    ],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Local engine only for startup table creation (does not replace your app's SessionLocal)
_engine = create_engine(settings.database_url, pool_pre_ping=True)
_SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=_engine)

@app.on_event("startup")
def on_startup():
    Base.metadata.create_all(bind=_engine)

@app.get("/health")
def health():
    return {"status": "ok", "env": settings.app_env}

logger = logging.getLogger("uvicorn.error")

@app.exception_handler(Exception)
async def unhandled_exception_handler(request: Request, exc: Exception):
    logger.exception("Unhandled exception on %s %s", request.method, request.url)
    return JSONResponse(status_code=500, content={"detail": "Internal Server Error"})

app.include_router(api_router)
