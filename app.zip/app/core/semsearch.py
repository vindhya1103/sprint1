
# backend/app/core/semsearch.py
from functools import lru_cache
from typing import List
from sentence_transformers import SentenceTransformer

@lru_cache(maxsize=1)
def get_sentence_model():
    return SentenceTransformer('all-MiniLM-L6-v2')

def embed_texts(texts: List[str]) -> List[List[float]]:
    """
    Returns normalized embeddings for better cosine distance behavior.
    """
    model = get_sentence_model()
    return model.encode(texts, normalize_embeddings=True).tolist()
