
# backend/app/core/activity.py
from typing import Optional, Dict, Any
import json
from sqlalchemy.orm import Session
from app.models.activity import UserSession, UserActivityLog, ProductView

def create_session(db: Session, user_id: int) -> int:
    row = UserSession(user_id=user_id, is_active=True)
    db.add(row); db.commit(); db.refresh(row)
    return row.id

def end_sessions(db: Session, user_id: int) -> int:
    """Mark active sessions for user as logged out."""
    cnt = 0
    q = db.query(UserSession).filter(UserSession.user_id == user_id, UserSession.is_active == True).all()
    for s in q:
        s.is_active = False
        from datetime import datetime, timezone
        s.logout_time = datetime.now(timezone.utc)
        db.add(s); cnt += 1
    db.commit()
    return cnt

def log_activity(
    db: Session,
    user_id: Optional[int],
    activity_type: str,
    description: str,
    metadata: Optional[Dict[str, Any]] = None,
):
    # store JSON in meta_json (renamed from reserved `metadata`)
    row = UserActivityLog(
        user_id=user_id,
        activity_type=activity_type,
        activity_description=description,
        meta_json=(json.dumps(metadata) if metadata else None),
    )
    db.add(row); db.commit()

def record_product_view(db: Session, user_id: Optional[int], product_id: int):
    row = ProductView(user_id=user_id, product_id=product_id)
    db.add(row); db.commit()
