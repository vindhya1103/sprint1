
from pydantic import BaseModel
from typing import List, Optional

class CountItem(BaseModel):
    label: str
    count: int

class BuyerQuote(BaseModel):
    text: str
    rating: Optional[int] = None
    date: str
    sentiment: Optional[str] = None
    helpful_votes: int
    reviewer_name: Optional[str] = None

class BuyerSummaryOut(BaseModel):
    product_id: int
    summary: Optional[str] = None
    pros: List[CountItem]
    cons: List[CountItem]
    verdict: Optional[str] = None
    average_rating: Optional[float] = None
    quotes_positive: List[BuyerQuote]
    quotes_negative: List[BuyerQuote]
    faqs: List[dict]

class SellerInsightsOut(BaseModel):
    product_id: int
    pros_top: List[CountItem]
    cons_top: List[CountItem]
    sentiment_distribution: List[CountItem]
    key_issues: List[CountItem]
    trend_points: List[dict]

class SupportIssueOut(BaseModel):
    review_id: int
    product_id: int
    review_date: str
    rating: Optional[int] = None
    reviewer_name: Optional[str] = None
    helpful_votes: int
    sentiment: str
    top_issue: Optional[str] = None
    severity: int
    excerpt: str

class SupportListOut(BaseModel):
    items: List[SupportIssueOut]

class BusinessTrendOut(BaseModel):
    points: List[dict]

class ProductCompareItem(BaseModel):
    product_id: int
    average_rating: Optional[float] = None
    issues_top: List[CountItem]
    last30_trend: List[dict]

class BusinessCompareOut(BaseModel):
    items: List[ProductCompareItem]
