
from fastapi import APIRouter, Depends, File, UploadFile, HTTPException
from sqlalchemy.orm import Session
from sqlalchemy import select
from app.db.session import get_db
from app.models.faq import ProductQuestion, ProductAnswer
from app.models.product import Product
from app.schemas.faq import ProductQuestionOut, ProductAnswerOut
import io, csv

router = APIRouter()

@router.get("/product/{product_id}", response_model=list[ProductQuestionOut])
def product_faq(product_id: int, db: Session = Depends(get_db)):
    p = db.get(Product, product_id)
    if not p:
        raise HTTPException(404, "Product not found")
    qrows = db.execute(select(ProductQuestion).where(ProductQuestion.product_id == product_id).order_by(ProductQuestion.id.asc())).scalars().all()
    out = []
    for q in qrows:
        answers = [ProductAnswerOut(id=a.id, question_id=a.question_id, answer_text=a.answer_text, answered_at=str(a.answered_at)) for a in q.answers]
        out.append(ProductQuestionOut(id=q.id, product_id=q.product_id, question_text=q.question_text, asked_at=str(q.asked_at), language=q.language, answers=answers))
    return out

@router.post("/import/questions")
async def import_questions(file: UploadFile = File(...), db: Session = Depends(get_db)):
    content = await file.read()
    reader = csv.DictReader(io.StringIO(content.decode("utf-8")))
    created = 0
    for row in reader:
        ext_pid = (row.get("product_id") or "").strip()
        qtext = (row.get("question_text") or "").strip()
        if not ext_pid or not qtext:
            continue
        p = db.query(Product).filter(Product.external_id == ext_pid).first()
        if not p:
            continue
        db.add(ProductQuestion(product_id=p.id, question_text=qtext))
        created += 1
    db.commit()
    return {"created": created}

@router.post("/import/answers")
async def import_answers(file: UploadFile = File(...), db: Session = Depends(get_db)):
    content = await file.read()
    reader = csv.DictReader(io.StringIO(content.decode("utf-8")))
    created = 0
    for row in reader:
        ext_pid = (row.get("product_id") or "").strip()
        qtext = (row.get("question_text") or "").strip()
        atext = (row.get("answer_text") or "").strip()
        if not ext_pid or not qtext or not atext:
            continue
        p = db.query(Product).filter(Product.external_id == ext_pid).first()
        if not p:
            continue
        q = db.query(ProductQuestion).filter(ProductQuestion.product_id == p.id, ProductQuestion.question_text == qtext).first()
        if not q:
            q = ProductQuestion(product_id=p.id, question_text=qtext)
            db.add(q); db.flush()
        db.add(ProductAnswer(question_id=q.id, answer_text=atext))
        created += 1
    db.commit()
    return {"created": created}
