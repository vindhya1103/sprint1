
# backend/app/models/support.py
from sqlalchemy import Column, BigInteger, String
from app.models.base import Base

class SupportTeam(Base):
    __tablename__ = "support_teams"
    id = Column(BigInteger, primary_key=True)
    name = Column(String, unique=True, nullable=False)
