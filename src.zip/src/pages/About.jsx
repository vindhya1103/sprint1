
// src/About.jsx
import { Link } from "react-router-dom";
import "./home.css";
import "./About.css"; // If About.css is in src/pages, change to: import "../pages/About.css";
import Header from "../components/Header";

export default function About() {
  return (
    <div className="home about about-page">
      <Header />

      {/* Hero Section */}
      <main className="hero" role="region" aria-label="About our platform">
        <div className="hero-left">
          <h1 className="text-center">
            Crafting a unified experience for Customers And Sellers And Managers
          </h1>
          <p className="text-center">
            A single platform to track orders, manage products, and monitor KPIs—built for clarity,
            speed, and delightful usability.
          </p>
          <br />
          <div className="cta-row">
            <Link to="/login" className="btn primary">Get Started</Link>
            <Link to="/login" className="btn ghost">Explore Customer Space</Link>
          </div>
        </div>
      </main>

      {/* Mission Section */}
      <section className="about-section" aria-labelledby="mission-title">
        <h1 id="mission-title" className="text-center">Our Missions</h1>
        <p className="text-center">
          We aim to simplify commerce operations by providing a seamless, role-specific experience
          that empowers every user.
        </p>
        <br />
        <div className="role-grid">
          <AboutCard
            title="Simplicity by Design"
            description="Reduce friction with intuitive workflows and clean, consistent UI patterns."
            emoji="✨"
            accent="var(--accent1)"
          />
          <AboutCard
            title="Performance at Scale"
            description="Deliver blazing-fast experiences with efficient rendering and smart data fetching."
            emoji="⚡"
            accent="var(--accent2)"
          />
          <AboutCard
            title="Trust & Transparency"
            description="Enable confident decisions with clear metrics, audit trails, and secure access."
            emoji="🔍"
            accent="var(--accent3)"
          />
        </div>
      </section>

      <h1 className="text-center">Our Services</h1>
      <div className="card">
        {/* Features Section */}
        <section className="about-section features" aria-labelledby="features-title">
          <h3 id="features-title">What We Offer</h3>
          <ul className="feature-list">
            <FeatureItem
              title="Unified Dashboard"
              description="View orders, inventory, reviews, and performance in one place."
              icon="📊"
            />
            <FeatureItem
              title="Role-Aware UX"
              description="Tailored experiences for Customers, Sellers, and Managers."
              icon="🎯"
            />
            <FeatureItem
              title="Real-Time Insights"
              description="Stay informed with up-to-date KPIs and alerts."
              icon="📈"
            />
            <FeatureItem
              title="Secure & Scalable"
              description="Built with modern best practices for reliability and growth."
              icon="🔐"
            />
          </ul>
          <div className="cta-row">
            <Link to="/login" className="btn small">View Manager KPIs</Link>
            <Link to="/login" className="btn small ghost">Manage Products</Link>
          </div>
        </section>

        {/* Values Section */}
        <section className="about-section values" aria-labelledby="values-title">
          <h3 id="values-title">Our Values</h3>
          <div className="value-grid">
            <ValueBadge
              title="User-Centric"
              description="We design for clarity, accessibility, and joy."
              color="var(--accent1)"
            />
            <ValueBadge
              title="Quality"
              description="Polished details, consistent patterns, and reliable performance."
              color="var(--accent2)"
            />
            <ValueBadge
              title="Ownership"
              description="We iterate quickly and ship responsibly."
              color="var(--accent3)"
            />
            <ValueBadge
              title="Trust"
              description="We build trust by delivering value consistently and responsibly."
              color="var(--accent4)"
            />
          </div>
        </section>
      </div>

      <br />

      {/* Call to Action */}
      <section className="about-section callout" aria-labelledby="cta-title">
        <h1 id="cta-title" className="text-center">Ready to Dive In?</h1>
        <p className="text-center">
          Create an account and start exploring role-specific experiences across the platform.
        </p>
        <div className="cta-row">
          <Link to="/register" className="btn primary">Create Account</Link>
          <Link to="/login" className="btn ghost">Browse as Customer</Link>
        </div>
      </section>

      <footer className="footer">
        <p>© {new Date().getFullYear()} Sprint Project • Built with Vite + React</p>
      </footer>
    </div>
  );
}

function AboutCard({ title, description, emoji, accent }) {
  return (
    <div className="role-card about-card" style={{ "--accent": accent }}>
      <div className="role-emoji" aria-hidden="true">{emoji}</div>
      <div className="role-info">
        <h4>{title}</h4>
        <p>{description}</p>
      </div>
    </div>
  );
}

function FeatureItem({ title, description, icon }) {
  return (
    <li className="feature-item" aria-label={title}>
      <span className="feature-icon" aria-hidden="true">{icon}</span>
      <div className="feature-content">
        <h4 className="feature-title">{title}</h4>
        <p className="feature-description">{description}</p>
      </div>
    </li>
  );
}

function ValueBadge({ title, description, color }) {
  return (
    <div className="value-badge" style={{ borderColor: color }}>
      <h4 className="value-title">{title}</h4>
      <p className="value-description">{description}</p>
    </div>
  );
}
