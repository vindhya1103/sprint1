
# backend/app/api/seller.py
from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session
from sqlalchemy import select, text
from typing import List, Dict, Any
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from sqlalchemy import text
from typing import Dict, Any, List

from app.db.session import get_db
from app.api.auth import require_role
from app.models.user import User

from app.db.session import get_db
from app.api.auth import require_role
from app.models.user import User
from app.models.product import Product

router = APIRouter()

@router.get("/me/products", response_model=List[Dict[str, Any]])
def seller_my_products(
    db: Session = Depends(get_db),
    u: User = Depends(require_role("seller")),
    limit: int = Query(500, ge=1, le=1000),
):
    """
    Return products for the logged-in seller.
    Only uses columns that exist in Product: id, product_title, brand, category, subtype, price.
    """
    if not u.seller_id:
        return []

    rows = db.execute(
        select(
            Product.id,
            Product.product_title,
            Product.brand,
            Product.category,
            Product.subtype,
            Product.price,
        ).where(Product.seller_id == u.seller_id).limit(limit)
    ).all()

    items: List[Dict[str, Any]] = []
    for pid, title, brand, cat, sub, price in rows:
        items.append({
            "id": int(pid),
            "product_title": title,
            "brand": brand,
            "category": cat,
            "subtype": sub,
            "price": float(price) if price is not None else None,
        })
    return items



@router.get("/product/{product_id}/insights", response_model=Dict[str, Any])
def product_insights(
    product_id: int,
    db: Session = Depends(get_db),
    u: User = Depends(require_role("seller", "admin")),
):
    """
    Product insights with robust fallbacks:
    - sentiment_distribution: from analyses.sentiment or fallback to rating
    - pros_top / cons_top:
        1) prefer analyses.key_themes grouped by positive/negative
        2) if empty, fallback to top keywords from review_text (SQL tokenization)
    - key_issues: themes if present, else top keywords overall
    - trend_points: daily counts per sentiment (with same sentiment fallback)
    - totals: include counts to display 'Total positive/negative reviews'
    """
    pid = int(product_id)

    # Ownership guard for sellers
    if u.role == "seller":
        owns = db.execute(
            text("SELECT 1 FROM products WHERE id = :pid AND seller_id = :sid"),
            {"pid": pid, "sid": int(u.seller_id or 0)}
        ).first()
        if not owns:
            raise HTTPException(403, "You do not own this product.")

    # ---------- Sentiment distribution (with fallback to rating) ----------
    dist_rows = db.execute(text("""
        WITH labeled AS (
          SELECT
            COALESCE(
              a.sentiment,
              CASE
                WHEN r.rating IS NULL THEN 'unknown'
                WHEN r.rating >= 4 THEN 'positive'
                WHEN r.rating <= 2 THEN 'negative'
                ELSE 'neutral'
              END
            ) AS label
          FROM reviews r
          LEFT JOIN analyses a ON a.review_id = r.id
          WHERE r.product_id = :pid
        )
        SELECT label, COUNT(*) AS count
        FROM labeled
        GROUP BY label
        ORDER BY count DESC;
    """), {"pid": pid}).all()
    sentiment_distribution = [{"label": str(l), "count": int(c)} for (l, c) in dist_rows]
    totals = {d["label"]: d["count"] for d in sentiment_distribution}
    total_reviews = sum(d["count"] for d in sentiment_distribution)

    # ---------- Pros/Cons from key_themes first ----------
    pros_rows = db.execute(text("""
        SELECT LOWER(TRIM(a.key_themes->i->>'theme')) AS label, COUNT(*) AS count
        FROM reviews r
        LEFT JOIN analyses a ON a.review_id = r.id
        JOIN LATERAL generate_series(
            0,
            CASE WHEN a.key_themes IS NULL THEN -1 ELSE jsonb_array_length(a.key_themes)-1 END
        ) AS i ON TRUE
        WHERE r.product_id = :pid
          AND COALESCE(a.sentiment, 'unknown') = 'positive'
          AND a.key_themes IS NOT NULL
        GROUP BY label
        ORDER BY count DESC
        LIMIT 10;
    """), {"pid": pid}).all()
    cons_rows = db.execute(text("""
        SELECT LOWER(TRIM(a.key_themes->i->>'theme')) AS label, COUNT(*) AS count
        FROM reviews r
        LEFT JOIN analyses a ON a.review_id = r.id
        JOIN LATERAL generate_series(
            0,
            CASE WHEN a.key_themes IS NULL THEN -1 ELSE jsonb_array_length(a.key_themes)-1 END
        ) AS i ON TRUE
        WHERE r.product_id = :pid
          AND COALESCE(a.sentiment, 'unknown') = 'negative'
          AND a.key_themes IS NOT NULL
        GROUP BY label
        ORDER BY count DESC
        LIMIT 10;
    """), {"pid": pid}).all()
    pros_top = [{"label": str(l), "count": int(c)} for (l, c) in pros_rows]
    cons_top = [{"label": str(l), "count": int(c)} for (l, c) in cons_rows]

    # ---------- If Pros/Cons empty, fallback to top keywords from text ----------
    # rudimentary tokenizer: lowercase, strip non-alnum, split by space; remove stopwords, len>=3
    stopwords = [
        'the','and','you','your','with','for','from','this','that','are','was','were','have','has','had',
        'they','them','their','its','our','ours','but','not','out','too','very','can','could','would',
        'will','just','about','after','before','into','over','under','more','less','than','then','there',
        'here','also','been','being','able','some','any','much','many','each','every','other','another',
        'between','among','across','within','without','while','when','where','which','what','who','whom',
        'why','how','done','does','did','don','t','good','bad','okay','ok'
    ]
    stoplist_sql = ",".join(f"'{w}'" for w in stopwords)

    if not pros_top:
        pros_kw = db.execute(text(f"""
            WITH base AS (
              SELECT
                unnest(
                  string_to_array(
                    regexp_replace(lower(COALESCE(r.review_text,'')), '[^a-z0-9 ]', ' ', 'g'),
                    ' '
                  )
                ) AS term
              FROM reviews r
              LEFT JOIN analyses a ON a.review_id = r.id
              WHERE r.product_id = :pid
                AND COALESCE(
                  a.sentiment,
                  CASE
                    WHEN r.rating IS NULL THEN 'neutral'
                    WHEN r.rating >= 4 THEN 'positive'
                    WHEN r.rating <= 2 THEN 'negative'
                    ELSE 'neutral'
                  END
                ) = 'positive'
            )
            SELECT term AS label, COUNT(*) AS count
            FROM base
            WHERE term <> '' AND char_length(term) >= 3
              AND term NOT IN ({stoplist_sql})
            GROUP BY term
            ORDER BY count DESC
            LIMIT 10;
        """), {"pid": pid}).all()
        pros_top = [{"label": str(l), "count": int(c)} for (l, c) in pros_kw]

    if not cons_top:
        cons_kw = db.execute(text(f"""
            WITH base AS (
              SELECT
                unnest(
                  string_to_array(
                    regexp_replace(lower(COALESCE(r.review_text,'')), '[^a-z0-9 ]', ' ', 'g'),
                    ' '
                  )
                ) AS term
              FROM reviews r
              LEFT JOIN analyses a ON a.review_id = r.id
              WHERE r.product_id = :pid
                AND COALESCE(
                  a.sentiment,
                  CASE
                    WHEN r.rating IS NULL THEN 'neutral'
                    WHEN r.rating >= 4 THEN 'positive'
                    WHEN r.rating <= 2 THEN 'negative'
                    ELSE 'neutral'
                  END
                ) = 'negative'
            )
            SELECT term AS label, COUNT(*) AS count
            FROM base
            WHERE term <> '' AND char_length(term) >= 3
              AND term NOT IN ({stoplist_sql})
            GROUP BY term
            ORDER BY count DESC
            LIMIT 10;
        """), {"pid": pid}).all()
        cons_top = [{"label": str(l), "count": int(c)} for (l, c) in cons_kw]

    # ---------- Key issues: prefer themes; fallback to overall top keywords ----------
    key_rows = db.execute(text("""
        SELECT LOWER(TRIM(a.key_themes->i->>'theme')) AS label, COUNT(*) AS count
        FROM reviews r
        LEFT JOIN analyses a ON a.review_id = r.id
        JOIN LATERAL generate_series(
            0,
            CASE WHEN a.key_themes IS NULL THEN -1 ELSE jsonb_array_length(a.key_themes)-1 END
        ) AS i ON TRUE
        WHERE r.product_id = :pid
          AND a.key_themes IS NOT NULL
        GROUP BY label
        ORDER BY count DESC
        LIMIT 10;
    """), {"pid": pid}).all()
    key_issues = [{"label": str(l), "count": int(c)} for (l, c) in key_rows]

    if not key_issues:
        key_kw = db.execute(text(f"""
            WITH base AS (
              SELECT
                unnest(
                  string_to_array(
                    regexp_replace(lower(COALESCE(r.review_text,'')), '[^a-z0-9 ]', ' ', 'g'),
                    ' '
                  )
                ) AS term
              FROM reviews r
              WHERE r.product_id = :pid
            )
            SELECT term AS label, COUNT(*) AS count
            FROM base
            WHERE term <> '' AND char_length(term) >= 3
              AND term NOT IN ({stoplist_sql})
            GROUP BY term
            ORDER BY count DESC
            LIMIT 10;
        """), {"pid": pid}).all()
        key_issues = [{"label": str(l), "count": int(c)} for (l, c) in key_kw]

    # ---------- Trend (daily) with same sentiment fallback ----------
    trend_rows = db.execute(text("""
        WITH labeled AS (
          SELECT
            COALESCE(TO_CHAR(r.review_date, 'YYYY-MM-DD'), 'unknown') AS date,
            COALESCE(
              a.sentiment,
              CASE
                WHEN r.rating IS NULL THEN 'unknown'
                WHEN r.rating >= 4 THEN 'positive'
                WHEN r.rating <= 2 THEN 'negative'
                ELSE 'neutral'
              END
            ) AS sentiment
          FROM reviews r
          LEFT JOIN analyses a ON a.review_id = r.id
          WHERE r.product_id = :pid
        )
        SELECT date, sentiment, COUNT(*) AS count
        FROM labeled
        GROUP BY date, sentiment
        ORDER BY date ASC, sentiment DESC
        LIMIT 600;
    """), {"pid": pid}).all()
    trend_points = [{"date": str(d), "sentiment": str(s), "count": int(c)} for (d, s, c) in trend_rows]

    # ---------- Product title ----------
    prod = db.execute(text("SELECT product_title FROM products WHERE id = :pid"), {"pid": pid}).first()
    product_title = str(prod[0]) if prod else None

    return {
        "product_id": pid,
        "product_title": product_title,
        "total_reviews": total_reviews,
        "positives": int(totals.get("positive", 0)),
        "negatives": int(totals.get("negative", 0)),
        "neutrals": int(totals.get("neutral", 0)),
        "pros_top": pros_top,
        "cons_top": cons_top,
        "sentiment_distribution": sentiment_distribution,
        "trend_points": trend_points,
        "key_issues": key_issues,
    }
