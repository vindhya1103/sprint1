// src/pages/Register.jsx
import { useState } from "react";
import { useNavigate } from "react-router-dom";
import "../styles/register.css";
import Header from "../components/Header";
import { postJSON } from "../api";

export default function Register() {
  const navigate = useNavigate();

  const [form, setForm] = useState({
    role: "buyer",          // "buyer" | "seller"
    full_name: "",
    email: "",
    password: "",
    company_name: "",
    phone: "",
    note: "",
  });

  const [errors, setErrors] = useState({});
  const [submitting, setSubmitting] = useState(false);

  const onChange = (e) => {
    const { name, value } = e.target;
    setForm((prev) => ({ ...prev, [name]: value }));
    setErrors((prev) => {
      const next = { ...prev };
      delete next[name];
      delete next.submit;
      return next;
    });
  };

  const validate = () => {
    const next = {};
    if (!form.email.trim()) next.email = "Email is required";
    else if (!/^\S+@\S+\.\S+$/.test(form.email)) next.email = "Enter a valid email";

    if (form.role === "buyer") {
      if (!form.full_name.trim()) next.full_name = "Full name is required";
      if (!form.password) next.password = "Password is required";
      else if (form.password.length < 6) next.password = "Password must be at least 6 characters";
    } else {
      if (!form.full_name.trim()) next.full_name = "Full name is required";
      if (!form.company_name.trim()) next.company_name = "Company is required";
    }

    setErrors(next);
    return Object.keys(next).length === 0;
  };

  const onSubmit = async (e) => {
    e.preventDefault();
    if (submitting) return;
    if (!validate()) return;

    setSubmitting(true);
    try {
      if (form.role === "buyer") {
        // ✅ Do NOT auto-login. Register, then redirect to Login with flash.
        await postJSON("/auth/register", {
          email: form.email.trim(),
          full_name: form.full_name.trim(),
          password: form.password,
          role: "buyer",
        });

        navigate("/login", {
          replace: true,
          state: { flash: "Registration successful. Please log in." },
        });
      } else {
        // Seller: submit application, then redirect to Login
        await postJSON("/auth/seller-apply", {
          email: form.email.trim(),
          full_name: form.full_name.trim(),
          company_name: form.company_name.trim(),
          phone: form.phone.trim(),
          note: form.note.trim(),
        });

        navigate("/login", {
          replace: true,
          state: { flash: "Seller application submitted. Admin will email you the OTP upon approval." },
        });
      }
    } catch (err) {
      setErrors((prev) => ({ ...prev, submit: err?.message || "Registration failed." }));
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="register-v10">
      <Header />
      <div className="register-v10__container">
        <div className="inner glass card">
          <form onSubmit={onSubmit} noValidate>
            <h3 className="register-title">Create your account</h3>

            <div className="form-holder">
              <select
                className="form-control"
                name="role"
                value={form.role}
                onChange={onChange}
                aria-label="I am a"
              >
                <option value="buyer">I am a Buyer</option>
                <option value="seller">I am a Seller</option>
              </select>
            </div>

            <div className="form-holder">
              <input
                type="text"
                className="form-control"
                placeholder="Full Name"
                name="full_name"
                value={form.full_name}
                onChange={onChange}
                aria-invalid={!!errors.full_name}
                aria-describedby="full_name-error"
                autoComplete="name"
              />
            </div>
            {errors.full_name && (
              <div id="full_name-error" className="field-error">{errors.full_name}</div>
            )}

            <div className="form-holder">
              <input
                type="email"
                className="form-control"
                placeholder="Email"
                name="email"
                value={form.email}
                onChange={onChange}
                aria-invalid={!!errors.email}
                aria-describedby="email-error"
                autoComplete="email"
              />
            </div>
            {errors.email && (
              <div id="email-error" className="field-error">{errors.email}</div>
            )}

            {form.role === "seller" && (
              <>
                <div className="form-holder">
                  <input
                    type="text"
                    className="form-control"
                    placeholder="Company"
                    name="company_name"
                    value={form.company_name}
                    onChange={onChange}
                    aria-invalid={!!errors.company_name}
                    aria-describedby="company-error"
                  />
                </div>
                {errors.company_name && (
                  <div id="company-error" className="field-error">{errors.company_name}</div>
                )}

                <div className="form-holder">
                  <input
                    type="text"
                    className="form-control"
                    placeholder="Phone (optional)"
                    name="phone"
                    value={form.phone}
                    onChange={onChange}
                  />
                </div>

                <div className="form-holder">
                  <input
                    type="text"
                    className="form-control"
                    placeholder="Note (optional)"
                    name="note"
                    value={form.note}
                    onChange={onChange}
                  />
                </div>
              </>
            )}

            {form.role === "buyer" && (
              <>
                <div className="form-holder">
                  <input
                    type="password"
                    className="form-control"
                    placeholder="Password"
                    name="password"
                    value={form.password}
                    onChange={onChange}
                    aria-invalid={!!errors.password}
                    aria-describedby="password-error"
                    autoComplete="new-password"
                  />
                </div>
                {errors.password && (
                  <div id="password-error" className="field-error">{errors.password}</div>
                )}
              </>
            )}

            <button type="submit" className="btn primary" disabled={submitting}>
              <span>
                {submitting
                  ? "Submitting..."
                  : form.role === "buyer"
                  ? "Register"
                  : "Submit Application"}
              </span>
            </button>

            {errors.submit && <div className="submit-error" role="alert">{errors.submit}</div>}
          </form>
        </div>
      </div>
    </div>
  );
}
