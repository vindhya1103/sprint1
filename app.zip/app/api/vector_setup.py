
# backend/app/api/vector_setup.py
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from sqlalchemy import text
from app.db.session import get_db
from app.api.auth import require_role
from app.models.embedding import ProductEmbedding

router = APIRouter()

@router.post("/init", response_model=dict)
def init_pgvector(db: Session = Depends(get_db), _=Depends(require_role("admin"))):
    """
    Initialize pgvector extension and create a HNSW index on product_embeddings.embedding.
    Run once after deploying.
    """
    try:
        db.execute(text("CREATE EXTENSION IF NOT EXISTS vector"))
        db.commit()
    except Exception as e:
        db.rollback()
        raise HTTPException(500, f"Failed to create extension: {e}")

    # Create HNSW or IVFFlat index; HNSW is good for cosine/large datasets
    try:
        db.execute(text("""
            CREATE INDEX IF NOT EXISTS ix_pe_embedding_hnsw
            ON product_embeddings
            USING hnsw (embedding vector_cosine_ops);
        """))
        db.commit()
    except Exception as e:
        db.rollback()
        raise HTTPException(500, f"Failed to create index: {e}")

    return {"status": "ok", "extension": "vector", "index": "ix_pe_embedding_hnsw"}
