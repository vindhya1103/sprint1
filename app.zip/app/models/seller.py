

# backend/app/models/seller.py
from sqlalchemy import Column, BigInteger, String, ForeignKey
from sqlalchemy.orm import relationship
from app.models.base import Base

class Seller(Base):
    __tablename__ = "sellers"

    id = Column(BigInteger, primary_key=True)
    external_id = Column(String(64), unique=True, index=True, nullable=False)
    name = Column(String(256), nullable=False)
    email = Column(String(256), nullable=True)

    # If you added support teams:
    # support_team_id = Column(BigInteger, ForeignKey("support_teams.id", ondelete="SET NULL"), nullable=True)

    # ✅ FIX: use back_populates (do NOT use backref here)
    products = relationship("Product", back_populates="seller")
