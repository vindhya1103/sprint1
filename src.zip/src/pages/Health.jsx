
export default function Health() {
  return (
    <div style={{ padding: 24, color: '#fff' }}>
      <h2>Router OK</h2>
      <p>If you can see this, React Router is working.</p>
    </div>
  );
}
