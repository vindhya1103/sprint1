

// src/api.js
const DEFAULT_BASE = "http://127.0.0.1:8001"; // Match backend port you run Uvicorn with
const API_BASE = (import.meta.env?.VITE_API_BASE || DEFAULT_BASE).replace(/\/+$/, "");

function authHeaders() {
  const t = localStorage.getItem("access_token");
  return t ? { Authorization: `Bearer ${t}` } : {};
}

async function handle(res) {
  if (!res.ok) {
    const ct = res.headers.get("content-type") || "";
    let msg = res.statusText;
    try {
      if (ct.includes("application/json")) {
        const json = await res.json();
        msg = json?.detail ?? JSON.stringify(json);
      } else {
        msg = await res.text();
      }
    } catch {}
    throw new Error(`HTTP ${res.status} ${msg}`);
  }
  const ct = res.headers.get("content-type") || "";
  if (!ct.includes("application/json")) return null; // handles 204/empty
  return res.json();
}

function buildUrl(path, params) {
  const safePath = path.startsWith("/") ? path : `/${path}`;
  const url = new URL(API_BASE + safePath);
  if (params) {
    Object.entries(params).forEach(([k, v]) => {
      if (v !== undefined && v !== null) url.searchParams.append(k, v);
    });
  }
  return url.toString();
}

export async function getJSON(path, params) {
  const res = await fetch(buildUrl(path, params), {
    method: "GET",
    headers: { Accept: "application/json", ...authHeaders() },
    // credentials: "include", // uncomment if your API uses cookies/session
  });
  return handle(res);
}

export async function postJSON(path, body) {
  const res = await fetch(buildUrl(path), {
    method: "POST",
    headers: { "Content-Type": "application/json", Accept: "application/json", ...authHeaders() },
    body: JSON.stringify(body || {}),
  });
  return handle(res);
}

export async function postForm(path, form) {
  const data = new URLSearchParams();
  Object.entries(form || {}).forEach(([k, v]) => data.append(k, v));
  const res = await fetch(buildUrl(path), {
    method: "POST",
    headers: { Accept: "application/json", ...authHeaders() },
    body: data,
  });
  return handle(res);
}

export async function patchJSON(path, body) {
  const res = await fetch(buildUrl(path), {
    method: "PATCH",
    headers: { "Content-Type": "application/json", Accept: "application/json", ...authHeaders() },
    body: JSON.stringify(body || {}),
  });
  return handle(res);
}

export async function deleteJSON(path) {
  const res = await fetch(buildUrl(path), {
    method: "DELETE",
    headers: { Accept: "application/json", ...authHeaders() },
  });
  return handle(res);
}
