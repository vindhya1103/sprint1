
from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session
from sqlalchemy import text, select
from typing import Optional, List, Dict, Any

from app.db.session import get_db
from app.api.auth import require_role, get_current_user
from app.core.security import hash_password
from app.core.config import Settings

from app.models.user import User
from app.models.seller import Seller
from app.models.product import Product
from app.models.review import Review
from app.models.analysis import Analysis

router = APIRouter()
settings = Settings()

# -------------------------------------------------------------------
# Schema helpers
# -------------------------------------------------------------------
def _ensure_support_schema(db: Session):
    """
    Idempotent – ensure support_teams + FKs exist (safety net for older DBs).
    """
    ddl = text("""
        CREATE TABLE IF NOT EXISTS support_teams (
          id   BIGSERIAL PRIMARY KEY,
          name TEXT UNIQUE NOT NULL
        );

        ALTER TABLE sellers
          ADD COLUMN IF NOT EXISTS support_team_id BIGINT
            REFERENCES support_teams(id) ON DELETE SET NULL;
        CREATE INDEX IF NOT EXISTS ix_sellers_support_team ON sellers(support_team_id);

        ALTER TABLE users
          ADD COLUMN IF NOT EXISTS support_team_id BIGINT
            REFERENCES support_teams(id) ON DELETE SET NULL;
        CREATE INDEX IF NOT EXISTS ix_users_support_team ON users(support_team_id);
    """)
    db.execute(ddl)
    db.commit()


def _seed_two_teams(db: Session) -> List[Dict[str, Any]]:
    """
    Ensure Team Alpha / Team Beta exist (idempotent).
    """
    sql = text("""
        INSERT INTO support_teams(name) VALUES ('Team Alpha')
        ON CONFLICT (name) DO NOTHING;

        INSERT INTO support_teams(name) VALUES ('Team Beta')
        ON CONFLICT (name) DO NOTHING;

        SELECT id, name FROM support_teams ORDER BY id ASC;
    """)
    rows = db.execute(sql).all()
    db.commit()
    return [{"id": int(r[0]), "name": str(r[1])} for r in rows]


def _truncate(s: Optional[str], n: int = 240) -> str:
    if not s:
        return "(no text)"
    s = s.strip()
    return s if len(s) <= n else s[: n - 3] + "..."


# -------------------------------------------------------------------
# Bootstrap & admin ops for support agents (kept)
# -------------------------------------------------------------------

@router.post("/teams/bootstrap", response_model=Dict[str, Any])
def bootstrap_support_teams(
    db: Session = Depends(get_db),
    _admin = Depends(require_role("admin")),
):
    _ensure_support_schema(db)
    teams = _seed_two_teams(db)
    return {"status": "ok", "teams": teams}


@router.post("/agents/bootstrap", response_model=Dict[str, Any])
def bootstrap_support_agents(
    emails: Optional[List[str]] = Query(None, description="Two emails, e.g., support1@example.com,support2@example.com"),
    default_password: str = Query("Support@123"),
    db: Session = Depends(get_db),
    _admin = Depends(require_role("admin")),
):
    """
    Create exactly TWO support users and assign them to Team Alpha (first) & Team Beta (second).
    """
    _ensure_support_schema(db)
    teams = _seed_two_teams(db)
    if len(teams) < 2:
        raise HTTPException(500, "Require two teams")

    team_alpha_id = int(teams[0]["id"])
    team_beta_id  = int(teams[1]["id"])

    if not emails or len(emails) < 2:
        emails = ["support1@example.com", "support2@example.com"]

    chosen = emails[:2]
    out = []

    for idx, email in enumerate(chosen):
        team_id = team_alpha_id if idx == 0 else team_beta_id
        u = db.execute(select(User).where(User.email == email)).scalar_one_or_none()
        pwd = default_password
        if u:
            u.role = "support"
            u.support_team_id = team_id
            u.is_active = True
            u.must_change_password = False
            u.password_hash = hash_password(pwd)
            db.add(u); db.flush()
            out.append({"email": email, "team_id": team_id, "password": pwd, "action": "updated"})
        else:
            nu = User(
                email=email,
                full_name="Customer Support",
                role="support",
                support_team_id=team_id,
                is_active=True,
                must_change_password=False,
                password_hash=hash_password(pwd),
            )
            db.add(nu); db.flush()
            out.append({"email": email, "team_id": team_id, "password": pwd, "action": "created"})

    db.commit()
    return {"status": "ok", "agents": out, "teams": teams}


@router.post("/agents/create", response_model=Dict[str, Any])
def create_support_agent(
    payload: Dict[str, Any],
    db: Session = Depends(get_db),
    _admin = Depends(require_role("admin")),
):
    """
    Admin-only: create or update a support agent with email/password and optional team_id.
    Body:
      { "email": "...", "full_name": "Agent", "password": "Strong@123", "team_id": 1 }
    """
    _ensure_support_schema(db)

    email = (payload.get("email") or "").strip()
    password = (payload.get("password") or "").strip()
    full_name = (payload.get("full_name") or "Customer Support").strip()
    team_id = payload.get("team_id")

    if not email or not password:
        raise HTTPException(400, "email and password are required")

    if team_id is not None:
        row = db.execute(text("SELECT id FROM support_teams WHERE id = :tid"), {"tid": int(team_id)}).first()
        if not row:
            raise HTTPException(400, "Unknown team_id")

    u = db.execute(select(User).where(User.email == email)).scalar_one_or_none()
    if u:
        u.full_name = full_name
        u.role = "support"
        u.is_active = True
        u.must_change_password = False
        u.password_hash = hash_password(password)
        u.support_team_id = (int(team_id) if team_id is not None else u.support_team_id)
        db.add(u); db.commit(); db.refresh(u)
        return {"status": "updated", "user_id": u.id}
    else:
        nu = User(
            email=email,
            full_name=full_name,
            role="support",
            is_active=True,
            must_change_password=False,
            password_hash=hash_password(password),
            support_team_id=(int(team_id) if team_id is not None else None),
        )
        db.add(nu); db.commit(); db.refresh(nu)
        return {"status": "created", "user_id": nu.id}


# -------------------------------------------------------------------
# Teams list & seller self-selection (kept)
# -------------------------------------------------------------------

@router.get("/teams", response_model=List[Dict[str, Any]])
def list_support_teams(db: Session = Depends(get_db), _u = Depends(get_current_user)):
    _ensure_support_schema(db)
    rows = db.execute(text("SELECT id, name FROM support_teams ORDER BY id ASC")).all()
    return [{"id": int(r[0]), "name": str(r[1])} for r in rows]


@router.get("/seller/my-support-team", response_model=Dict[str, Any])
def seller_my_support_team(
    db: Session = Depends(get_db),
    u: User = Depends(require_role("seller", "admin")),
):
    _ensure_support_schema(db)
    if u.role == "admin":
        return {"team": None}
    if not u.seller_id:
        return {"team": None}

    r = db.execute(
        text("""
            SELECT st.id, st.name
            FROM sellers s
            LEFT JOIN support_teams st ON st.id = s.support_team_id
            WHERE s.id = :sid
        """),
        {"sid": int(u.seller_id)}
    ).first()
    if not r or r[0] is None:
        return {"team": None}
    return {"team": {"id": int(r[0]), "name": str(r[1])}}


@router.post("/seller/choose-support-team", response_model=Dict[str, Any])
def seller_choose_support_team(
    team_id: int,
    db: Session = Depends(get_db),
    u: User = Depends(require_role("seller", "admin")),
):
    _ensure_support_schema(db)

    t = db.execute(text("SELECT id, name FROM support_teams WHERE id = :tid"), {"tid": int(team_id)}).first()
    if not t:
        raise HTTPException(400, "Unknown team_id")

    if u.role == "admin":
        raise HTTPException(400, "Admin should set team via Sellers UI or SQL.")

    if not u.seller_id:
        raise HTTPException(400, "User not linked to a seller")

    row = db.execute(text("SELECT support_team_id FROM sellers WHERE id = :sid"), {"sid": int(u.seller_id)}).first()
    current = int(row[0]) if row and row[0] is not None else None
    if current:
        return {"status": "exists", "team_id": current}

    db.execute(text("UPDATE sellers SET support_team_id = :tid WHERE id = :sid"),
               {"tid": int(team_id), "sid": int(u.seller_id)})
    db.commit()
    return {"status": "ok", "team_id": int(team_id), "team_name": str(t[1])}


# -------------------------------------------------------------------
# Support agent views (kept)
# -------------------------------------------------------------------

@router.get("/me/sellers", response_model=List[Dict[str, Any]])
def support_me_sellers(
    db: Session = Depends(get_db),
    u: User = Depends(require_role("support", "admin")),
):
    _ensure_support_schema(db)
    team_id = int(u.support_team_id) if (u.role == "support" and u.support_team_id is not None) else None

    sql = text("""
        SELECT s.id, s.external_id, s.name, s.email,
               COUNT(p.id) AS products
        FROM sellers s
        LEFT JOIN products p ON p.seller_id = s.id
        WHERE (:is_admin = TRUE AND :team_id IS NULL)
           OR (s.support_team_id = :team_id)
        GROUP BY s.id, s.external_id, s.name, s.email
        ORDER BY s.id ASC
        LIMIT 500
    """)
    rows = db.execute(sql, {"team_id": team_id, "is_admin": (u.role == "admin")}).all()
    return [{
        "id": int(r[0]),
        "external_id": str(r[1]),
        "name": str(r[2]),
        "email": (str(r[3]) if r[3] is not None else None),
        "products": int(r[4]),
    } for r in rows]


@router.get("/seller/{seller_id}/review-feed", response_model=Dict[str, Any])
def support_review_feed_for_seller(
    seller_id: int,
    limit: int = Query(100, ge=1, le=500),
    db: Session = Depends(get_db),
    u: User = Depends(require_role("support", "admin")),
):
    _ensure_support_schema(db)

    if u.role == "support":
        chk = db.execute(
            text("SELECT 1 FROM sellers WHERE id = :sid AND support_team_id = :tid"),
            {"sid": int(seller_id), "tid": int(u.support_team_id or 0)},
        ).first()
        if not chk:
            raise HTTPException(403, "Seller not under your team")

    q = text("""
        SELECT r.id, r.product_id, r.review_date, r.rating,
               COALESCE(a.sentiment, 'unknown') AS sentiment,
               CASE
                 WHEN COALESCE(a.sentiment, 'unknown') = 'negative' THEN TRUE
                 WHEN r.rating IS NOT NULL AND r.rating <= 2 THEN TRUE
                 ELSE FALSE
               END AS negative_flag,
               CASE
                 WHEN a.key_themes IS NOT NULL
                      AND jsonb_typeof(a.key_themes) = 'array'
                      AND jsonb_array_length(a.key_themes) > 0
                 THEN (a.key_themes->0->>'theme')
                 ELSE NULL
               END AS issue_category,
               r.helpful_votes,
               r.review_text
        FROM reviews r
        JOIN products p ON p.id = r.product_id
        LEFT JOIN analyses a ON a.review_id = r.id
        WHERE p.seller_id = :sid
        ORDER BY
          CASE
            WHEN COALESCE(a.sentiment, 'unknown') = 'negative' OR (r.rating IS NOT NULL AND r.rating <= 2) THEN 0
            ELSE 1
          END ASC,
          r.helpful_votes DESC,
          r.review_date DESC NULLS LAST,
          r.id DESC
        LIMIT :lim
    """)
    rows = db.execute(q, {"sid": int(seller_id), "lim": int(limit)}).all()

    items = []
    for rid, pid, d, rating, sent, neg, cat, hv, txt in rows:
        items.append({
            "review_id": int(rid),
            "product_id": int(pid),
            "date": (str(d) if d is not None else None),
            "rating": (int(rating) if rating is not None else None),
            "sentiment": str(sent),
            "negative": bool(neg),
            "issue_category": (str(cat) if cat is not None else None),
            "helpful_votes": int(hv or 0),
            "excerpt": _truncate(txt, 240),
        })
    return {"items": items}


# -------------------------------------------------------------------
# NEW: Seller products list with severe sparkline
# -------------------------------------------------------------------

@router.get("/seller/{seller_id}/products", response_model=List[Dict[str, Any]])
def support_seller_products(
    seller_id: int,
    db: Session = Depends(get_db),
    u: User = Depends(require_role("support", "admin")),
    limit: int = Query(1000, ge=1, le=2000),
):
    """
    Support agent: list all products for a given seller,
    including severe reviews summary (negative/neutral) and a small sparkline.
    Enforces team scoping for support role.
    """
    _ensure_support_schema(db)

    # Team scoping: support agent must own this seller via team
    if u.role == "support":
        chk = db.execute(
            text("SELECT 1 FROM sellers WHERE id = :sid AND support_team_id = :tid"),
            {"sid": int(seller_id), "tid": int(u.support_team_id or 0)},
        ).first()
        if not chk:
            raise HTTPException(403, "Seller not under your team")

    # 1) Basic product list
    rows = db.execute(text("""
        SELECT p.id, p.product_title, p.brand, p.category, p.subtype, p.price
        FROM products p
        WHERE p.seller_id = :sid
        ORDER BY p.id ASC
        LIMIT :lim
    """), {"sid": int(seller_id), "lim": int(limit)}).all()

    products: List[Dict[str, Any]] = [{
        "id": int(r[0]),
        "product_title": str(r[1]),
        "brand": (str(r[2]) if r[2] is not None else None),
        "category": (str(r[3]) if r[3] is not None else None),
        "subtype": (str(r[4]) if r[4] is not None else None),
        "price": (float(r[5]) if r[5] is not None else None),
    } for r in rows]

    # 2) For each product, compute severe_total and sparkline (last 12 dates)
    for p in products:
        pid = int(p["id"])
        total_row = db.execute(text("""
            SELECT COUNT(*) FROM reviews r
            LEFT JOIN analyses a ON a.review_id = r.id
            WHERE r.product_id = :pid
              AND COALESCE(a.sentiment, 'unknown') IN ('negative','neutral')
        """), {"pid": pid}).first()
        severe_total = int(total_row[0]) if total_row else 0

        series_rows = db.execute(text("""
            SELECT COALESCE(TO_CHAR(r.review_date, 'YYYY-MM-DD'), 'unknown') AS date,
                   COUNT(*) AS count
            FROM reviews r
            LEFT JOIN analyses a ON a.review_id = r.id
            WHERE r.product_id = :pid
              AND COALESCE(a.sentiment, 'unknown') IN ('negative','neutral')
            GROUP BY date
            ORDER BY date ASC
            LIMIT 60
        """), {"pid": pid}).all()
        series = [{"date": str(d), "count": int(c)} for (d, c) in series_rows]
        # keep the last 12 points for sparkline
        sparkline = series[-12:] if len(series) > 12 else series

        p["severe_total"] = severe_total
        p["sparkline"] = sparkline

    return products


# -------------------------------------------------------------------
# Severe reviews per product (kept)
# -------------------------------------------------------------------

@router.get("/product/{product_id}/urgent", response_model=Dict[str, Any])
def product_urgent(product_id: int, db: Session = Depends(get_db)):
    """
    Severe reviews for a product:
    - sentiment: negative or neutral
    - sorted by severity, helpful_votes, and recency
    """
    q = text("""
        SELECT r.id, r.product_id, r.review_date, r.rating, r.reviewer_name, r.helpful_votes,
               COALESCE(a.sentiment, 'unknown') AS sentiment,
               COALESCE((a.key_themes->0->>'theme'), NULL) AS top_issue,
               CASE COALESCE(a.sentiment,'unknown') WHEN 'negative' THEN 3 WHEN 'neutral' THEN 2 ELSE 1 END AS severity,
               r.review_text
        FROM reviews r
        LEFT JOIN analyses a ON a.review_id = r.id
        WHERE r.product_id = :pid AND COALESCE(a.sentiment, 'unknown') IN ('negative','neutral')
        ORDER BY severity DESC, r.helpful_votes DESC, r.review_date DESC
        LIMIT 100
    """)
    rows = db.execute(q, {"pid": product_id}).all()
    items = []
    for rid, pid, d, rating, name, hv, s, theme, sev, txt in rows:
        excerpt = (txt or "").strip()
        if len(excerpt) > 240:
            excerpt = excerpt[:237] + "..."
        items.append({
            "review_id": int(rid), "product_id": int(pid), "review_date": str(d),
            "rating": int(rating) if rating is not None else None, "reviewer_name": name,
            "helpful_votes": int(hv or 0), "sentiment": s, "top_issue": theme,
            "severity": int(sev), "excerpt": excerpt
        })
    return {"items": items}


@router.get("/reviews/negative", response_model=Dict[str, Any])
def global_negative(db: Session = Depends(get_db)):
    """
    (Kept) All negative reviews across products (global view).
    """
    q = text("""
        SELECT r.id, r.product_id, r.review_date, r.rating, r.reviewer_name, r.helpful_votes,
               COALESCE(a.sentiment, 'unknown') AS sentiment,
               COALESCE((a.key_themes->0->>'theme'), NULL) AS top_issue,
               CASE COALESCE(a.sentiment,'unknown') WHEN 'negative' THEN 3 WHEN 'neutral' THEN 2 ELSE 1 END AS severity,
               r.review_text
        FROM reviews r
        LEFT JOIN analyses a ON a.review_id = r.id
        WHERE COALESCE(a.sentiment, 'unknown') = 'negative'
        ORDER BY r.helpful_votes DESC, r.review_date DESC
        LIMIT 100
    """)
    rows = db.execute(q).all()
    items = []
    for rid, pid, d, rating, name, hv, s, theme, sev, txt in rows:
        excerpt = (txt or "").strip()
        if len(excerpt) > 240:
            excerpt = excerpt[:237] + "..."
        items.append({
            "review_id": int(rid), "product_id": int(pid), "review_date": str(d),
            "rating": int(rating) if rating is not None else None, "reviewer_name": name,
            "helpful_votes": int(hv or 0), "sentiment": s, "top_issue": theme,
            "severity": int(sev), "excerpt": excerpt
        })
    return {"items": items}
