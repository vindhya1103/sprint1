
// src/auth/AuthContext.jsx
import { createContext, useContext, useEffect, useState } from 'react'
import { postForm, getJSON } from '../api'

const AuthCtx = createContext(null)
export const useAuth = () => useContext(AuthCtx)

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null)

  async function refreshMe() {
    try {
      const token = localStorage.getItem('access_token')
      if (!token) { setUser(null); return null }
      const me = await getJSON('/auth/me')
      setUser(me)
      return me
    } catch (e) {
      setUser(null)
      return null
    }
  }

  useEffect(() => { refreshMe() }, [])

  // IMPORTANT: return the freshly fetched "me" object
  async function login(email, password) {
    const data = await postForm('/auth/login', { username: email, password })
    localStorage.setItem('access_token', data.access_token)
    const me = await refreshMe()
    return me
  }

  async function loginWithToken(access_token) {
    localStorage.setItem('access_token', access_token)
    const me = await refreshMe()
    return me
  }

  function logout() {
    localStorage.removeItem('access_token')
    setUser(null)
  }

  const value = { user, login, loginWithToken, logout, refreshMe }
  return <AuthCtx.Provider value={value}>{children}</AuthCtx.Provider>
}
