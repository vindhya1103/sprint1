
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from app.db.session import get_db
from app.models.seller import Seller
from app.models.product import Product

router = APIRouter()

@router.post("/", response_model=dict)
def create_seller(payload: dict, db: Session = Depends(get_db)):
    ext = (payload.get("external_id") or "").strip()
    if not ext:
        raise HTTPException(400, "external_id required")
    name = (payload.get("name") or "").strip() or "Unknown"
    email = (payload.get("email") or None)
    s = db.query(Seller).filter(Seller.external_id == ext).first()
    if s:
        return {"id": s.id, "status": "exists"}
    s = Seller(external_id=ext, name=name, email=email)
    db.add(s); db.commit(); db.refresh(s)
    return {"id": s.id}

@router.get("/", response_model=list[dict])
def list_sellers(db: Session = Depends(get_db)):
    rows = db.query(Seller).order_by(Seller.id.asc()).limit(200).all()
    return [{"id": s.id, "external_id": s.external_id, "name": s.name, "email": s.email} for s in rows]

@router.get("/{seller_id}/products", response_model=list[dict])
def list_seller_products(seller_id: int, db: Session = Depends(get_db)):
    rows = db.query(Product).filter(Product.seller_id == seller_id).order_by(Product.id.asc()).limit(500).all()
    return [{"id": p.id, "sku": p.sku, "product_title": p.product_title, "brand": p.brand, "category": p.category, "price": float(p.price) if p.price is not None else None} for p in rows]
