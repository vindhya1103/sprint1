
// src/pages/SellerProducts.jsx
import { useEffect, useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";
import Header from "../components/Header";
import { getJSON } from "../api";

export default function SellerProducts() {
  const [loading, setLoading] = useState(true);
  const [products, setProducts] = useState([]);
  const [error, setError] = useState("");
  const [query, setQuery] = useState(""); // search
  const navigate = useNavigate();

  useEffect(() => {
    let cancelled = false;
    (async () => {
      setLoading(true);
      setError("");
      try {
        const rows = await getJSON("/seller/me/products");
        if (!cancelled) setProducts(rows || []);
      } catch (e) {
        if (!cancelled) setError(e?.message || "Failed to load products.");
      } finally {
        if (!cancelled) setLoading(false);
      }
    })();
    return () => { cancelled = true; };
  }, []);

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    if (!q) return products || [];
    return (products || []).filter((p) => {
      const title = (p.product_title || "").toLowerCase();
      const brand = (p.brand || "").toLowerCase();
      const cat = (p.category || "").toLowerCase();
      const sub = (p.subtype || "").toLowerCase();
      return title.includes(q) || brand.includes(q) || cat.includes(q) || sub.includes(q);
    });
  }, [products, query]);

  return (
    <div>
      <Header />

      <main className="container sp-container">
        {/* Scoped styles */}
        <style>{`
          :root {
            --bg: #0b1020;
            --card: #0f172a;
            --cardBorder: #1f2937;
            --text: #e5e7eb;
            --muted: #9fb0d1;
            --primary: #3b82f6;
            --primary-600: #2563eb;
            --succ: #34d399;

            /* 🔧 Change this to make the search wider/narrower */
            --search-max-w: 680px; /* e.g., 560px, 640px, 720px */
          }
          .sp-container {
            padding: 24px;
            color: var(--text);
          }

          /* Header */
          .sp-header {
            margin-bottom: 14px;
          }
          .sp-title {
            margin: 0 0 8px;
            font-size: 1.6rem;
            letter-spacing: -0.2px;
          }

          /* Centered search wrapper */
          .sp-search-wrap {
            display: flex;
            justify-content: center;
            align-items: center;
          }
          .sp-search {
            width: 100%;
            max-width: var(--search-max-w); /* 👈 Max width controlled via CSS var */
            display: flex; align-items: center; gap: 8px;
            background: var(--card); border: 1px solid var(--cardBorder);
            border-radius: 12px; padding: 10px 12px;
          }
          .sp-search input {
            flex: 1; background: transparent; border: none; outline: none; color: var(--text);
            font-size: 1rem;
          }
          .sp-search svg { opacity: .85; }

          /* Grid + Card (compact) */
          .sp-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(280px, 1fr));
            gap: 10px; /* compact gap */
            margin-top: 16px;
          }
          .sp-card {
            background: var(--card);
            border: 1px solid var(--cardBorder);
            border-radius: 12px;
            padding: 10px; /* compact padding */
            box-shadow: 0 1px 3px rgba(0,0,0,.25);
            text-align: left;
            cursor: pointer;
            transition: transform .08s ease, box-shadow .12s ease, border-color .12s ease, background .12s ease;
          }
          .sp-card:hover {
            transform: translateY(-2px);
            border-color: #2a3b65;
            box-shadow: 0 6px 16px rgba(0,0,0,.25);
            background: #111b33;
          }

          /* Thumbnail */
          .sp-thumb {
            height: 140px; /* compact height */
            border-radius: 10px;
            overflow: hidden;
            background: #0b1222;
            margin-bottom: 8px;
            border: 1px solid rgba(255,255,255,0.06);
          }
          .sp-thumb img {
            width: 100%;
            height: 100%;
            object-fit: cover;
            display: block;
          }

          .sp-name {
            margin: 0 0 4px; font-weight: 700; font-size: 1rem; color: #fff;
          }
          .sp-meta {
            margin: 0 8px 8px 0; color: var(--muted); font-size: .92rem;
          }
          .sp-footer {
            display: flex; align-items: center; justify-content: space-between;
          }
          .sp-price {
            display: inline-flex; align-items: center; gap: 6px;
            padding: 4px 8px; border-radius: 999px;
            background: rgba(52,211,153,0.12);
            color: var(--succ);
            font-weight: 700; font-size: .95rem;
            border: 1px solid rgba(52,211,153,0.35);
          }
          .sp-cta {
            color: var(--primary);
            border: 1px dashed rgba(59,130,246,.45);
            background: rgba(59,130,246,.08);
            border-radius: 8px;
            padding: 4px 8px;
            font-size: .9rem;
          }

          /* Skeletons (compact) */
          .sk-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(280px, 1fr));
            gap: 10px;
            margin-top: 16px;
          }
          .sk-card {
            background: var(--card);
            border: 1px solid var(--cardBorder);
            border-radius: 12px;
            padding: 10px;
          }
          .sk-thumb {
            height: 140px; border-radius: 10px; background: #101a32; margin-bottom: 8px;
          }
          .sk-line {
            height: 12px; border-radius: 8px; background: #1a253d;
            margin: 8px 0;
            animation: pulse 1.2s ease-in-out infinite;
          }
          .sk-line.w1 { width: 85%; }
          .sk-line.w2 { width: 60%; }
          .sk-line.w3 { width: 40%; }
          @keyframes pulse {
            0% { opacity: 0.55; }
            50% { opacity: 0.95; }
            100% { opacity: 0.55; }
          }

          /* Empty + error */
          .sp-hint { color: var(--muted); margin-top: 12px; }
          .sp-error { color: #f66; margin-top: 12px; }
        `}</style>

        {/* Title + centered search */}
        <div className="sp-header">
          <h2 className="sp-title">My Products</h2>
          <div className="sp-search-wrap">
            <div className="sp-search" role="search" aria-label="Search products">
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" aria-hidden="true">
                <circle cx="11" cy="11" r="7" stroke="currentColor" strokeWidth="2" />
                <line x1="16.65" y1="16.65" x2="21" y2="21" stroke="currentColor" strokeWidth="2" strokeLinecap="round" />
              </svg>
              <input
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder="Search products by name, brand, category…"
                aria-label="Search products"
              />
            </div>
          </div>
        </div>

        {/* Loading skeletons */}
        {loading && (
          <div className="sk-grid" aria-busy="true">
            {Array.from({ length: 8 }).map((_, i) => (
              <div key={i} className="sk-card">
                <div className="sk-thumb" />
                <div className="sk-line w1" />
                <div className="sk-line w2" />
                <div className="sk-line w3" />
              </div>
            ))}
          </div>
        )}

        {/* Errors */}
        {!loading && error && (
          <div className="sp-error" role="alert">
            {error}
          </div>
        )}

        {/* Empty */}
        {!loading && !error && filtered.length === 0 && (
          <p className="sp-hint">No products found.</p>
        )}

        {/* Grid */}
        {!loading && !error && filtered.length > 0 && (
          <div className="sp-grid">
            {filtered.map((p) => (
              <button
                key={p.id}
                className="sp-card"
                onClick={() => navigate(`/seller/product/${p.id}`)}
                title="Open seller insights"
              >
                {/* Thumbnail */}
                <div className="sp-thumb">
                  <img
                    src={p.image_url || "https://via.placeholder.com/800x600?text=Product"}
                    alt={p.product_title || `#${p.id}`}
                    onError={(e) => {
                      // Gracefully hide broken images
                      e.currentTarget.style.display = "none";
                    }}
                    loading="lazy"
                  />
                </div>

                <h4 className="sp-name">{p.product_title}</h4>
                <p className="sp-meta">
                  {(p.brand || "—")} · {(p.category || "—")}
                  {p.subtype ? ` · ${p.subtype}` : ""}
                </p>

                <div className="sp-footer">
                  <span className="sp-cta">View analytics</span>
                  <span className="sp-price">
                    {p.price != null ? `₹${Number(p.price).toFixed(2)}` : "—"}
                  </span>
                </div>
              </button>
            ))}
          </div>
        )}
      </main>
    </div>
  );
}
