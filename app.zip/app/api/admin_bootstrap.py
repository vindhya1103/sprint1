
from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from sqlalchemy import select
from app.db.session import get_db
from app.models.user import User
from app.core.security import hash_password

router = APIRouter()

from app.core.config import Settings
settings = Settings()

@router.post("/bootstrap-admin")
def bootstrap_admin(email: str, password: str, db: Session = Depends(get_db)):
    existing = db.execute(select(User).where(User.email == email)).scalar_one_or_none()
    if existing:
        return {"status": "already_exists", "email": email}
    u = User(email=email, full_name="Administrator", password_hash=hash_password(password), role="admin")
    db.add(u); db.commit(); db.refresh(u)
    return {"status": "admin_created", "email": email}
